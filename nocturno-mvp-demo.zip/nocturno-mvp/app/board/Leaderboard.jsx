"use client";

import { useCallback, useEffect, useState } from "react";
import styles from "./board.module.css";
import { useT } from "@/app/components/i18n/LangProvider";

function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

export default function Leaderboard() {
  const t = useT();
  const [rows, setRows] = useState([]);
  const [loaded, setLoaded] = useState(false);

  const refresh = useCallback(async () => {
    const res = await fetch("/api/leaderboard?limit=10");
    if (!res.ok) return;
    const data = await res.json();
    setRows(data.leaderboard);
    setLoaded(true);
  }, []);

  useEffect(() => {
    refresh();
    // Polling, not websockets. On a screen nobody interacts with, a five
    // second lag is invisible, and a socket that silently dies at 2am and
    // leaves a frozen board on the wall is worse than a poll that retries.
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  const top = rows[0];

  return (
    <main className={styles.wrap}>
      <header className={styles.head}>
        <div>
          <p className={styles.eyebrow}>{t("board.tonight")}</p>
          <h1 className={styles.title}>{t("board.title")}</h1>
        </div>
        <span className={styles.venue}>Club Nocturno</span>
      </header>

      {loaded && rows.length === 0 && (
        <p className={styles.empty}>{t("board.empty")}</p>
      )}

      <ol className={styles.list}>
        {rows.map((r) => (
          <li key={r.tableId} className={styles.row} data-lead={r.rank === 1 || undefined}>
            <span className={`mono ${styles.rank}`}>{String(r.rank).padStart(2, "0")}</span>
            <span className={styles.label}>
              {r.label}
              {r.live && <i className={styles.live} aria-label={t("board.stillOpen")} />}
            </span>
            <span className={styles.zone}>{r.zone}</span>
            {/* A bar rather than a raw ranking: across a room you read the
                gap between tables long before you read the numbers. */}
            <span className={styles.barWrap}>
              <span
                className={styles.bar}
                style={{ width: top ? `${(r.spentCents / top.spentCents) * 100}%` : 0 }}
              />
            </span>
            <span className={`mono ${styles.amount}`}>{eur(r.spentCents)} €</span>
          </li>
        ))}
      </ol>
    </main>
  );
}
