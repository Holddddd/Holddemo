import { LangProvider } from "@/app/components/i18n/LangProvider";
import { getLang } from "@/lib/i18n/server";

// The staff side's language — chosen separately from the guest side's.
// Adds the language button; changes nothing else on the page.
export default function Layout({ children }) {
  return (
    <LangProvider area="staff" initialLang={getLang("staff")}>
      {children}
    </LangProvider>
  );
}
