import Leaderboard from "./Leaderboard";

// The wall screen. No chrome, no navigation — this page is furniture.
export const metadata = { title: "Tonight · Club Nocturno" };

export default function BoardPage() {
  return <Leaderboard />;
}
