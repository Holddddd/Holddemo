import { NextResponse } from "next/server";
import {
  getTable,
  updateTable,
  mutateTable,
  sumOpenHolds,
  claimSettlement,
} from "@/lib/db";
import { canSeeBooking } from "@/lib/auth";
import { settleHolds } from "@/lib/settle";
import { rememberVisit } from "@/lib/customers";
import { notifyGuest, billClosedMessage } from "@/lib/notify";
import { emailReceipt } from "@/lib/email";
import { buildReceipt, receiptText } from "@/lib/receipt";

// Guest-initiated close-out from their own phone: settle the tab, add a
// tip, rate the service, leave a note. Staff's /api/capture still exists
// and does the same settlement without the guest-side fields — this is
// the path where the person paying is the one pressing the button.
//
// The hard constraint is the same one that governs every capture: you can
// never take more than was authorized. So the tip is not free-form money,
// it is bounded by the headroom left under the hold.
export async function POST(req) {
  const {
    tableId,
    bookingToken,
    tipAmountCents = 0,
    serviceRating = null,
    guestComment = null,
  } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }

  // This route takes money. Nothing about it runs on a guessable id alone.
  if (!canSeeBooking(table, bookingToken)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }
  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }

  // One card per table, so the tab IS what this guest owes — less any
  // notes already handed to a waiter during the night.
  const tab = table.tabAmountCents || 0;
  const cash = table.cashAmountCents || 0;
  const owedOnCard = Math.max(0, tab - cash);
  const hold = sumOpenHolds(table);
  const cur = table.currency.toUpperCase();

  if (tab <= 0) {
    return NextResponse.json({ error: "Nothing ordered yet" }, { status: 400 });
  }

  // NOT ONE EURO OVER. If the bill is bigger than the card can cover, the
  // guest does not get a partial payment and a quiet debt — they top up
  // first and then pay in full.
  //
  // The alternative, capturing whatever is authorized and leaving the rest
  // outstanding, is how a guest ends up believing they have settled while
  // the venue believes they owe 300 €. Refusing is the honest outcome:
  // nothing has moved, and the way forward is on screen.
  if (owedOnCard > hold) {
    const short = owedOnCard - hold;
    return NextResponse.json(
      {
        error: `Your bill is ${(tab / 100).toFixed(2)} ${cur} and ${(hold / 100).toFixed(
          2
        )} ${cur} is authorized on your card. Add ${(short / 100).toFixed(
          2
        )} ${cur} before paying — ask a member of staff, or approve the request they send you.`,
        code: "over_limit",
        shortCents: short,
      },
      { status: 409 }
    );
  }

  const tip = Math.max(0, Math.round(tipAmountCents));
  // The card is charged what is still owed after cash, plus the tip.
  const total = owedOnCard + tip;

  if (total > hold) {
    const maxTip = Math.max(0, hold - owedOnCard);
    return NextResponse.json(
      {
        error: `A tip of ${(tip / 100).toFixed(2)} ${cur} would put the card charge over the ${(
          hold / 100
        ).toFixed(2)} ${cur} authorized. The most that can be added is ${(maxTip / 100).toFixed(
          2
        )} ${cur} — ask staff to raise the hold for anything above that.`,
        maxTipCents: maxTip,
      },
      { status: 400 }
    );
  }

  if (serviceRating !== null && ![1, 2, 3, 4, 5].includes(serviceRating)) {
    return NextResponse.json({ error: "Rating must be 1–5" }, { status: 400 });
  }

  // The guest's phone and the staff board can reach this table at the same
  // second. Without an atomic claim both pass every check above and both
  // capture the card. See claimSettlement.
  if (!claimSettlement(tableId)) {
    return NextResponse.json(
      {
        error: "This bill is already being closed — give it a moment.",
        code: "settlement_in_progress",
      },
      { status: 409 }
    );
  }

  try {
    const { holds, captured, failure, shortCents } = await settleHolds(table, total);

    // Computed from the row as it stands now, not from the copy read
    // before the Stripe round-trip.
    const updated = mutateTable(
      tableId,
      () => ({
        status: failure ? "checked_in" : "closed",
        settlingAt: null,
        holds,
        holdAmountCents: failure ? sumOpenHolds({ holds }) : 0,
        capturedAmountCents: captured,
        billAmountCents: tab,
        tipAmountCents: tip,
        serviceRating,
        guestComment: guestComment ? String(guestComment).slice(0, 500) : null,
      }),
      `${failure ? "Guest close-out PARTIAL" : "Guest closed the bill"} — bill ${(tab / 100).toFixed(2)} ${cur}${
        cash ? `, ${(cash / 100).toFixed(2)} already paid in cash` : ""
      }, captured ${(captured / 100).toFixed(2)} on the card (${(owedOnCard / 100).toFixed(
        2
      )} + ${(tip / 100).toFixed(2)} tip)${serviceRating ? `, rated ${serviceRating}/5` : ""}${
        failure ? ` — STOPPED: ${failure.message}` : ""
      }`
    );

    // Report the failure only after what actually moved is written down.
    if (failure) {
      return NextResponse.json(
        {
          error: `Only part of your bill could be taken (${(captured / 100).toFixed(
            2
          )} ${cur}). Nothing more has been charged — please ask a member of staff.`,
          capturedCents: captured,
          shortCents,
          partial: true,
        },
        { status: 402 }
      );
    }

    // Learn what they drank, but only once the money actually landed —
    // a failed capture shouldn't teach the venue anything.
    rememberVisit(table.customerKey, {
      guestName: table.guestName,
      orders: table.orders,
    });

    // Same receipt the staff path sends. Fire-and-forget: the money has
    // moved, and a failed SMS must not turn a successful capture into an
    // error the guest sees.
    await notifyGuest(
      updated,
      billClosedMessage(updated, {
        capturedCents: captured,
        releasedCents: Math.max(0, hold - captured),
      })
    );

    // The itemised receipt, by email. Same fire-and-forget contract.
    const receipt = buildReceipt(updated);
    const email = await emailReceipt(updated, {
      subject: `${receipt.venue} — receipt for ${receipt.tableName}`,
      text: receiptText(receipt),
    });

    return NextResponse.json({ ok: true, table: updated, receipt, email });
  } catch (err) {
    // Hand the table back, or the guest can never retry and staff find it
    // stuck for the rest of the night.
    updateTable(tableId, { settlingAt: null }, `Guest close-out FAILED: ${err.message}`);
    return NextResponse.json(
      { error: `${err.message} — please ask a member of staff.` },
      { status: 500 }
    );
  }
}
