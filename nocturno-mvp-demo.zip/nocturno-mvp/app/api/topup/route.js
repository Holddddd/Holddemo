import { NextResponse } from "next/server";
import crypto from "crypto";
import { staffOnly, currentStaff, canApproveTopUp, newTopUpToken } from "@/lib/auth";
import { stripe } from "@/lib/stripe";
import { getTable, updateTable, sumOpenHolds, mutateTable } from "@/lib/db";
import { notifyGuest } from "@/lib/notify";
import { TOPUP_EXPIRY_MINUTES, CASH_LIMIT_CENTS } from "@/lib/config";

// Raising what is held on the card, WITH the guest's consent.
//
// What this replaces: staff pressed +500 and a second authorization
// appeared on the guest's card off-session, silently, while they were
// dancing. It worked, and Stripe allows it under the mandate taken at
// booking — but combined with hiding the running tab it becomes "we grow
// the amount reserved on your card and you can see neither the tab nor the
// hold". That is the version that is genuinely indefensible, not merely
// unusual.
//
// So the flow is now a REQUEST:
//
//   1. Staff ask for more headroom          (action: "request")
//   2. The guest gets a message with a link
//   3. The guest opens it, sees the amount, and approves
//   4. The card issuer challenges them — 3DS, on-session   (action: "confirm")
//   5. The hold is placed                                  (action: "finalize")
//
// Slower, and interrupts somebody's night. It is also an explicit,
// authenticated consent to each increase, which is a stronger position
// under PSD2 than a stored mandate, and it means the guest always knows
// what is reserved even though they cannot see the tab.
export async function POST(req) {
  const body = await req.json().catch(() => ({}));
  const { action, tableId } = body;

  const table = getTable(tableId);
  if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });

  if (action === "request") return request(table, body);
  if (action === "confirm") return confirm(table, body);
  if (action === "finalize") return finalize(table, body);
  if (action === "cancel") return cancelRequest(table, body);
  if (action === "cash") return takeCash(table, body);
  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}

// What the guest sees when they open the link, and what the staff board
// polls to know whether they've approved it yet.
export async function GET(req) {
  const url = new URL(req.url);
  const table = getTable(url.searchParams.get("tableId"));
  if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });
  if (!canApproveTopUp(table, url.searchParams.get("t"))) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }

  // Deliberately narrow: the guest cannot see their tab, so this must not
  // become the back door that shows it.
  return NextResponse.json({
    tableName: table.name,
    guestName: table.guestName,
    currency: table.currency,
    topUp: table.topUp || null,
  });
}

// ---------- 1. staff ask ----------

async function request(table, { amountCents }) {
  const denied = staffOnly();
  if (denied) return denied;
  const actor = currentStaff();

  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }

  const amount = Math.round(Number(amountCents));
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Amount must be positive" }, { status: 400 });
  }

  // One open request at a time. Two live links for the same table means a
  // guest can approve both and be held twice for one raise.
  if (table.topUp && table.topUp.status === "pending") {
    return NextResponse.json(
      {
        error: `There is already a pending request for ${(
          table.topUp.amountCents / 100
        ).toFixed(2)} ${table.currency.toUpperCase()}. Cancel it before asking for another.`,
        code: "already_pending",
      },
      { status: 409 }
    );
  }

  const cur = table.currency.toUpperCase();
  // Good for this one top-up and nothing else — see newTopUpToken.
  const linkToken = newTopUpToken();

  const topUp = {
    id: `tu_${crypto.randomBytes(6).toString("hex")}`,
    tokenHash: linkToken.tokenHash,
    amountCents: amount,
    status: "pending",
    requestedAt: new Date().toISOString(),
    requestedBy: actor,
    expiresAt: Date.now() + TOPUP_EXPIRY_MINUTES * 60 * 1000,
    paymentIntentId: null,
  };

  const updated = updateTable(
    table.id,
    { topUp },
    `Requested ${(amount / 100).toFixed(2)} ${cur} more on the card — waiting for the guest to approve`,
    actor
  );

  const link = `${originOf()}/topup/${table.id}?t=${linkToken.token}`;
  const notification = await notifyGuest(
    updated,
    `${table.name}: the bar needs to reserve a further ${(amount / 100).toFixed(
      2
    )} ${cur} on your card to keep your table open. Nothing is charged — approve it here: ${link}`
  );

  return NextResponse.json({ ok: true, table: updated, notification });
}

// The link has to be a full URL for a phone. NEXT_PUBLIC_APP_URL wins when
// set (a deployed venue), otherwise localhost so the demo works.
function originOf() {
  return (process.env.NEXT_PUBLIC_APP_URL || "http://localhost:3010").replace(/\/$/, "");
}

// ---------- 2. the guest approves ----------

async function confirm(table, { bookingToken }) {
  if (!canApproveTopUp(table, bookingToken)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }

  const topUp = table.topUp;
  if (!topUp || topUp.status !== "pending") {
    return NextResponse.json({ error: "Nothing to approve" }, { status: 400 });
  }
  if (topUp.expiresAt && Date.now() > topUp.expiresAt) {
    updateTable(table.id, { topUp: { ...topUp, status: "expired" } }, `Top-up request expired`);
    return NextResponse.json(
      { error: "This request has expired. Ask staff to send a new one." },
      { status: 410 }
    );
  }

  try {
    // off_session is deliberately FALSE and confirm is true: this is the
    // guest, on their phone, right now. That is what makes the issuer
    // raise a 3DS challenge instead of silently approving against the
    // mandate — the whole point of the flow.
    const pi = await stripe.paymentIntents.create(
      {
        amount: topUp.amountCents,
        currency: table.currency,
        customer: table.stripeCustomerId,
        payment_method: table.paymentMethodId,
        off_session: false,
        confirm: true,
        capture_method: "manual",
        use_stripe_sdk: true,
        // 3-D Secure on EVERY top-up, not only when the issuer happens to
        // want it. Left to the bank, most cards — and Stripe's 4242 test
        // card — approve frictionlessly, so a staff request could raise
        // the hold without the cardholder ever proving it was them.
        // "challenge" asks the issuer to show the guest a verification
        // step; finalize() then refuses the hold unless Stripe reports the
        // authentication actually happened.
        payment_method_options: {
          card: { request_three_d_secure: "challenge" },
        },
        // Without this Stripe wants somewhere to send the guest back to
        // for redirect-based authentication.
        // The guest is on the page and has already presented a token —
        // theirs is the one that will still open this URL when Stripe
        // sends them back. The server holds none to substitute.
        return_url: `${originOf()}/topup/${table.id}?t=${encodeURIComponent(
          bookingToken || ""
        )}`,
        metadata: { tableId: table.id, kind: "topup", topUpId: topUp.id },
      },
      { idempotencyKey: `topup_${topUp.id}_3ds` }
    );

    updateTable(table.id, { topUp: { ...topUp, paymentIntentId: pi.id } });

    return NextResponse.json({
      ok: true,
      clientSecret: pi.client_secret,
      status: pi.status,
      publishableKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
    });
  } catch (err) {
    updateTable(
      table.id,
      { topUp: { ...topUp, status: "declined" } },
      `Top-up of ${(topUp.amountCents / 100).toFixed(2)} ${table.currency.toUpperCase()} DECLINED: ${err.message}`
    );
    return NextResponse.json({ error: err.message }, { status: 402 });
  }
}

// ---------- 3. after the 3DS challenge ----------
//
// The client tells us it is done; we ask Stripe rather than believing it.
// A browser saying "authentication succeeded" is not evidence that money
// is reserved.
const THREE_DS_PASSED = new Set(["authenticated", "attempt_acknowledged"]);

async function finalize(table, { bookingToken }) {
  if (!canApproveTopUp(table, bookingToken)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }

  const topUp = table.topUp;
  if (!topUp?.paymentIntentId) {
    return NextResponse.json({ error: "Nothing to finalize" }, { status: 400 });
  }
  if (topUp.status === "done") {
    return NextResponse.json({ ok: true, alreadyDone: true });
  }

  const pi = await stripe.paymentIntents.retrieve(topUp.paymentIntentId, {
    expand: ["latest_charge"],
  });
  const cur = table.currency.toUpperCase();

  // requires_capture IS the success state for a hold: authorized, not
  // taken. Anything else means the money is not reserved.
  if (pi.status !== "requires_capture") {
    return NextResponse.json(
      { error: `Authentication did not complete (${pi.status}).`, status: pi.status },
      { status: 402 }
    );
  }

  // PROOF OF 3-D SECURE, checked here and not in the browser.
  //
  // Requesting a challenge is not the same as getting one: an issuer can
  // still wave the payment through, and a modified client could skip the
  // step entirely and call this endpoint anyway. Stripe records what really
  // happened on the charge, so that record is what decides.
  //
  // Two results pass:
  //   authenticated         the guest completed the bank's verification.
  //   attempt_acknowledged  the card's bank does not do 3-D Secure at all,
  //                         so there is no step the guest COULD complete;
  //                         the attempt is on record, and under the card
  //                         schemes' rules liability for a dispute usually
  //                         moves to that bank. Refusing these made top-ups
  //                         impossible for such cards — including Stripe's
  //                         4242 test card — with no way for the guest to
  //                         do anything about it.
  // Everything else — failed, abandoned, or no 3-D Secure run at all — is
  // refused, and the reserved money is released on the spot: an
  // authorization that was never put through verification must not stay on
  // the guest's card, and it is not added to the table.
  const tds = pi.latest_charge?.payment_method_details?.card?.three_d_secure || null;
  if (!THREE_DS_PASSED.has(tds?.result)) {
    await stripe.paymentIntents
      .cancel(pi.id, { cancellation_reason: "requested_by_customer" }, {
        idempotencyKey: `topup_no3ds_${pi.id}`,
      })
      .catch(() => {});

    updateTable(
      table.id,
      { topUp: { ...topUp, status: "declined" } },
      `Top-up of ${(pi.amount / 100).toFixed(2)} ${cur} REFUSED — card not verified with 3-D Secure (${
        tds?.result || "no authentication"
      }). Authorization released, nothing added to the table.`
    );

    return NextResponse.json(
      {
        error:
          "Your card could not be verified with 3-D Secure, so nothing was reserved. Ask a member of staff — they can send a new request or take the difference in cash.",
        code: "three_ds_required",
      },
      { status: 402 }
    );
  }

  // The hold is appended to the stack as it is NOW. Building the array
  // from the read taken before the 3DS round-trip — which can sit for a
  // minute while the bank asks the guest for a code — would drop anything
  // the waiter rang in meanwhile.
  //
  // Guarded on the PaymentIntent id as well, so a guest who taps the
  // approve link twice, or reloads it after finishing, does not get the
  // same authorization recorded against the table twice.
  let total = 0;
  const updated = mutateTable(table.id, (t) => {
    const existing = t.holds || [];
    if (existing.some((h) => h.paymentIntentId === pi.id)) return null;

    const holds = [
      ...existing,
      { paymentIntentId: pi.id, amountCents: pi.amount, capturedCents: null, status: "open" },
    ];
    total = holds.filter((h) => h.status === "open").reduce((s, h) => s + h.amountCents, 0);

    return {
      holds,
      holdAmountCents: total,
      topUp: { ...t.topUp, status: "done", approvedAt: new Date().toISOString() },
    };
  }, `Guest approved a further ${(pi.amount / 100).toFixed(2)} ${cur} (3-D Secure: ${tds.result}${
    tds.authentication_flow ? `, ${tds.authentication_flow}` : ""
  })`);

  // null means it was already recorded — a replay, not a failure.
  if (!updated) {
    const fresh = getTable(table.id);
    return NextResponse.json({ ok: true, alreadyDone: true, authorizedCents: fresh.holdAmountCents });
  }

  return NextResponse.json({ ok: true, table: updated, authorizedCents: total });
}

// ---------- cash, handed over at the table ----------
//
// The other way to cover a growing tab, and it needs no card, no link, no
// 3-D Secure and no waiting: the guest gives the waiter notes. There is
// nothing to re-check because the money is already in the till — that is
// the entire difference between this and a hold.
//
// It is recorded against the table so close-out captures the REMAINDER
// from the card rather than the whole bill. Skipping that step would
// charge the guest twice for the same drinks.
async function takeCash(table, { amountCents }) {
  const denied = staffOnly();
  if (denied) return denied;
  const actor = currentStaff();

  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }

  const amount = Math.round(Number(amountCents));
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Amount must be positive" }, { status: 400 });
  }

  const cur = table.currency.toUpperCase();
  const already = table.cashAmountCents || 0;

  // Spain caps cash at 1.000 € when one party is a business (Ley 11/2021).
  // The cap is on the TOTAL for this table, not on each handover —
  // otherwise three payments of 400 walk straight through a 1.000 limit,
  // which is precisely the structuring the law exists to stop. Enforced
  // here rather than in the UI, because the manager who wants the sale is
  // exactly the person who would call the endpoint directly.
  const room = CASH_LIMIT_CENTS - already;
  if (amount > room) {
    return NextResponse.json(
      {
        error:
          room <= 0
            ? `This table has already taken the legal maximum of ${(
                CASH_LIMIT_CENTS / 100
              ).toFixed(2)} ${cur} in cash (Ley 11/2021). The rest has to go on the card.`
            : `Cash on one table is capped at ${(CASH_LIMIT_CENTS / 100).toFixed(
                2
              )} ${cur} by law (Ley 11/2021) and ${(already / 100).toFixed(
                2
              )} ${cur} has already been taken. Accept at most ${(room / 100).toFixed(
                2
              )} ${cur} more in notes.`,
        code: "cash_limit",
        maxCashCents: Math.max(0, room),
      },
      { status: 400 }
    );
  }

  // Accumulated inside the transaction, and the legal cap re-checked
  // there. Two waiters taking notes at the same table at the same moment
  // would otherwise each write `already + amount` from their own read —
  // one handover vanishes from the till, and the 1.000 € cap could be
  // walked straight past.
  let overCap = null;
  let total = 0;
  const updated = mutateTable(
    table.id,
    (t) => {
      const taken = t.cashAmountCents || 0;
      if (taken + amount > CASH_LIMIT_CENTS) {
        overCap = {
          error: `Cash on one table is capped at ${(CASH_LIMIT_CENTS / 100).toFixed(
            2
          )} ${cur} by law (Ley 11/2021) and ${(taken / 100).toFixed(
            2
          )} ${cur} has already been taken.`,
          code: "cash_limit",
          maxCashCents: Math.max(0, CASH_LIMIT_CENTS - taken),
        };
        return null;
      }
      total = taken + amount;
      return { cashAmountCents: total };
    },
    () =>
      `Took ${(amount / 100).toFixed(2)} ${cur} in cash — comes off the card at close-out`,
    actor
  );

  if (!updated) return NextResponse.json(overCap, { status: 400 });

  return NextResponse.json({ ok: true, table: updated, cashCents: total });
}

// ---------- staff withdraw the ask ----------

async function cancelRequest(table) {
  const denied = staffOnly();
  if (denied) return denied;
  const actor = currentStaff();

  if (!table.topUp || table.topUp.status !== "pending") {
    return NextResponse.json({ error: "No pending request" }, { status: 400 });
  }

  const updated = updateTable(
    table.id,
    { topUp: { ...table.topUp, status: "cancelled" } },
    `Top-up request withdrawn by staff`,
    actor
  );
  return NextResponse.json({ ok: true, table: updated });
}
