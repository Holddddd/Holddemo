import { NextResponse } from "next/server";
import { getTable, mutateTable } from "@/lib/db";
import { canSeeBooking, isStaff } from "@/lib/auth";
import { MENU } from "@/lib/menu";
import { checkCoverage } from "@/lib/coverage";

// One endpoint, two callers: a waiter tapping the item on /staff, and the
// guest ordering from their own phone on /table/[id]. Both are stand-ins
// for the POS webhook the README calls for — `by` is recorded so the
// activity log can tell the two apart during a dispute.
export async function POST(req) {
  // A table has exactly one card — the one saved at booking — so a line is
  // simply a line. There is no per-person division to record.
  const { tableId, itemId, bookingToken } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }

  // Ordering puts money on someone's card, so the caller is either signed
  // in as staff or holding this booking's token.
  if (!canSeeBooking(table, bookingToken)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }
  const item = MENU.find((m) => m.id === itemId);
  if (!item) {
    return NextResponse.json({ error: "Unknown menu item" }, { status: 400 });
  }

  // Who is ringing this in is decided HERE, from the session — it used to
  // arrive in the request body as `by`, which meant a guest's phone could
  // label its own order "staff" and the activity log would repeat it back
  // during a dispute. The log is only worth having if it cannot be dictated
  // by the party it might be used against.
  const by = isStaff() ? "staff" : "guest";
  const cur = table.currency.toUpperCase();

  // EVERYTHING BELOW RUNS INSIDE THE TRANSACTION.
  //
  // The previous version read the orders array, appended to it and wrote
  // the whole thing back. Two taps at the same moment — a waiter's tablet
  // and the guest's phone, which is a completely ordinary Saturday — both
  // read the same array and the second write erased the first. The club
  // poured a bottle it never billed for.
  //
  // The coverage check moves in here too, for the same reason: checked
  // against a stale tab it can wave through a line that takes the table
  // past what the card can pay.
  let refusal = null;
  let newTotal = 0;

  const updated = mutateTable(
    tableId,
    (t) => {
      if (t.status !== "checked_in") {
        refusal = {
          body: { error: `Table is in status "${t.status}", expected "checked_in"` },
          status: 400,
        };
        return null;
      }

      const orders = [...(t.orders || []), { ...item, at: new Date().toISOString(), by }];
      const tabAmountCents = orders.reduce((sum, o) => sum + o.priceCents, 0);

      const denied = checkCoverage(t, tabAmountCents);
      if (denied) {
        refusal = {
          body: { ...denied, error: `${item.name}: ${denied.error}` },
          status: 409,
        };
        return null;
      }

      newTotal = tabAmountCents;
      return { orders, tabAmountCents };
    },
    () =>
      `${by === "guest" ? "Guest ordered" : "Ordered"} ${item.name} (+${(
        item.priceCents / 100
      ).toFixed(2)} ${cur}) — tab now ${(newTotal / 100).toFixed(2)} ${cur}`
  );

  if (!updated) {
    return NextResponse.json(refusal.body, { status: refusal.status });
  }

  return NextResponse.json({ ok: true, table: updated });
}
