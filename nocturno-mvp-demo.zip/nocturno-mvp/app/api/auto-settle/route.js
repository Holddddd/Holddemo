import { NextResponse } from "next/server";
import { staffOrCron, isCron, currentStaff } from "@/lib/auth";
import { getTables, updateTable, resetTable, sumOpenHolds, closeShift, getShift } from "@/lib/db";
import { settleHolds, releaseHolds } from "@/lib/settle";
import {
  IDLE_SETTLE_MINUTES,
  AUTO_SETTLE_TIP_CENTS,
  PENDING_CARD_TIMEOUT_MINUTES,
} from "@/lib/config";
import { isPastCheckinCutoff, cutoffLabel } from "@/lib/nightclock";

// The 03:37 problem: a table gets up and leaves, and the money sits in an
// authorization until it expires because nobody found a waiter.
//
// This sweeps tables that have gone quiet and settles them against what
// they actually ordered. Two rules it will not break:
//
//   1. It never adds a tip (AUTO_SETTLE_TIP_CENTS). Charging a gratuity to
//      someone who never pressed anything is not a default.
//   2. A table that ordered nothing is RELEASED, not captured. An idle
//      table with an empty tab is a no-show, and no-shows don't get billed
//      just because a timer fired.
//
// Deliberately a pull, not a background timer inside the web process: a
// setInterval in a Next.js server is lost on every restart and duplicated
// on every extra instance. Real deployments point a cron at this route.
export async function POST(req) {
  // The one route a scheduler may drive. Everything else stays
  // staff-only, so a leaked CRON_SECRET can settle tables on the schedule
  // it was already going to settle them on — and nothing else.
  const denied = staffOrCron(req);
  if (denied) return denied;

  // The log has to say a robot did this. "Auto-settled" with a manager's
  // name against it is a worse record than no name at all.
  const actor = isCron(req) ? "cron" : currentStaff();

  const body = await req.json().catch(() => ({}));
  const endOfShift = body.action === "close-shift";
  const idleMs = (body.idleMinutes ?? IDLE_SETTLE_MINUTES) * 60 * 1000;
  const now = Date.now();

  const settled = [];
  const released = [];
  const failed = [];
  const expired = [];

  // Bookings that never walked in. Past 01:00 a reservation stops being a
  // reservation, and the table goes back on the floor so it can be sold to
  // somebody physically standing at the door.
  //
  // Nothing is charged, and that is the honest gap in this MVP rather than
  // a design choice: no hold exists yet at this point in the flow, because
  // the authorization is placed at CHECK-IN, not at booking. A no-show
  // costs the club the table and nothing else until the hold moves to
  // booking time.
  // Half-finished bookings. Somebody opened the booking link, the table
  // went "card pending" so nobody else could take it, and then they closed
  // the tab. Ten minutes later it goes back on the floor — this runs on
  // every sweep, not only after the cutoff, because an unsellable table at
  // 23:00 is the expensive version of this.
  const stale = [];
  for (const t of getTables()) {
    if (t.status !== "pending_card") continue;
    const since = t.pendingSince ? now - new Date(t.pendingSince).getTime() : Infinity;
    if (since < PENDING_CARD_TIMEOUT_MINUTES * 60 * 1000) continue;

    resetTable(t.id);
    stale.push(t.id);
  }

  const cutoffPassed = isPastCheckinCutoff();
  if (cutoffPassed || endOfShift) {
    for (const t of getTables()) {
      if (t.status !== "card_saved" && t.status !== "pending_card") continue;

      updateTable(
        t.id,
        { status: "cancelled", cancelReason: "Didn't arrive" },
        `Auto-released — no arrival by ${cutoffLabel()}, table returned to the floor`,
        actor
      );
      expired.push(t.id);
    }
  }

  for (const t of getTables()) {
    if (t.status !== "checked_in") continue;

    const since = t.lastActivityAt ? now - new Date(t.lastActivityAt).getTime() : 0;
    // At end of shift everything open is in scope; otherwise only the
    // tables that have actually gone quiet.
    if (!endOfShift && since < idleMs) continue;

    const tab = t.tabAmountCents || 0;
    const cur = t.currency.toUpperCase();
    const reason = endOfShift ? "shift closed" : `idle ${Math.round(since / 60000)} min`;

    try {
      if (tab <= 0) {
        const { holds } = await releaseHolds(t);
        updateTable(
          t.id,
          { status: "cancelled", cancelReason: "Left without ordering", holds, holdAmountCents: 0 },
          `Auto-released — ${reason}, nothing ordered`,
          actor
        );
        released.push(t.id);
        continue;
      }

      const capped = Math.min(tab, sumOpenHolds(t));
      const { holds, captured } = await settleHolds(t, capped);

      updateTable(
        t.id,
        {
          status: "closed",
          holds,
          holdAmountCents: 0,
          capturedAmountCents: captured,
          tipAmountCents: AUTO_SETTLE_TIP_CENTS,
        },
        `Auto-settled — ${reason}, captured ${(captured / 100).toFixed(2)} ${cur}${
          capped < tab
            ? ` (tab was ${(tab / 100).toFixed(2)} — SHORT by ${((tab - capped) / 100).toFixed(2)}, hold didn't cover it)`
            : ""
        }`,
        actor
      );
      settled.push({ tableId: t.id, capturedCents: captured, shortCents: tab - capped });
    } catch (err) {
      // One table failing must not stop the sweep — the rest of the floor
      // still needs closing.
      updateTable(t.id, {}, `Auto-settle FAILED: ${err.message}`, actor);
      failed.push({ tableId: t.id, error: err.message });
    }
  }

  const shift = endOfShift ? closeShift() : getShift();
  return NextResponse.json({ ok: true, shift, settled, released, failed, expired, stale });
}
