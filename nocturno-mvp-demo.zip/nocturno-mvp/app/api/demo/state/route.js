import { NextResponse } from "next/server";
import {
  allTables,
  getTable,
  openTable,
  addLine,
  removeLast,
  closeTable,
  resetAll,
} from "@/lib/demo/store";

// The demo's shared state. No auth on purpose — the staff PIN in this
// demo is a stage prop, not a security boundary, and nothing here can
// touch real money or the real database.

export async function GET(req) {
  const id = new URL(req.url).searchParams.get("tableId");
  if (id) {
    const t = getTable(id);
    return t
      ? NextResponse.json({ table: t })
      : NextResponse.json({ error: "Not found" }, { status: 404 });
  }
  return NextResponse.json({ tables: allTables() });
}

export async function POST(req) {
  const { action, tableId, line } = await req.json().catch(() => ({}));

  switch (action) {
    case "open":
      return NextResponse.json({ table: openTable(tableId) });
    case "add":
      return NextResponse.json({ table: addLine(tableId, line) });
    case "undo":
      return NextResponse.json({ table: removeLast(tableId) });
    case "close":
      return NextResponse.json({ table: closeTable(tableId) });
    case "reset":
      return NextResponse.json({ tables: resetAll() });
    default:
      return NextResponse.json({ error: "unknown action" }, { status: 400 });
  }
}
