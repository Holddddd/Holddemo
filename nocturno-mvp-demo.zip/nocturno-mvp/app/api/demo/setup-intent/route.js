import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";

// The demo's one and only Stripe call.
//
// A SetupIntent moves no money — it has no `amount` field at all — so this
// stays inside "stage 1, no real transactions" while still giving the card
// form something genuine to talk to.
//
// The alternative was a hand-drawn card input, which is not an option: at a
// sales meeting somebody will type a real card number into it, and a card
// field that isn't Stripe's iframe means the number crosses our server. It
// never does here — Stripe Elements posts straight to Stripe, and the only
// thing that comes back to us is an identifier.
export async function POST() {
  try {
    const setupIntent = await stripe.setupIntents.create({
      payment_method_types: ["card"],
      metadata: { demo: "true" },
    });
    return NextResponse.json({ clientSecret: setupIntent.client_secret });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
