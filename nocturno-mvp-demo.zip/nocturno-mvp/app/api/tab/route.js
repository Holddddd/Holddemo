import { NextResponse } from "next/server";
import { staffOnly, currentStaff } from "@/lib/auth";
import { getTable, mutateTable } from "@/lib/db";
import { checkCoverage } from "@/lib/coverage";
import { ADJUSTMENT_ID } from "@/lib/menu";

// Staff correcting the running total by hand — a comped bottle, a
// breakage, something rung in on the wrong table. In production the tab
// comes from a POS webhook and this form doesn't exist.
//
// The correction is stored as an ADJUSTMENT LINE inside orders, not as an
// overwrite of the total. Overwriting looked simpler and was wrong: the
// tab is recomputed from orders every time anything is ordered, so the
// next tap — by a waiter or by the guest on their own phone — silently
// erased whatever the correction had been. Now the total is always the
// sum of the lines, and the correction is one of the lines.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  // Stamped onto every log line this request writes, so the record
  // says who did it and not merely that somebody did.
  const actor = currentStaff();

  const { tableId, tabAmountCents } = await req.json().catch(() => ({}));

  const t = getTable(tableId);
  if (!t) return NextResponse.json({ error: "Table not found" }, { status: 404 });
  if (typeof tabAmountCents !== "number" || tabAmountCents < 0) {
    return NextResponse.json({ error: "Invalid tab amount" }, { status: 400 });
  }

  // Recomputed INSIDE the transaction, against the row as it is at that
  // instant. Built outside it, this patch rewrites the whole orders array
  // from a copy read moments earlier — so a bottle rung in while the
  // manager was typing vanishes the moment they press save.
  //
  // The coverage check belongs in here for the same reason: a hand-typed
  // total is still the easiest way to push a table past what its card can
  // pay, and checking it against a stale tab is not checking it.
  let refusal = null;
  let logLine = "";

  const updated = mutateTable(
    tableId,
    (t) => {
      const overCovered = checkCoverage(t, tabAmountCents);
      if (overCovered) {
        refusal = { body: overCovered, status: 409 };
        return null;
      }

      // Drop any previous adjustment first, so corrections replace each
      // other instead of stacking up into nonsense.
      const realOrders = (t.orders || []).filter((o) => o.id !== ADJUSTMENT_ID);
      const orderedTotal = realOrders.reduce((sum, o) => sum + o.priceCents, 0);
      const delta = tabAmountCents - orderedTotal;

      const orders =
        delta === 0
          ? realOrders
          : [
              ...realOrders,
              {
                id: ADJUSTMENT_ID,
                name: "Manual adjustment",
                priceCents: delta,
                at: new Date().toISOString(),
                by: "staff",
              },
            ];

      const cur = t.currency.toUpperCase();
      logLine = `Tab set to ${(tabAmountCents / 100).toFixed(2)} ${cur} by hand (${
        delta === 0
          ? "no adjustment needed"
          : `${delta > 0 ? "+" : "−"}${Math.abs(delta / 100).toFixed(2)} ${cur} adjustment`
      })`;

      return { orders, tabAmountCents };
    },
    () => logLine,
    actor
  );

  if (!updated) {
    return NextResponse.json(refusal.body, { status: refusal.status });
  }

  return NextResponse.json({ ok: true, table: updated });
}
