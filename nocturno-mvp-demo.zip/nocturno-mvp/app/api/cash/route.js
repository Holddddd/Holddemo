import { NextResponse } from "next/server";
import { staffOnly } from "@/lib/auth";
import {
  getTable,
  updateTable,
  mutateTable,
  sumOpenHolds,
  claimSettlement,
} from "@/lib/db";
import { settleHolds } from "@/lib/settle";
import { cashSplit, settlementPlan } from "@/lib/deposit";
import { CASH_LIMIT_CENTS } from "@/lib/config";
import { notifyGuest, billClosedMessage } from "@/lib/notify";

// Screen 8 — settle a table with notes, card, or both.
//
// The cash cap is enforced HERE, not only in the UI. A disabled button is
// a suggestion: anyone with the tab open can call this endpoint directly,
// and the manager who wants the sale is exactly the person who would.
// Above the legal limit the request is refused outright and told what the
// lawful split would be.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  const { tableId, billCents, cashCents = 0 } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });
  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }
  if (!Number.isFinite(billCents) || billCents <= 0) {
    return NextResponse.json({ error: "Invalid bill amount" }, { status: 400 });
  }
  // The notes figure was taken on trust while the bill next to it was
  // checked. A negative or non-numeric value feeds the split and the
  // settlement plan straight through to a Stripe capture.
  if (!Number.isFinite(cashCents) || cashCents < 0) {
    return NextResponse.json({ error: "Invalid cash amount" }, { status: 400 });
  }

  const cur = table.currency.toUpperCase();
  const split = cashSplit(billCents, cashCents);

  if (split.overLimit) {
    return NextResponse.json(
      {
        error: `Cash is capped at ${(CASH_LIMIT_CENTS / 100).toFixed(
          2
        )} ${cur} by law when a business is being paid. Take at most ${(
          split.maxCashCents / 100
        ).toFixed(2)} ${cur} in notes and the remaining ${(
          (billCents - split.maxCashCents) / 100
        ).toFixed(2)} ${cur} on the card.`,
        maxCashCents: split.maxCashCents,
        cardCents: billCents - split.maxCashCents,
        overLimit: true,
      },
      { status: 400 }
    );
  }

  const authorized = sumOpenHolds(table);
  const deposit = table.depositAmountCents || 0;
  const plan = settlementPlan({
    billCents,
    depositCents: deposit,
    authorizedCents: authorized,
    cashCents: split.cashCents,
  });

  // Same race as every other close-out path: the status check above ran
  // before a network call. See claimSettlement.
  if (!claimSettlement(tableId)) {
    return NextResponse.json(
      { error: "This table is already being closed.", code: "settlement_in_progress" },
      { status: 409 }
    );
  }

  try {
    // settleHolds walks the stack; a capture of 0 releases everything,
    // which is exactly right when notes and deposit covered the bill.
    const { holds, captured, failure, shortCents } = await settleHolds(table, plan.captureCents);

    const updated = mutateTable(
      tableId,
      () => ({
        status: failure ? "checked_in" : "closed",
        settlingAt: null,
        holds,
        holdAmountCents: failure ? sumOpenHolds({ holds }) : 0,
        cashAmountCents: split.cashCents,
        capturedAmountCents: captured,
      }),
      `${failure ? "PARTIAL close-out" : "Closed"} — bill ${(billCents / 100).toFixed(2)} ${cur}: ${(
        deposit / 100
      ).toFixed(2)} deposit + ${(split.cashCents / 100).toFixed(2)} cash + ${(
        captured / 100
      ).toFixed(2)} card, ${(plan.releaseCents / 100).toFixed(2)} released${
        plan.shortfallCents
          ? `, SHORTFALL ${(plan.shortfallCents / 100).toFixed(2)} still owed`
          : ""
      }${
        failure
          ? ` — STOPPED before the card leg finished, nothing released: ${failure.message}`
          : ""
      }`
    );

    if (failure) {
      return NextResponse.json(
        {
          error: `The notes are recorded, but only ${(captured / 100).toFixed(
            2
          )} ${cur} could be taken from the card — ${failure.message}. ${(
            shortCents / 100
          ).toFixed(2)} ${cur} is still owed.`,
          capturedCents: captured,
          shortCents,
          partial: true,
        },
        { status: 402 }
      );
    }

    const note = await notifyGuest(
      updated,
      billClosedMessage(updated, {
        capturedCents: captured,
        releasedCents: plan.releaseCents,
      })
    );

    return NextResponse.json({ ok: true, table: updated, plan, notification: note });
  } catch (err) {
    updateTable(
      tableId,
      { settlingAt: null },
      `CASH CLOSE-OUT FAILED — card leg declined: ${err.message}`
    );
    return NextResponse.json(
      { error: `The card part of this bill was declined: ${err.message}`, failed: true },
      { status: 402 }
    );
  }
}
