import QRCode from "qrcode";
import { getTable } from "@/lib/db";

// The PERMANENT code that lives on the table — printed once, glued to the
// furniture, scanned by whoever sits down. Distinct from
// /api/checkin-qr/[tableId], which is a per-booking code on the guest's
// confirmation and carries a one-night token.
//
// This one deliberately carries NO token: it is physically attached to a
// table in a room the guest had to get into, and it has to keep working
// next Saturday for a different group. Possession of the printed code is
// the only claim it makes — which is exactly why the page it opens starts
// a NEW session and can never show the previous guests' bill.
export async function GET(req, { params }) {
  const table = getTable(params.tableId);
  if (!table) return new Response("Table not found", { status: 404 });

  const origin = new URL(req.url).origin;

  // Dark-on-light and a chunky error-correction level: this gets printed,
  // stuck to a table, and scanned in the dark by a phone at an angle.
  const svg = await QRCode.toString(`${origin}/t/${table.id}`, {
    type: "svg",
    margin: 2,
    errorCorrectionLevel: "H",
    color: { dark: "#000000", light: "#FFFFFF" },
  });

  return new Response(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
      "Cache-Control": "public, max-age=86400",
    },
  });
}
