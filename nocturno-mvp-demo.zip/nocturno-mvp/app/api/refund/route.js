import { NextResponse } from "next/server";
import crypto from "crypto";
import { staffOnly, currentStaff } from "@/lib/auth";
import { stripe } from "@/lib/stripe";
import { getTable, updateTable, mutateTable } from "@/lib/db";

// Giving money back after it has been taken.
//
// This is the one money movement the app had no answer for, and the gap
// was not cosmetic: every other "undo" here is a RELEASE — an
// authorization that is simply never captured, which costs the club
// nothing and reaches the guest within hours. Once a capture has
// happened, releasing is no longer available. The money is in the club's
// balance and the only way back out is a refund, which takes days, shows
// on the guest's statement as a return, and — unlike a release — usually
// does not give the card fee back.
//
// Refunds are staff-only and always partial-capable: the common case is
// not "undo the whole night", it is "we charged for a bottle that was
// never opened".
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  const actor = currentStaff();
  const { tableId, amountCents, reason = "" } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }

  const captured = table.capturedAmountCents || 0;
  const already = table.refundedAmountCents || 0;
  const refundable = captured - already;
  const cur = table.currency.toUpperCase();

  if (captured <= 0) {
    return NextResponse.json(
      {
        error:
          "Nothing was captured on this table, so there is nothing to refund. An open hold is released, not refunded — cancel the table instead.",
      },
      { status: 400 }
    );
  }

  const amount = Math.round(Number(amountCents));
  if (!Number.isFinite(amount) || amount <= 0) {
    return NextResponse.json({ error: "Refund amount must be positive" }, { status: 400 });
  }
  if (amount > refundable) {
    return NextResponse.json(
      {
        error: `Only ${(refundable / 100).toFixed(2)} ${cur} is refundable — ${(
          captured / 100
        ).toFixed(2)} was charged and ${(already / 100).toFixed(2)} has already gone back.`,
      },
      { status: 400 }
    );
  }

  // Walk the captured holds and refund across them, because the money may
  // have been taken over several PaymentIntents — the same reason
  // settlement walks the stack rather than assuming one.
  const holds = [...(table.holds || [])];
  let remaining = amount;
  const receipts = [];

  try {
    for (let i = 0; i < holds.length && remaining > 0; i++) {
      const h = holds[i];
      if (h.status !== "captured") continue;

      const takenHere = h.capturedCents || 0;
      const refundedHere = h.refundedCents || 0;
      const canTake = takenHere - refundedHere;
      if (canTake <= 0) continue;

      const take = Math.min(canTake, remaining);
      const refund = await stripe.refunds.create(
        { payment_intent: h.paymentIntentId, amount: take },
        // Keyed on the intent and the running total so a double-tapped
        // button replays the same refund instead of issuing a second one.
        { idempotencyKey: `ref_${h.paymentIntentId}_${refundedHere + take}` }
      );

      holds[i] = { ...h, refundedCents: refundedHere + refund.amount };
      remaining -= refund.amount;
      receipts.push(`${(refund.amount / 100).toFixed(2)} on ${h.paymentIntentId}`);
    }

    if (remaining > 0) {
      // Should be unreachable — `refundable` is derived from these same
      // holds — but returning a partial refund silently would be worse
      // than saying so.
      return NextResponse.json(
        {
          error: `Refunded ${((amount - remaining) / 100).toFixed(
            2
          )} ${cur} but ${(remaining / 100).toFixed(
            2
          )} could not be placed against any charge. Check this table in Stripe.`,
        },
        { status: 500 }
      );
    }

    const entry = {
      id: `rf_${crypto.randomBytes(5).toString("hex")}`,
      amountCents: amount,
      reason: String(reason).slice(0, 200) || null,
      at: new Date().toISOString(),
      by: actor,
    };

    // Recorded from the row as it is NOW, not as it was before the refund
    // round-trip. Two refunds issued at once would otherwise each write
    // `already + amount` from their own stale read, and the second would
    // erase the first — Stripe would have sent both, our books only one.
    // The refunded amounts are applied ONTO the row as it stands now,
    // rather than writing back the `holds` array captured before the
    // Stripe round-trip. That array is already stale — a capture or a
    // top-up landing during the refund would be erased by it — and this
    // route was only half-protected: the running total was computed from
    // the live row while the holds beside it were not.
    const refundedByIntent = new Map(
      holds.filter((h) => h.refundedCents).map((h) => [h.paymentIntentId, h.refundedCents])
    );

    const updated = mutateTable(
      tableId,
      (t) => ({
        holds: (t.holds || []).map((h) =>
          refundedByIntent.has(h.paymentIntentId)
            ? { ...h, refundedCents: refundedByIntent.get(h.paymentIntentId) }
            : h
        ),
        refunds: [...(t.refunds || []), entry],
        refundedAmountCents: (t.refundedAmountCents || 0) + amount,
      }),
      `Refunded ${(amount / 100).toFixed(2)} ${cur}${reason ? ` — ${reason}` : ""} [${receipts.join(
        "; "
      )}]`,
      actor
    );

    return NextResponse.json({ ok: true, table: updated, refundedCents: amount });
  } catch (err) {
    updateTable(
      tableId,
      {},
      `REFUND FAILED (${(amount / 100).toFixed(2)} ${cur}): ${err.message}`,
      actor
    );
    return NextResponse.json({ error: err.message }, { status: 402 });
  }
}
