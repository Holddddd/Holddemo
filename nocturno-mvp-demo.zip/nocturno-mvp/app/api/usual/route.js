import { NextResponse } from "next/server";
import { getTable, updateTable, mutateTable } from "@/lib/db";
import { checkCoverage } from "@/lib/coverage";
import { canSeeBooking } from "@/lib/auth";
import { getProfile, usualOrder } from "@/lib/customers";
import { MENU } from "@/lib/menu";

// GET — what this guest usually drinks, if the venue has seen them before.
// Returns null rather than a guess: a first-time guest has no usual, and
// inventing one is the kind of fake personalisation people notice.
export async function GET(req) {
  const url = new URL(req.url);
  const tableId = url.searchParams.get("tableId");
  const table = getTable(tableId);
  if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });
  if (!canSeeBooking(table, url.searchParams.get("t"))) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }

  const profile = getProfile(table.customerKey);
  const usual = usualOrder(profile);

  return NextResponse.json({
    usual,
    visits: profile?.visits || 0,
    guestName: profile?.guestName || null,
  });
}

// POST — ring the whole usual set in one tap.
export async function POST(req) {
  const { tableId, bookingToken } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });
  if (!canSeeBooking(table, bookingToken)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }
  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }

  const usual = usualOrder(getProfile(table.customerKey));
  if (!usual) return NextResponse.json({ error: "No usual on file" }, { status: 400 });

  // Prices come from today's MENU, never from the remembered profile — a
  // saved price is a stale price, and charging last month's number for
  // tonight's bottle is a dispute waiting to happen.
  const lines = [];
  for (const want of usual.items) {
    const item = MENU.find((m) => m.id === want.id);
    if (!item) continue; // dropped from the menu since their last visit
    for (let i = 0; i < want.qty; i++) {
      lines.push({ ...item, at: new Date().toISOString(), by: "guest" });
    }
  }

  if (!lines.length) {
    return NextResponse.json(
      { error: "Nothing from that order is on tonight's menu" },
      { status: 400 }
    );
  }

  const addedCents = lines.reduce((s, l) => s + l.priceCents, 0);
  const cur = table.currency.toUpperCase();

  // Appended to the order list as it stands INSIDE the transaction, and
  // the coverage ceiling is re-checked there too. Both matter: the profile
  // lookup above is an await, so a waiter can ring in a bottle between the
  // read and this write — which would both lose their line and let the tab
  // slip past what the card covers.
  let overCovered = null;
  const updated = mutateTable(
    tableId,
    (t) => {
      const orders = [...(t.orders || []), ...lines];
      const tabAmountCents = orders.reduce((sum, o) => sum + o.priceCents, 0);

      overCovered = checkCoverage(t, tabAmountCents);
      if (overCovered) return null;

      return { orders, tabAmountCents };
    },
    `Guest re-ordered the usual — ${lines.length} item(s), +${(addedCents / 100).toFixed(
      2
    )} ${cur}`
  );

  if (!updated) return NextResponse.json(overCovered, { status: 409 });

  return NextResponse.json({ ok: true, table: updated });
}
