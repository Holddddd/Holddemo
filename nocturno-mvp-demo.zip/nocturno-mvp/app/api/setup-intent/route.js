import { NextResponse } from "next/server";
import { rateLimit, clientKey } from "@/lib/ratelimit";
import { stripe } from "@/lib/stripe";
import { getTable, getTables, updateTable, resetTable } from "@/lib/db";
import { newBookingToken } from "@/lib/auth";
import { profileKey } from "@/lib/customers";

// Step 1 of the flow: guest lands on the booking confirmation page and this
// route creates a Customer + SetupIntent so their card can be verified and
// stored WITHOUT charging anything. This is the "$0 check" step.
export async function POST(req) {
  // Open to the world by necessity — a guest booking a table has not
  // signed in and cannot. Loose on purpose: a flood is hundreds of
  // requests a minute, and squatting is bounded below, not here.
  const limited = rateLimit(req, {
    name: "booking",
    limit: Number(process.env.RATE_LIMIT_BOOKING) || 30,
  });
  if (limited) {
    return NextResponse.json(limited, {
      status: 429,
      headers: { "Retry-After": String(limited.retryAfterSeconds) },
    });
  }

  const { tableId, guestName, guestPhone, guestEmail } = await req.json().catch(() => ({}));

  // ONE UNCONFIRMED BOOKING PER CALLER.
  //
  // Rate limiting cannot solve table-squatting: taking the whole floor
  // needs nine requests over ten minutes, far slower than any limit worth
  // setting would trip on. What bounds it is how many tables one caller
  // may hold at once.
  //
  // Refusing the second attempt was the first instinct and it was wrong —
  // a guest comparing Mesa 3, then 6, then 7 is ordinary behaviour, and
  // locking them out punishes the exact person the page exists for.
  // Releasing their PREVIOUS table instead is friendlier and stricter at
  // the same time: one held table per caller, and switching costs nothing.
  const caller = clientKey(req);
  for (const other of getTables()) {
    if (other.id === tableId) continue;
    if (other.status !== "pending_card") continue;
    if (other.pendingFromKey !== caller) continue;
    // Only ever their own half-finished booking, never a confirmed one.
    resetTable(other.id);
  }

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }
  if (!guestName || typeof guestName !== "string" || !guestName.trim()) {
    return NextResponse.json({ error: "Guest name is required" }, { status: 400 });
  }
  // Bounded before it is stored and before it is sent to Stripe. Nothing
  // upstream limited it, so a megabyte of text went into the row, into
  // every poll of the staff board, and out to Stripe as a customer name.
  const name = guestName.trim().slice(0, 120);

  // A table that is still running cannot take a new booking on top of the
  // old one.
  //
  // This is the bug that produced a table sitting at "booked" with a
  // 3.000 € tab nobody could pay: opening /book on a live table
  // overwrote the guest, the card and the token, while leaving the
  // previous night's orders and holds in place. The result belonged to
  // nobody — a new guest's name against an old guest's bill, and an
  // authorization that could no longer cover it.
  //
  // Staff clear a table with "Free up table" (which voids its holds) and
  // only then can it be re-booked.
  // `card_saved` belongs in this list and was missing from it, which was a
  // table-takeover anybody could perform: that status is a CONFIRMED
  // booking — a guest has verified a card, holds a QR code and expects a
  // table tonight — and an unauthenticated POST here overwrote the name,
  // the Stripe customer and the booking token. The first guest arrived to
  // a table that was no longer theirs and a link that had stopped working.
  if (
    table.status === "checked_in" ||
    table.status === "checking_in" ||
    table.status === "card_saved" ||
    (table.tabAmountCents || 0) > 0
  ) {
    return NextResponse.json(
      {
        error:
          "This table is still open from tonight. Staff need to close or free it up before it can be booked again.",
        code: "table_busy",
      },
      { status: 409 }
    );
  }

  try {
    const customer = await stripe.customers.create({
      name,
      metadata: { tableId },
    });

    const setupIntent = await stripe.setupIntents.create({
      customer: customer.id,
      payment_method_types: ["card"],
      usage: "off_session", // we WILL be charging this later without the guest present
      metadata: { tableId },
    });

    const booking = newBookingToken();
    // Hashed for the DURABLE profile — the long-lived customer record only
    // ever sees this, never the number.
    const customerKey = profileKey(guestPhone);

    updateTable(
      tableId,
      {
        guestName: name,
        // Starts the clock. The table is held from this moment, and the
        // sweep releases it if a card never lands — see
        // PENDING_CARD_TIMEOUT_MINUTES.
        pendingSince: new Date().toISOString(),
        pendingFromKey: caller,
        customerKey,
        // The raw number, for tonight only, so close-out has somewhere to
        // send the final amount. Wiped when the table is freed or reset.
        // See lib/notify.js for why it lives here and nowhere else.
        guestPhone: guestPhone ? String(guestPhone).trim() : null,
        // For the close-out receipt. Same one-night lifetime as the phone.
        guestEmail: guestEmail ? String(guestEmail).trim().slice(0, 200) : null,
        stripeCustomerId: customer.id,
        setupIntentId: setupIntent.id,
        status: "pending_card",
        ...booking.record,
      },
      `${name} started card verification`
    );

    return NextResponse.json({
      clientSecret: setupIntent.client_secret,
      publishableKey: process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY,
      // Handed back so the confirmation screen can build the guest's own
      // links. Only ever returned to the browser that created the booking.
      bookingToken: booking.bookingToken,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
