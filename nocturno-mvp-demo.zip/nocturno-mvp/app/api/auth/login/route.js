import { NextResponse } from "next/server";
import { findStaff, issueStaffToken, authConfigured, STAFF_COOKIE } from "@/lib/auth";
import { rateLimit } from "@/lib/ratelimit";

export async function POST(req) {
  // Ten guesses a minute against a four-digit PIN. The 400 ms pause below
  // slows a sequential attacker and does nothing at all to a parallel one,
  // which is the only kind worth planning for.
  const limited = rateLimit(req, { name: "login", limit: 10 });
  if (limited) {
    return NextResponse.json(limited, {
      status: 429,
      headers: { "Retry-After": String(limited.retryAfterSeconds) },
    });
  }

  const { pin } = await req.json().catch(() => ({}));

  if (!authConfigured()) {
    return NextResponse.json(
      {
        error:
          "Staff auth isn't configured. Set STAFF_PIN and AUTH_SECRET in .env.local and restart the server.",
      },
      { status: 503 }
    );
  }

  const user = findStaff(pin);
  if (!user) {
    // Deliberately vague, and deliberately slow enough that guessing a
    // 4-digit PIN over the network isn't free.
    await new Promise((r) => setTimeout(r, 400));
    return NextResponse.json({ error: "Wrong PIN" }, { status: 401 });
  }

  // The name comes back so the board can show who is signed in. Staff
  // sharing a tablet need to see whose name is about to land on the log
  // before they comp a bottle with it.
  const res = NextResponse.json({ ok: true, name: user.name });
  res.cookies.set(STAFF_COOKIE, issueStaffToken(user.name), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    // The demo runs over plain HTTP on localhost; anywhere else this must
    // be a secure cookie or the session is readable on the wire.
    secure: process.env.NODE_ENV === "production",
    maxAge: 12 * 60 * 60,
  });
  return res;
}
