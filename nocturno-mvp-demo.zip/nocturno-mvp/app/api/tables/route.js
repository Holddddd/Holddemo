import { NextResponse } from "next/server";
import { getTables, resetDB, resetTable, getTable } from "@/lib/db";
import { isStaff, staffOnly } from "@/lib/auth";

// The floor map is public — a guest picking a table hasn't signed in and
// hasn't booked yet — so this endpoint is readable by anyone. That makes
// what it returns a decision, not an afterthought: it used to hand out
// every guest's name plus the Stripe customer, setup-intent and payment-
// method ids to anybody who typed the URL.
//
// Public callers get only what it takes to draw the room and price it.
function publicView(t) {
  return {
    id: t.id,
    name: t.name,
    zone: t.zone,
    seats: t.seats,
    minSpendCents: t.minSpendCents,
    currency: t.currency,
    status: t.status,
  };
}

export async function GET() {
  const tables = getTables();
  // Signed-in staff get the real thing — the board needs holds, tabs,
  // orders and the activity log.
  return NextResponse.json({
    tables: isStaff() ? tables : tables.map(publicView),
  });
}

// Demo-only convenience, and both actions are destructive, so both are
// staff-only: reset wipes the floor, reopen frees someone's live table.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  const body = await req.json().catch(() => ({}));

  if (body.action === "reset") {
    const db = resetDB();
    return NextResponse.json({ tables: db.tables });
  }

  if (body.action === "reopen") {
    const table = getTable(body.tableId);
    if (!table) return NextResponse.json({ error: "Table not found" }, { status: 404 });
    const updated = resetTable(body.tableId);
    return NextResponse.json({ ok: true, table: updated });
  }

  return NextResponse.json({ error: "unknown action" }, { status: 400 });
}
