import { NextResponse } from "next/server";
import { staffOnly, currentStaff } from "@/lib/auth";
import {
  getTable,
  updateTable,
  mutateTable,
  sumOpenHolds,
  claimSettlement,
  releaseSettlement,
} from "@/lib/db";
import { settleHolds } from "@/lib/settle";
import { notifyGuest, billClosedMessage } from "@/lib/notify";
import { HOLD_LIFETIME_DAYS } from "@/lib/config";

// Step 4: the night is over, the real bill is known. Capture exactly that
// amount — across however many authorizations the table ended up needing.
// Anything held but not captured is released back to the guest's available
// balance by their bank automatically; the club never touches money it
// didn't actually earn.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  // Stamped onto every log line this request writes, so the record
  // says who did it and not merely that somebody did.
  const actor = currentStaff();

  const { tableId, finalAmountCents } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }
  if (table.status !== "checked_in") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "checked_in"` },
      { status: 400 }
    );
  }

  // Validated BEFORE the arithmetic below, because it feeds it. An
  // undefined or non-numeric amount used to flow straight through:
  // `Math.max(0, undefined - cash)` is NaN, NaN fails no comparison, and
  // settleHolds then treated every hold as "capture nothing" and CANCELLED
  // them — closing the table having taken not one cent.
  const finalCents = Math.round(Number(finalAmountCents));
  if (!Number.isFinite(finalCents) || finalCents < 0) {
    return NextResponse.json({ error: "Invalid bill amount" }, { status: 400 });
  }

  const authorized = sumOpenHolds(table);
  const cur = table.currency.toUpperCase();

  // Notes handed over during the night are already in the till. The card
  // owes the REMAINDER — charging the full bill on top of cash already
  // taken bills the guest twice for the same drinks.
  const cash = table.cashAmountCents || 0;
  const cardCents = Math.max(0, finalCents - cash);

  if (cardCents > authorized) {
    return NextResponse.json(
      {
        error: `${(cardCents / 100).toFixed(2)} ${cur} would have to come off the card${
          cash ? ` (bill ${(finalAmountCents / 100).toFixed(2)} less ${(cash / 100).toFixed(2)} cash)` : ""
        }, but only ${(authorized / 100).toFixed(
          2
        )} ${cur} is authorized. Raise the hold or take the difference in notes.`,
      },
      { status: 400 }
    );
  }

  // CLAIM THE TABLE BEFORE TALKING TO STRIPE.
  //
  // The status check above is not enough on its own: it ran before a
  // network round-trip, and a second request arriving during that trip
  // passes exactly the same check. Both would capture. See claimSettlement.
  if (!claimSettlement(tableId)) {
    return NextResponse.json(
      { error: "This table is already being closed.", code: "settlement_in_progress" },
      { status: 409 }
    );
  }

  try {
    const { holds, captured, notes, failure, shortCents } = await settleHolds(table, cardCents);
    // Nothing is released when the walk stopped early — the untouched
    // holds are still open on the guest's card. Reporting the difference
    // as "released" would tell staff money went back that never moved.
    const released = failure ? 0 : authorized - captured;

    // Written from the row as it is NOW. Building this patch from the
    // `table` read before the Stripe call would silently overwrite
    // anything that landed meanwhile — an order, a top-up, a refund.
    const updated = mutateTable(
      tableId,
      () => ({
        status: failure ? "checked_in" : "closed",
        settlingAt: null,
        holds,
        holdAmountCents: failure ? sumOpenHolds({ holds }) : 0,
        capturedAmountCents: captured,
        billAmountCents: finalCents,
      }),
      `${failure ? "PARTIAL close-out" : "Closed by staff"} — bill ${(finalCents / 100).toFixed(2)} ${cur}${
        cash ? `, ${(cash / 100).toFixed(2)} paid in cash` : ""
      }, captured ${(captured / 100).toFixed(2)} on the card of ${(authorized / 100).toFixed(
        2
      )} authorized, ${(released / 100).toFixed(2)} released [${notes.join("; ")}]${
        failure
          ? ` — STOPPED on ${failure.paymentIntentId}: ${failure.message}. ${(
              shortCents / 100
            ).toFixed(2)} ${cur} still owed.`
          : ""
      }`,
      actor
    );

    // The money that DID move is now on the row. Only then is the failure
    // reported, so nobody is ever told "it failed" about a capture that
    // partly succeeded without the books showing it.
    if (failure) {
      return NextResponse.json(
        {
          error: `Only ${(captured / 100).toFixed(2)} ${cur} could be taken — ${
            failure.message
          }. ${(shortCents / 100).toFixed(
            2
          )} ${cur} is still owed and the table is still open.`,
          capturedCents: captured,
          shortCents,
          partial: true,
        },
        { status: 402 }
      );
    }

    // Fire-and-forget by design: the money has already moved, and a
    // notification that fails must not turn a successful capture into an
    // error the staff have to re-run.
    const note = await notifyGuest(updated, billClosedMessage(updated, {
      capturedCents: captured,
      releasedCents: released,
    }));

    return NextResponse.json({
      ok: true,
      table: updated,
      capturedCents: captured,
      releasedCents: released,
      notification: note,
    });
  } catch (err) {
    // Two very different failures land here, and staff need to be able to
    // tell them apart before they decide whether to chase the guest.
    const expired =
      /expired|no longer available|already been captured|canceled/i.test(err.message);

    updateTable(
      tableId,
      {
        // Hand the table back so staff can retry immediately.
        settlingAt: null,
        captureFailed: { at: new Date().toISOString(), message: err.message, expired },
      },
      expired
        ? `CLOSE-OUT FAILED — the authorization is no longer valid (holds last ~${HOLD_LIFETIME_DAYS} days). Nothing was captured. Take payment another way: ${err.message}`
        : `CLOSE-OUT FAILED — bank declined the capture. Nothing may have been taken: ${err.message}`,
      actor
    );

    return NextResponse.json(
      {
        error: expired
          ? `The hold on this card has expired or been voided, so nothing could be captured. Take payment another way.`
          : `The bank declined the capture: ${err.message}. Check this table in Stripe before retrying.`,
        expired,
        failed: true,
      },
      { status: 402 }
    );
  }
}
