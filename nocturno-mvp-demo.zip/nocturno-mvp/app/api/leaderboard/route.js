import { NextResponse } from "next/server";
import { getLeaderboard, getShift } from "@/lib/db";

// Public, because the whole point is that it goes on a screen in the room.
//
// That makes what it leaves out the important part. It returns a table's
// own number (or a name the guests picked for themselves) and an amount —
// never the name on the card, never the phone, never anything that ties a
// number on a wall to a person who can be identified by it.
export async function GET(req) {
  const limit = Math.min(Number(new URL(req.url).searchParams.get("limit")) || 10, 25);
  const shift = getShift();

  return NextResponse.json({
    shift: { id: shift.id, startedAt: shift.startedAt, status: shift.status },
    leaderboard: getLeaderboard(limit),
  });
}
