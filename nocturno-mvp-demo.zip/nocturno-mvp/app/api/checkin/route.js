import { NextResponse } from "next/server";
import { staffOnly, currentStaff } from "@/lib/auth";
import { stripe } from "@/lib/stripe";
import { getTable, updateTable, mutateTable } from "@/lib/db";
import { isPastCheckinCutoff, cutoffLabel } from "@/lib/nightclock";

// Step 2: the guest has arrived at the club. Staff taps "check in" on the
// table. This is where the REAL money-relevant check happens: we place an
// authorization hold sized as a buffer above the table minimum, using the
// card saved at booking. The guest does not need to be present or touch
// their phone — the card was already verified with 3DS at booking, so this
// off-session authorization does not require them to re-authenticate.
//
// If the card can't cover the buffer, THIS is the moment staff find out —
// before a single bottle has been opened.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  // Stamped onto every log line this request writes, so the record
  // says who did it and not merely that somebody did.
  const actor = currentStaff();

  const { tableId, bufferMultiplier = 1.5, force = false } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }
  if (table.status !== "card_saved") {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", expected "card_saved"` },
      { status: 400 }
    );
  }

  // The door shuts at 01:00. Enforced here rather than only in the UI —
  // a cutoff that just greys out a button is a cutoff that gets clicked
  // through at 02:30 by whoever has the tablet.
  //
  // `force` is the manager override, and it is deliberately not silent:
  // turning away a guest who is standing at the door with a valid booking
  // is sometimes the wrong call, so the override exists — but it signs the
  // activity log, because "who let table 6 in at 3am" is a question that
  // gets asked the next morning.
  if (isPastCheckinCutoff() && !force) {
    return NextResponse.json(
      {
        error: `Arrivals closed at ${cutoffLabel()}. This booking is a no-show — release the table, or override if the manager is letting them in.`,
        code: "past_cutoff",
      },
      { status: 409 }
    );
  }

  const holdAmount = Math.round(table.minSpendCents * bufferMultiplier);

  // CLAIM THE TABLE BEFORE TALKING TO STRIPE.
  //
  // Everything above read the table and decided it was checkable. Placing
  // the hold takes a second or two, and in that window a second request —
  // the doorman's tablet and the staff board, tapped at the same moment —
  // passes exactly the same checks. Both then authorize the card, and the
  // second write overwrites the first: two real holds on the guest's
  // money, one of them invisible to us forever.
  //
  // This flips the status atomically first. Whoever loses the race sees
  // the table is no longer "card_saved" and stops before spending anyone's
  // credit line.
  const claimed = mutateTable(
    tableId,
    (t) => (t.status === "card_saved" ? { status: "checking_in" } : null)
  );

  if (!claimed) {
    return NextResponse.json(
      { error: "This table is already being checked in.", code: "checkin_in_progress" },
      { status: 409 }
    );
  }

  const basePaymentIntentParams = {
    amount: holdAmount,
    currency: table.currency,
    customer: table.stripeCustomerId,
    payment_method: table.paymentMethodId,
    off_session: true,
    confirm: true,
    capture_method: "manual", // authorize now, capture later = a hold, not a charge
    metadata: { tableId },
    expand: ["latest_charge"],
  };

  try {
    let paymentIntent;
    try {
      paymentIntent = await stripe.paymentIntents.create(
        {
          ...basePaymentIntentParams,
          payment_method_options: {
            card: {
              // Ask Stripe/the card network to allow us to raise this hold
              // later in the night without a new 3DS challenge.
              request_incremental_authorization: "if_available",
            },
          },
        },
        // The fallback path below always had this; the primary path did
        // not, which meant a retried check-in — a doorman's tablet losing
        // signal mid-request and being tapped again — could authorize the
        // guest's card twice. Keyed on the booking, so a replay returns
        // the SAME hold instead of placing another.
        { idempotencyKey: `hold_${tableId}_${table.setupIntentId}_${holdAmount}` }
      );
    } catch (err) {
      // Some accounts aren't eligible for incremental authorization at all
      // (needs Stripe IC+ pricing + merchant-category approval — see
      // README section 5). Stripe rejects the whole PaymentIntent in that
      // case instead of silently skipping the feature, so fall back to a
      // plain hold: the rest of the demo (place hold / update tab /
      // capture) still works, only "+250 / +500 / +1000" won't.
      if (err.message?.includes("not eligible for the requested card features")) {
        // Its OWN key. Stripe remembers the refused request above under
        // the first key, parameters included, and rejects any reuse of it
        // with different parameters — which this call always has, since it
        // drops the incremental-auth option. Sharing the key made this
        // fallback fail every single time on the accounts it exists for.
        paymentIntent = await stripe.paymentIntents.create(basePaymentIntentParams, {
          idempotencyKey: `hold_${tableId}_${table.setupIntentId}_${holdAmount}_plain`,
        });
      } else {
        throw err;
      }
    }

    const incrementalStatus =
      paymentIntent.latest_charge?.payment_method_details?.card?.incremental_authorization
        ?.status || "unknown";

    const updated = updateTable(
      tableId,
      {
        status: "checked_in",
        // First hold on the stack. More get added alongside it as the
        // night runs — see /api/increment.
        holds: [
          {
            paymentIntentId: paymentIntent.id,
            amountCents: paymentIntent.amount,
            capturedCents: null,
            status: "open",
          },
        ],
        holdAmountCents: paymentIntent.amount,
        // The opening hold, kept as its own figure. Everything the total
        // grows beyond this is money the guest was asked for and approved
        // during the night, which is exactly what "added tonight" means on
        // their own screen — and it can't be derived once holds are
        // stripped out of what the guest's page is allowed to see.
        checkinHoldCents: paymentIntent.amount,
        incrementalSupported: incrementalStatus === "available",
      },
      `Checked in${
        force && isPastCheckinCutoff() ? ` — OVERRIDE, arrived after ${cutoffLabel()}` : ""
      } — hold placed for ${(holdAmount / 100).toFixed(2)} ${table.currency.toUpperCase()} (incremental auth: ${incrementalStatus})`,
      actor
    );

    return NextResponse.json({ ok: true, table: updated });
  } catch (err) {
    // The realistic failure mode: card_declined because the buffer amount
    // isn't available on the card. Log it and DO NOT check the table in.
    //
    // Releasing the claim matters as much as logging it: a table left in
    // "checking_in" after a decline can never be checked in again, and the
    // guest is standing at the door.
    updateTable(
      tableId,
      { status: "card_saved" },
      `Check-in hold DECLINED (${(holdAmount / 100).toFixed(2)} ${table.currency.toUpperCase()}): ${err.message}`,
      actor
    );
    return NextResponse.json({ error: err.message }, { status: 402 });
  }
}
