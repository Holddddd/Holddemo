import { NextResponse } from "next/server";
import { getTable } from "@/lib/db";
import { canSeeBooking } from "@/lib/auth";

// The guest's live table page polls this instead of /api/tables. Two
// reasons: it only ever returns ONE booking, and it makes the caller prove
// they hold that booking's token first — the public table list can't do
// either, because the floor map needs it unauthenticated.
export async function GET(req, { params }) {
  const table = getTable(params.tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }

  const token = new URL(req.url).searchParams.get("t");
  if (!canSeeBooking(table, token)) {
    return NextResponse.json({ error: "Not your table" }, { status: 403 });
  }

  // Stripe ids and the booking token itself never need to reach the guest's
  // browser, so they don't.
  const {
    stripeCustomerId,
    setupIntentId,
    paymentMethodId,
    holds,
    bookingTokenHash,
    bookingTokenExpiresAt,
    ...safe
  } = table;

  return NextResponse.json({ table: safe });
}
