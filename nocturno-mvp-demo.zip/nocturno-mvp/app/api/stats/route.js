import { NextResponse } from "next/server";
import { staffOnly } from "@/lib/auth";
import { readDB } from "@/lib/db";
import { buildStats } from "@/lib/stats";

// Tonight's numbers, for the person who has to decide whether any of this
// works. Staff-only without exception: this is the venue's takings, its
// margins and its refusal rate in one object, and none of it is a guest's
// business — unlike /api/leaderboard, which is public precisely because it
// carries none of it.
//
// Read-only and derived on every call rather than incrementally maintained.
// A running total kept in the database drifts the first time a write fails
// halfway, and a figure that is quietly wrong is worse than a slow one.
export async function GET() {
  const denied = staffOnly();
  if (denied) return denied;

  return NextResponse.json(buildStats(readDB()));
}
