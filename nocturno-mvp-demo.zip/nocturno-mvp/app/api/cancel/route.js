import { NextResponse } from "next/server";
import { staffOnly, currentStaff } from "@/lib/auth";
import { getTable, updateTable } from "@/lib/db";
import { releaseHolds } from "@/lib/settle";
import { notifyGuest } from "@/lib/notify";
import {
  isRefusal,
  noteRequired,
  reasonLabel,
  buildRefusal,
  refusalMessage,
  releasedMessage,
} from "@/lib/refusal";

// Not every booking ends at capture. A guest can be turned away at the
// door, or never show at all. This is the "no money changes hands"
// off-ramp: if a hold has already been placed, it's voided outright
// (distinct from /api/capture, which settles it) — nothing is charged
// either way.
//
// Two endings live here and they are NOT the same event:
//
//   REFUSAL   somebody was turned away. A named member of staff made a
//             decision about a person who was standing in front of them.
//             It produces an official record with a quotable reference,
//             and the guest is told in writing.
//   RELEASE   the booking lapsed — no-show, guest cancelled, venue error.
//             Nobody judged anybody. No reference, but the guest is still
//             told their table is gone and their card is untouched.
//
// Either way the guest hears something. Being refused entry and then
// simply never hearing from the venue again — no message, no reason, no
// way to ask — was the part that was actually broken.
export async function POST(req) {
  const denied = staffOnly();
  if (denied) return denied;

  // Stamped onto every log line this request writes, so the record
  // says who did it and not merely that somebody did.
  const actor = currentStaff();

  const { tableId, reason = "other", note = "" } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table) {
    return NextResponse.json({ error: "Table not found" }, { status: 404 });
  }
  if (!["pending_card", "card_saved", "checked_in"].includes(table.status)) {
    return NextResponse.json(
      { error: `Table is in status "${table.status}", nothing to cancel` },
      { status: 400 }
    );
  }

  const refused = isRefusal(reason);
  // Captured BEFORE the status changes: whether these people were already
  // sitting at the table decides which message they get.
  const wasSeated = table.status === "checked_in";

  // An official record that says only "under 18" records a conclusion and
  // no evidence. If this is ever challenged — and these are the ones that
  // get challenged — the note is the entire difference between a
  // defensible decision and one person's word. Enforced server-side, not
  // just marked with an asterisk in the form.
  if (refused && noteRequired(reason) && !String(note).trim()) {
    return NextResponse.json(
      {
        error: `"${reasonLabel(
          reason
        )}" goes on an official record the guest can contest. Write down what was actually observed — an ID's date of birth, what was seen — not just the conclusion.`,
        code: "note_required",
      },
      { status: 400 }
    );
  }

  const base = reasonLabel(reason);
  const trimmed = String(note).trim();
  const label = trimmed ? `${base} — ${trimmed}` : base;

  try {
    // Void every authorization on the table, not just the first one.
    const { holds, released } = await releaseHolds(table);
    const releasedNote = released
      ? ` (released ${(released / 100).toFixed(2)} ${table.currency.toUpperCase()} across ${
          holds.filter((h) => h.status === "released").length
        } hold(s))`
      : "";

    const refusal = refused
      ? buildRefusal({ reasonId: reason, note: trimmed, actor })
      : null;

    const updated = updateTable(
      tableId,
      {
        status: "cancelled",
        cancelReason: label,
        refusal,
        holds,
        holdAmountCents: 0,
      },
      refusal
        ? `REFUSED ENTRY — ${label}${releasedNote} · official record ${refusal.ref}`
        : `Released — ${label}${releasedNote}`,
      actor
    );

    // Tell them. Fire-and-forget: a failed SMS must not leave the table
    // stuck open, and notifyGuest logs its own outcome either way.
    const notification = await notifyGuest(
      updated,
      refusal
        ? refusalMessage(updated, refusal, { wasSeated })
        : releasedMessage(updated, { label: base })
    );

    return NextResponse.json({ ok: true, table: updated, refusal, notification });
  } catch (err) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
