import { NextResponse } from "next/server";
import { stripe } from "@/lib/stripe";
import { getTable, updateTable } from "@/lib/db";
import { bookingTokenValid } from "@/lib/auth";

// After the guest completes the card form (and 3D Secure, if their bank
// requires it) in the browser, we NEVER trust the client's word that it
// worked — we re-fetch the SetupIntent from Stripe ourselves and check its
// status. This is what actually marks the booking as confirmed.
export async function POST(req) {
  const { tableId, bookingToken } = await req.json().catch(() => ({}));

  const table = getTable(tableId);
  if (!table || !table.setupIntentId) {
    return NextResponse.json({ error: "No pending card verification for this table" }, { status: 400 });
  }

  // The route re-checks with Stripe below, so it can only ever confirm a
  // verification that genuinely succeeded — the damage from leaving it
  // open was never a fake booking. But it took a bare table id, which
  // meant anyone could ask "is table 6 booked yet?" and get an answer.
  // The browser that started this booking is the only one holding the
  // token, so requiring it costs nothing and closes that.
  if (!bookingTokenValid(table, bookingToken)) {
    return NextResponse.json({ error: "Not your booking" }, { status: 403 });
  }

  try {
    const setupIntent = await stripe.setupIntents.retrieve(table.setupIntentId);

    if (setupIntent.status !== "succeeded") {
      return NextResponse.json(
        { error: `Card verification not complete (status: ${setupIntent.status})` },
        { status: 400 }
      );
    }

    updateTable(
      tableId,
      {
        paymentMethodId: setupIntent.payment_method,
        status: "card_saved",
      },
      "Card verified — booking confirmed (no charge yet)"
    );

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
