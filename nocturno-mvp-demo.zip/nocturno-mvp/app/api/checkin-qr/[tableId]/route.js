import QRCode from "qrcode";
import { getTable } from "@/lib/db";

// The code on the guest's confirmation. Scanning it at the door opens the
// doorman's page for exactly this booking, so the person on the step
// doesn't have to find the right table on a list at 1am.
//
// Deliberately dark-on-light: inverted QR codes scan on some phones and
// silently fail on others, and this one has a queue behind it.
export async function GET(req, { params }) {
  const table = getTable(params.tableId);
  if (!table) {
    return new Response("Table not found", { status: 404 });
  }

  // A phone camera needs a full URL — a bare path would scan as plain
  // text and open nothing. Taking the origin off the incoming request
  // means the code is correct whether the page was loaded on localhost,
  // on a LAN IP from an actual phone, or on a deployed host.
  const origin = new URL(req.url).origin;
  // Carry the booking token so the scan lands on THIS booking and an
  // expired code is refused at the door instead of checking someone in.
  const token = new URL(req.url).searchParams.get("t");
  const target = `${origin}/door/${table.id}${token ? `?t=${token}` : ""}`;

  const svg = await QRCode.toString(target, {
    type: "svg",
    margin: 1,
    errorCorrectionLevel: "M",
    color: { dark: "#000000", light: "#FFFFFF" },
  });

  return new Response(svg, {
    headers: {
      "Content-Type": "image/svg+xml",
      // This image ENCODES the booking token. "public" invites every
      // proxy and CDN between here and the phone to keep a copy of a live
      // credential; the browser that asked for it is the only cache that
      // should ever hold it.
      "Cache-Control": "private, no-store",
    },
  });
}
