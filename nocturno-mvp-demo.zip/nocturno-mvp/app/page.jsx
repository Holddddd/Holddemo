import { getTables } from "@/lib/db";
import { cutoffLabel } from "@/lib/nightclock";
import styles from "./home.module.css";
import { LangProvider } from "@/app/components/i18n/LangProvider";
import { getLang, getT } from "@/lib/i18n/server";

// The way in. Two doors, clearly labelled, because this is two devices: a
// guest's phone and a manager's tablet.
//
// These point at the REAL flow (/book, /staff) rather than the scripted
// /demo screens — booking, arrival and the staff board are the thing being
// judged, and none of them exist in the fixture demo.
//
// The guest list here shows table NAMES ONLY — no prices, no status, no
// floor plan. A guest has one table, the one the club sent them a link
// for. Publishing the whole room with what each table costs and which are
// still unsold is the venue's live inventory, and that is a staff view.
// The landing page is the guest's way in, so it follows the guest-side
// language and carries the same language button.
export default function Home() {
  const tables = getTables();
  const t = getT("guest");

  return (
    <LangProvider area="guest" initialLang={getLang("guest")}>
    <main className={styles.wrap}>
      <p className={styles.eyebrow}>{t("home.eyebrow")}</p>

      <h1 className={styles.title}>
        {t("home.title1")}
        <br />
        <em>{t("home.title2")}</em>
      </h1>

      <p className={styles.lede}>{t("home.lede")}</p>

      <section className={styles.doorSection}>
        <div className={styles.door}>
          <h2 className={styles.doorTitle}>{t("home.guestTitle")}</h2>
          <p className={styles.doorText}>{t("home.guestText")}</p>
          <ul className={styles.tableList}>
            {tables.map((tb) => (
              <li key={tb.id}>
                <a className={styles.tableLink} href={`/book/${tb.id}`}>
                  <span>{tb.name}</span>
                  <span className={styles.tableGo}>{t("home.book")}</span>
                </a>
              </li>
            ))}
          </ul>
        </div>

        <div className={styles.door}>
          <h2 className={styles.doorTitle}>{t("home.staffTitle")}</h2>
          <p className={styles.doorText}>{t("home.staffText", { time: cutoffLabel() })}</p>
          <a className={styles.cta} href="/staff">
            {t("home.openFloor")}
          </a>
          <p className={styles.doorNote}>PIN 2468</p>
        </div>
      </section>

      <p className={styles.foot}>
        {t("home.foot", {
          card: <span className="mono">4242 4242 4242 4242</span>,
          booked: <span>{t("home.booked")}</span>,
        })}
      </p>
    </main>
    </LangProvider>
  );
}
