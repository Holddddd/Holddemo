"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { DICTS } from "@/lib/i18n/dicts";
import { DEFAULT_LANG, LANG_COOKIE, pluralKey, translate } from "@/lib/i18n/core";
import { LangContext } from "./context";
import LanguagePicker from "./LanguagePicker";

// One per side of the venue — see the layouts under /book, /table, /staff…
// `initialLang` comes from the cookie on the server, so the first paint is
// already in the right language and nothing flickers from English.
export function LangProvider({ area, initialLang, children }) {
  const [lang, setLangState] = useState(initialLang || DEFAULT_LANG);
  const router = useRouter();

  const setLang = useCallback(
    (next) => {
      // A year: the choice belongs to the device, like a phone's own
      // language setting, not to one night.
      document.cookie = `${LANG_COOKIE[area]}=${next}; path=/; max-age=31536000; samesite=lax`;
      setLangState(next);
      // Some text is rendered on the server (a "table not found", the
      // receipt). Re-rendering it picks the new cookie up.
      router.refresh();
    },
    [area, router]
  );

  // Screen readers and the browser's own translate prompt read this.
  useEffect(() => {
    document.documentElement.lang = lang;
  }, [lang]);

  const value = useMemo(() => {
    const dict = DICTS[area];
    const t = (key, vars) => translate(dict, lang, key, vars);
    t.plural = (base, n, vars) => translate(dict, lang, pluralKey(lang, base, n), { n, ...vars });
    return { area, lang, setLang, t };
  }, [area, lang, setLang]);

  return (
    <LangContext.Provider value={value}>
      {children}
      <LanguagePicker />
    </LangContext.Provider>
  );
}

export { useLang, useT } from "./context";
