"use client";

import { createContext, useContext } from "react";
import { DICTS } from "@/lib/i18n/dicts";
import { DEFAULT_LANG, pluralKey, translate } from "@/lib/i18n/core";

export const LangContext = createContext(null);

// Outside a provider (a component rendered somewhere unexpected) this still
// works — in English, which is what that component said before.
const FALLBACK = (() => {
  const dict = { en: { ...DICTS.guest.en, ...DICTS.staff.en } };
  const t = (key, vars) => translate(dict, "en", key, vars);
  t.plural = (base, n, vars) => translate(dict, "en", pluralKey("en", base, n), { n, ...vars });
  return { area: null, lang: DEFAULT_LANG, setLang: () => {}, t };
})();

export function useLang() {
  return useContext(LangContext) || FALLBACK;
}

export function useT() {
  return useLang().t;
}
