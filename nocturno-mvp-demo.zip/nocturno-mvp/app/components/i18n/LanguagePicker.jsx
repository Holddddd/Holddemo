"use client";

import { useEffect, useRef, useState } from "react";
import { LANGS } from "@/lib/i18n/core";
import { useLang } from "./context";
import styles from "./picker.module.css";

// The one control this feature adds. Pinned to a corner so it never moves
// anything already on the page, and kept under the sheet overlays so an
// open "Close the bill" or "Close the shift" covers it rather than the
// other way round.
//
// Each language is listed in its own name — someone who cannot read the
// current language can still find theirs.
export default function LanguagePicker() {
  const { lang, setLang, area } = useLang();
  const [open, setOpen] = useState(false);
  const root = useRef(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e) => {
      if (!root.current?.contains(e.target)) setOpen(false);
    };
    const onKey = (e) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("pointerdown", onDoc);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("pointerdown", onDoc);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  if (!area) return null;
  const current = LANGS.find((l) => l.code === lang) || LANGS[0];

  return (
    <div ref={root} className={styles.root} data-area={area}>
      {open && (
        <ul className={styles.menu} role="menu" aria-label="Language">
          {LANGS.map((l) => (
            <li key={l.code} role="none">
              <button
                type="button"
                role="menuitemradio"
                aria-checked={l.code === lang}
                lang={l.code}
                className={styles.item}
                onClick={() => {
                  setOpen(false);
                  if (l.code !== lang) setLang(l.code);
                }}
              >
                <span className={styles.code}>{l.short}</span>
                {l.name}
              </button>
            </li>
          ))}
        </ul>
      )}
      <button
        type="button"
        className={styles.trigger}
        aria-haspopup="menu"
        aria-expanded={open}
        aria-label={`Language: ${current.name}`}
        onClick={() => setOpen((v) => !v)}
      >
        <svg className={styles.globe} viewBox="0 0 16 16" aria-hidden="true">
          <circle cx="8" cy="8" r="6.5" />
          <path d="M1.5 8h13M8 1.5c2 2 2.8 4 2.8 6.5S10 12.5 8 14.5M8 1.5C6 3.5 5.2 5.5 5.2 8S6 12.5 8 14.5" />
        </svg>
        {current.short}
      </button>
    </div>
  );
}
