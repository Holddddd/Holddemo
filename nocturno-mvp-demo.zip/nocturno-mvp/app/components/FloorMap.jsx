"use client";

import { useCallback, useEffect, useState } from "react";
import { mapState } from "@/lib/floorplan";
import { DEFAULT_BUFFER_MULTIPLIER } from "@/lib/config";
import FloorPlanSvg from "./FloorPlanSvg";
import styles from "./floormap.module.css";

function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

const STATE_LABEL = {
  free: "Free",
  reserved: "Reserved",
  live: "Occupied",
  spent: "Closed",
};

export default function FloorMap() {
  const [tables, setTables] = useState([]);
  const [selectedId, setSelectedId] = useState(null);

  const refresh = useCallback(async () => {
    const res = await fetch("/api/tables");
    const data = await res.json();
    setTables(data.tables);
  }, []);

  useEffect(() => {
    refresh();
    // Someone else can take a table while this map is open on a phone.
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  const selected = tables.find((t) => t.id === selectedId) || null;

  return (
    <div className={styles.wrap}>
      <div className={styles.mapCol}>
        <FloorPlanSvg
          tables={tables}
          selectedId={selectedId}
          onSelect={setSelectedId}
          label="Floor plan — choose a table"
        />

        <ul className={styles.legend}>
          {["free", "reserved", "live"].map((s) => (
            <li key={s}>
              <span className={styles.swatch} data-state={s} />
              {STATE_LABEL[s]}
            </li>
          ))}
        </ul>
      </div>

      <aside className={styles.panel} aria-live="polite">
        {selected ? (
          <TableDetail table={selected} />
        ) : (
          <p className={styles.empty}>
            Pick a table on the plan to see its size, its minimum and what gets held.
          </p>
        )}
      </aside>
    </div>
  );
}

function TableDetail({ table }) {
  const state = mapState(table.status);
  const cap = Math.round(table.minSpendCents * DEFAULT_BUFFER_MULTIPLIER);

  return (
    <div className={styles.detail}>
      <p className={styles.detailZone}>{table.zone}</p>
      <h3 className={styles.detailName}>{table.name}</h3>
      <span className={styles.detailPill} data-state={state}>
        {STATE_LABEL[state]}
      </span>

      <dl className={styles.specs}>
        <div>
          <dt>Seats</dt>
          <dd className="mono">{table.seats}</dd>
        </div>
        <div>
          <dt>Minimum</dt>
          <dd className={`mono ${styles.money}`}>{eur(table.minSpendCents)} €</dd>
        </div>
        <div>
          <dt>Held on arrival</dt>
          <dd className={`mono ${styles.moneyGhost}`}>{eur(cap)} €</dd>
        </div>
      </dl>

      {state === "free" && (
        <a className={styles.cta} href={`/book/${table.id}`}>
          Reserve this table
        </a>
      )}
      {state === "reserved" && (
        <p className={styles.note}>
          Held for {table.guestName || "another guest"} — not bookable right now.
        </p>
      )}
      {/* No link through to the tab from here. This map is public, and the
          live tab belongs to whoever holds that booking's token. */}
      {state === "live" && (
        <p className={styles.note}>Occupied tonight — sitting guests, running tab.</p>
      )}
      {state === "spent" && <p className={styles.note}>Finished for tonight.</p>}
    </div>
  );
}
