"use client";

import { FLOOR, FEATURES, ZONE_LABELS, TABLE_GEOMETRY, mapState } from "@/lib/floorplan";
import styles from "./floormap.module.css";

function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

// "Mesa 6 · Reservado" -> "6". The map has no room for the full name, and
// the number is what staff and guests both say out loud anyway.
export function shortLabel(name) {
  const n = name.match(/\d+/);
  return n ? n[0] : name.slice(0, 2);
}

// The room, drawn once and reused: interactive on the home page for picking
// a table, and locked with a single table called out on the confirmation
// screen. Same geometry both times, so "the one I picked" and "the one on
// my confirmation" are visibly the same place.
// How close a table is to the ceiling it can be charged up to. The same
// thresholds the staff cards use, so a table that is amber on the map is
// amber on its card — two different answers to "is this table a problem"
// would be worse than only having one of them.
export function spendRisk(t) {
  const hold = t.holdAmountCents || 0;
  const tab = t.tabAmountCents || 0;
  if (t.status !== "checked_in" || hold <= 0) return null;
  if (tab > hold) return "over";
  if (tab / hold >= 0.8) return "warn";
  return "ok";
}

export default function FloorPlanSvg({
  tables,
  selectedId = null,
  highlightId = null,
  onSelect = null,
  onHover = null,
  // Staff only. Colours live tables by how close they are to their ceiling
  // and lets the parent show the figures on hover — money on a wall-facing
  // plan is a staff instrument, never a guest one.
  showSpend = false,
  // Guest mode: the room without the inventory. No prices, no other
  // table's status — the guest is being shown where they are sitting, not
  // what the venue has left to sell.
  bare = false,
  label = "Floor plan",
  // What a screen reader says for each table. Defaults to the English it
  // always said; the staff map passes a translated one.
  tableLabel = null,
}) {
  const interactive = typeof onSelect === "function";

  return (
    <svg
      className={styles.map}
      viewBox={`0 0 ${FLOOR.width} ${FLOOR.height}`}
      role="group"
      aria-label={label}
    >
      {/* Architecture first, so tables always sit on top of it. */}
      {FEATURES.map((f) => (
        <g key={f.id}>
          <rect
            x={f.x}
            y={f.y}
            width={f.w}
            height={f.h}
            rx={f.kind === "door" ? 4 : 6}
            className={styles[`feat_${f.kind}`]}
          />
          {f.kind !== "door" && (
            <text x={f.x + f.w / 2} y={f.y + f.h / 2} className={styles.featLabel}>
              {f.label.toUpperCase()}
            </text>
          )}
        </g>
      ))}

      {FEATURES.filter((f) => f.kind === "door").map((f) => (
        <text
          key={`${f.id}-label`}
          x={f.x + f.w / 2}
          y={f.y + f.h + 16}
          className={styles.featLabel}
        >
          {f.label.toUpperCase()}
        </text>
      ))}

      {ZONE_LABELS.map((z) => (
        <text key={z.label} x={z.x} y={z.y} className={styles.zoneLabel}>
          {z.label.toUpperCase()}
        </text>
      ))}

      {tables.map((t) => {
        const g = TABLE_GEOMETRY[t.id];
        if (!g) return null;
        // In bare mode every table but the guest's own is drawn in one
        // neutral state, so the plan can't be read for who is sold out.
        const isHighlight = t.id === highlightId;
        const state = bare ? "free" : mapState(t.status);
        const risk = showSpend ? spendRisk(t) : null;
        // With one table called out, everything else steps back — the
        // point of that view is "here", not "what else is free".
        const dim = highlightId !== null && !isHighlight;

        // `key` is deliberately NOT in here: React reads it off the JSX
        // element itself, and spreading it in from an object is both a
        // warning and a silent no-op waiting to happen.
        const common = {
          className: styles.table,
          "data-state": state,
          // Persistent, not hover-only: a waiter crossing the room should
          // see which table is about to run out of headroom without
          // having to point at anything.
          "data-risk": risk || undefined,
          "data-selected": t.id === selectedId || undefined,
          "data-highlight": isHighlight || undefined,
          "data-dim": dim || undefined,
        };

        const hoverHandlers = onHover
          ? {
              onMouseEnter: () => onHover(t.id),
              onMouseLeave: () => onHover(null),
              onFocus: () => onHover(t.id),
              onBlur: () => onHover(null),
            }
          : {};

        const handlers = interactive
          ? {
              role: "button",
              tabIndex: 0,
              "aria-label": tableLabel
                ? tableLabel(t, eur(t.minSpendCents))
                : `${t.name}, ${t.seats} seats, minimum ${eur(t.minSpendCents)} euro`,
              onClick: () => onSelect(t.id),
              onKeyDown: (e) => {
                if (e.key === "Enter" || e.key === " ") {
                  e.preventDefault();
                  onSelect(t.id);
                }
              },
            }
          : {};

        return (
          <g key={t.id} {...common} {...handlers} {...hoverHandlers}>
            {g.shape === "round" ? (
              <>
                <circle cx={g.cx} cy={g.cy} r={g.r} className={styles.shape} />
                <text x={g.cx} y={g.cy + 1} className={styles.tableNum}>
                  {shortLabel(t.name)}
                </text>
              </>
            ) : (
              <>
                <rect
                  x={g.x}
                  y={g.y}
                  width={g.w}
                  height={g.h}
                  rx={g.shape === "sofa" ? 12 : 5}
                  className={styles.shape}
                />
                {/* The backrest is what makes a sofa read as a sofa
                    rather than as another rectangle on the plan. */}
                {g.shape === "sofa" && (
                  <line
                    x1={g.x + 10}
                    y1={g.y + 7}
                    x2={g.x + g.w - 10}
                    y2={g.y + 7}
                    className={styles.backrest}
                  />
                )}
                <text
                  x={g.x + g.w / 2}
                  y={g.y + g.h / 2 + (bare ? 5 : -6)}
                  className={styles.tableNum}
                >
                  {shortLabel(t.name)}
                </text>
                {/* Staff see the money on the plan; a guest sees a room. */}
                {!bare && (
                  <text x={g.x + g.w / 2} y={g.y + g.h / 2 + 14} className={styles.tablePrice}>
                    {showSpend && t.status === "checked_in"
                      ? `${eur(t.tabAmountCents || 0)} €`
                      : `${eur(t.minSpendCents)} €`}
                  </text>
                )}
              </>
            )}

            {/* "You are here" — a marker above the table rather than a
                colour change, so it survives whatever state the table
                is already drawn in. */}
            {isHighlight && <TableMarker geometry={g} />}
          </g>
        );
      })}
    </svg>
  );
}

function TableMarker({ geometry: g }) {
  const cx = g.shape === "round" ? g.cx : g.x + g.w / 2;
  const top = g.shape === "round" ? g.cy - g.r : g.y;

  return (
    <g className={styles.marker}>
      <line x1={cx} y1={top - 26} x2={cx} y2={top - 8} />
      <circle cx={cx} cy={top - 30} r={5} />
    </g>
  );
}
