"use client";

import { useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { useLang } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "");

// The approve-and-authenticate sequence, in one place.
//
// It is used from two screens — the guest's own table page and the
// standalone /topup link they get by SMS — and the two must never drift.
// The order of these three calls is the entire security property of the
// feature: the browser asks the server to create the intent, the ISSUER
// challenges the cardholder, and then the SERVER asks Stripe what actually
// happened. Skip the last step and a modified client can claim success
// without any money being reserved.
export function useApproveTopUp({ tableId, bookingToken, onDone }) {
  const { t, lang } = useLang();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  async function approve() {
    setBusy(true);
    setErr(null);
    try {
      const post = (body) =>
        fetch("/api/topup", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tableId, bookingToken, ...body }),
        });

      const res = await post({ action: "confirm" });
      const data = await res.json();
      if (!res.ok) throw new Error(apiError(t, lang, data, res.status, "topup.errAuthorize"));

      // requires_action means the bank wants the cardholder to prove who
      // they are. If the card needs no challenge this resolves at once.
      if (data.status === "requires_action" || data.status === "requires_source_action") {
        const stripe = await stripePromise;
        const { error } = await stripe.handleNextAction({ clientSecret: data.clientSecret });
        if (error) throw new Error(error.message);
      }

      const fin = await post({ action: "finalize" });
      const finData = await fin.json();
      if (!fin.ok) throw new Error(apiError(t, lang, finData, fin.status, "topup.errIncomplete"));

      onDone?.(finData.table);
      return true;
    } catch (e) {
      setErr(e.message);
      return false;
    } finally {
      setBusy(false);
    }
  }

  return { approve, busy, err };
}
