"use client";

import { useCallback, useEffect, useState } from "react";
import { useApproveTopUp } from "@/app/components/useApproveTopUp";
import styles from "./guest.module.css";
import { useLang, useT } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";
import { reasonText } from "@/lib/i18n/reasons";

const VENUE_NAME = "CLUB NOCTURNO";

// Rounded — for menu prices and the big "spent so far" figure, where
// whole euros read faster and nobody is auditing the number.
function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

// Exact — for anything that has to ADD UP. A receipt reading
// "475 + 48 = 522" is the kind of detail that costs you the trust the
// rest of this product is trying to build.
function eurExact(cents) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

export default function GuestTable({ initialTable, bookingToken, tipPresets }) {
  const t = useT();
  const [table, setTable] = useState(initialTable);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const [closing, setClosing] = useState(false);

  const tokenQ = bookingToken ? `?t=${bookingToken}` : "";

  const refresh = useCallback(async () => {
    const res = await fetch(`/api/booking/${initialTable.id}${tokenQ}`);
    if (!res.ok) return;
    const data = await res.json();
    if (data.table) setTable(data.table);
  }, [initialTable.id, tokenQ]);

  useEffect(() => {
    // A waiter can ring something in on the same table from the staff
    // board while this page is open in someone's hand.
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  // The tab is read only to decide whether there is anything to close. It
  // is never rendered outside the close sheet.
  const tab = table.tabAmountCents || 0;
  // These ARE shown: the guest approved every hold and handed over the cash
  // themselves, so none of it is news to them — and the ceiling is the one
  // number that tells them the most that can ever be taken.
  const hold = table.holdAmountCents || 0;
  const cash = table.cashAmountCents || 0;
  // Everything beyond the hold placed at check-in: each approved top-up,
  // plus notes. "Added tonight" is the figure a guest actually queries.
  const added = Math.max(0, hold - (table.checkinHoldCents || hold)) + cash;
  // How far past the card's ceiling the bill has gone. Above zero the
  // guest cannot pay at all until it is topped up — see /api/close-bill.
  const overLimit = Math.max(0, tab - cash - hold);

  if (table.status === "closed") {
    return <Settled table={table} bookingToken={bookingToken} />;
  }

  // The apology has to land somewhere the guest actually looks, and this
  // page is the one they already have open. Until now a refused table fell
  // through to "this table isn't open yet" — which is both wrong and, to
  // somebody who has just been asked to leave, insulting.
  if (table.status === "cancelled") {
    return <Refused table={table} />;
  }

  if (table.status !== "checked_in") {
    return (
      <Shell table={table}>
        <p className={styles.notYet}>{t("table.notYet")}</p>
      </Shell>
    );
  }

  return (
    <Shell table={table}>
      {/* No running total during service. The venue's decision: a table is
          read like a restaurant table, where the bill arrives at the end
          rather than counting up in your hand all night.

          What this page must NEVER become is a way to take money without
          the guest seeing the figure. Three things keep that honest and all
          three are load-bearing:
            1. Close the bill shows the full itemised total before anything
               is captured (see CloseSheet).
            2. Every increase to what is held on the card is a separate
               request the guest approves with their bank. Hiding the tab
               AND silently growing the authorization is the combination
               that would actually be indefensible.
            3. What IS reserved on their card is shown, always. That is
               their money, they consented to each hold, and it is on their
               statement anyway — hiding it would be hiding the one figure
               they have already been told. */}
      <section className={styles.status}>
        <span className={styles.statusDot} aria-hidden="true" />
        <div>
          <p className={styles.statusLabel}>{t("table.open")}</p>
          <p className={styles.statusText}>{t("table.nothingCharged")}</p>
        </div>
      </section>

      <TopUpRequest
        table={table}
        bookingToken={bookingToken}
        onApproved={(t) => t && setTable(t)}
      />

      <dl className={styles.facts}>
        <div>
          <dt>{t("table.minSpend")}</dt>
          <dd className="mono">{eurExact(table.minSpendCents)} €</dd>
        </div>
        <div>
          <dt>{t("table.maxOnCard")}</dt>
          <dd className={`mono ${styles.factMoney}`}>{eurExact(hold)} €</dd>
        </div>
        {added > 0 && (
          <div>
            <dt>{t("table.addedTonight")}</dt>
            <dd className={`mono ${styles.factMoney}`}>+{eurExact(added)} €</dd>
          </div>
        )}
        {cash > 0 && (
          <div>
            <dt>{t("table.paidCashOf")}</dt>
            <dd className="mono">{eurExact(cash)} €</dd>
          </div>
        )}
      </dl>

      <p className={styles.explain}>
        {cash > 0 ? t("table.explainCash") : t("table.explain")}
      </p>

      {/* Read-only. Ordering goes through a waiter, so this page's job is
          to answer "what has actually gone on our table" — the question a
          group argues about at 3am — and nothing more. Prices stay off it:
          the guest is not shown a running total, so per-item pricing here
          would just be a sum they are invited to do and then can't check. */}
      <TabSoFar orders={table.orders} />

      {/* The itemised list is part of the bill, not part of the evening —
          it appears at close-out, where the guest is deciding whether to
          pay it. */}
      {/* Blocked before it is pressed, with the reason and the amount.
          Finding out you cannot pay only after tapping "pay" is the worst
          version of this. */}
      <button
        className={styles.closeBtn}
        onClick={() => setClosing(true)}
        disabled={tab <= 0 || overLimit > 0}
      >
        {t("table.closeBill")}
      </button>
      {tab <= 0 && <p className={styles.hint}>{t("table.nothingRung")}</p>}
      {overLimit > 0 && (
        <p className={styles.overHint}>{t("table.overHint", { amount: eurExact(overLimit) })}</p>
      )}

      {closing && (
        <CloseSheet
          table={table}
          bookingToken={bookingToken}
          tipPresets={tipPresets}
          onCancel={() => setClosing(false)}
          onDone={(t) => {
            setClosing(false);
            setTable(t);
          }}
        />
      )}
    </Shell>
  );
}

// The ask, on the page the guest already has open.
//
// This was the bug: the request went out by SMS and nowhere else, so with
// no SMS provider configured — or a guest who gave no number, or a text
// that simply didn't arrive in a basement — staff could see "waiting on
// the guest" forever while the guest had no idea and no way to act. The
// link still works and still gets sent; this is the copy of it that cannot
// go missing.
function TopUpRequest({ table, bookingToken, onApproved }) {
  const t = useT();
  const pending = table.topUp?.status === "pending";
  const { approve, busy, err } = useApproveTopUp({
    tableId: table.id,
    bookingToken,
    onDone: onApproved,
  });

  // The reason for a refusal has to stay on screen. The server marks the
  // request declined the moment it refuses it, so on the next refresh it
  // stops being "pending" — and the box, with the explanation inside it,
  // used to disappear without a word. The guest saw the request vanish and
  // had no idea why.
  if (!pending) {
    return err ? (
      <section className={styles.askBox} role="alert">
        <p className={styles.err}>{err}</p>
      </section>
    ) : null;
  }

  const expired = table.topUp.expiresAt && Date.now() > table.topUp.expiresAt;

  return (
    <section className={styles.askBox} role="status">
      <p className={styles.askLabel}>{t("topup.askLabel")}</p>
      <p className={`mono ${styles.askAmount}`}>{eurExact(table.topUp.amountCents)} €</p>
      <p className={styles.askText}>{t("topup.askText")}</p>

      {expired ? (
        <p className={styles.askExpired}>{t("topup.expired")}</p>
      ) : (
        <>
          {err && <p className={styles.err}>{err}</p>}
          <button className={styles.askBtn} onClick={approve} disabled={busy}>
            {busy ? t("topup.confirming") : t("topup.approve", { amount: eurExact(table.topUp.amountCents) })}
          </button>
          {/* Saying no is a real option and the screen should say so. A
              consent prompt that only offers agreement is not asking. */}
          <p className={styles.askRefuse}>{t("topup.refuse")}</p>
        </>
      )}
    </section>
  );
}

// What has landed on the table tonight, in the order it arrived.
//
// Grouped by item with a count, newest first, and timestamped — because
// the argument this settles is "did we order two bottles or three, and
// when". A flat repeated list makes that harder to answer, not easier.
function TabSoFar({ orders }) {
  const t = useT();
  const lines = orders || [];

  const grouped = Object.values(
    lines.reduce((acc, o) => {
      if (!acc[o.id]) acc[o.id] = { ...o, qty: 0, last: o.at };
      acc[o.id].qty += 1;
      // Keep the most recent time for this item, so "10 min ago" means
      // the last round rather than the first.
      if (o.at > acc[o.id].last) acc[o.id].last = o.at;
      return acc;
    }, {})
  ).sort((a, b) => (a.last < b.last ? 1 : -1));

  const total = lines.length;

  return (
    <section className={styles.tabBox}>
      <div className={styles.tabHead}>
        <h2 className={styles.h2}>{t("table.onYourTable")}</h2>
        {total > 0 && (
          <span className={styles.tabCount}>{t.plural("table.items", total)}</span>
        )}
      </div>

      {grouped.length === 0 ? (
        <p className={styles.tabEmpty}>{t("table.tabEmpty")}</p>
      ) : (
        <>
          <ul className={styles.tabList}>
            {grouped.map((o) => (
              <li key={o.id}>
                {/* The count is the thing people check, so it leads. */}
                <span className={styles.tabQty}>{o.qty}×</span>
                <span className={styles.tabName}>{o.name}</span>
                <span className={styles.tabWhen}>{timeAgo(o.last, t)}</span>
              </li>
            ))}
          </ul>
          <p className={styles.tabNote}>{t("table.tabNote")}</p>
        </>
      )}
    </section>
  );
}

// Short and forgiving. Nobody reading this at 3am wants a timestamp.
//
// Past about six hours it stops saying "ago" and gives the clock time
// instead: "22h ago" is both unreadable and a sign something is wrong —
// no club table runs for a day, and phrasing it as an elapsed time makes
// a stale record look like a normal one.
function timeAgo(iso, t) {
  if (!iso) return "";
  const then = new Date(iso);
  const mins = Math.round((Date.now() - then.getTime()) / 60000);
  if (mins < 1) return t("time.justNow");
  if (mins < 60) return t("time.minAgo", { n: mins });
  if (mins < 360) return t("time.hAgo", { n: Math.floor(mins / 60) });
  return then.toLocaleString("es-ES", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

// The table was ended before it closed. Two quite different situations
// share this screen and the wording has to tell them apart:
//
//   REFUSED   a named member of staff decided this person could not stay.
//             There is an official record with a reference, and this is
//             where the apology belongs — the guest is standing outside a
//             place they were just asked to leave, holding a phone.
//   RELEASED  the booking simply lapsed. Nobody judged anybody, so an
//             apology would be noise.
//
// Both say the same load-bearing sentence: no money was taken. That is the
// question the guest actually has, and it is the one thing they cannot
// check for themselves until their statement updates days later.
function Refused({ table }) {
  const t = useT();
  const r = table.refusal;

  return (
    <Shell table={table}>
      <div className={styles.refusedSeal} data-refusal={!!r || undefined}>
        {r ? "!" : "—"}
      </div>

      <h1 className={styles.doneTitle}>
        {r ? t("refused.title") : t("released.title")}
      </h1>

      <p className={styles.doneText}>
        {r
          ? t("refused.text")
          : table.cancelReason
            ? t("released.textReason", {
                reason: reasonText(t, { label: table.cancelReason }).toLowerCase(),
              })
            : t("released.text")}
      </p>

      {r && (
        <>
          <dl className={styles.facts}>
            <div>
              <dt>{t("refused.reference")}</dt>
              <dd className={`mono ${styles.factMoney}`}>{r.ref}</dd>
            </div>
            <div>
              <dt>{t("refused.reason")}</dt>
              <dd>{reasonText(t, { id: r.reasonId, label: r.label })}</dd>
            </div>
            <div>
              <dt>{t("refused.time")}</dt>
              <dd>{new Date(r.at).toLocaleString("es-ES")}</dd>
            </div>
          </dl>

          {/* The point of a reference is that it can be quoted. Saying so
              explicitly is what makes the decision contestable rather than
              final — which protects the guest, and the venue too. */}
          <p className={styles.explain}>{t("refused.explain")}</p>
        </>
      )}
    </Shell>
  );
}

function Shell({ table, children }) {
  const t = useT();
  return (
    <div className={styles.shell}>
      <header className={styles.venueBar}>
        <span className={styles.venueMark}>{VENUE_NAME}</span>
        <span className={styles.venueCity}>{t("venue.city")}</span>
      </header>
      <main className={styles.sheet}>
        <p className={styles.eyebrow}>
          {table.name}
          {table.guestName ? ` · ${table.guestName}` : ""}
        </p>
        {children}
      </main>
    </div>
  );
}

// Repeated rounds collapse into one line with a count — a guest reading
// their own bill wants "3× Grey Goose", not three identical rows.
function OrderList({ orders }) {
  const t = useT();
  const grouped = Object.values(
    (orders || []).reduce((acc, o) => {
      acc[o.id] = acc[o.id] || { ...o, qty: 0 };
      acc[o.id].qty += 1;
      return acc;
    }, {})
  );

  if (grouped.length === 0) return null;

  return (
    <section>
      <h2 className={styles.h2}>{t("close.yourTableTonight")}</h2>
      <ul className={styles.orderList}>
        {grouped.map((o) => (
          <li key={o.id}>
            <span>
              {o.qty > 1 ? `${o.qty}× ` : ""}
              {o.name}
            </span>
            <span className="mono">{eur(o.priceCents * o.qty)} €</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

function CloseSheet({ table, bookingToken, tipPresets, onCancel, onDone }) {
  const { t, lang } = useLang();
  const tab = table.tabAmountCents || 0;
  const hold = table.holdAmountCents || 0;
  // A capture can never exceed the authorization, so the tip is bounded
  // by whatever headroom is left rather than being free-form.
  const maxTip = Math.max(0, hold - tab);

  const [tipCents, setTipCents] = useState(0);
  const [rating, setRating] = useState(null);
  const [comment, setComment] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  async function submit() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/close-bill", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tableId: table.id,
          bookingToken,
          tipAmountCents: tipCents,
          serviceRating: rating,
          guestComment: comment.trim() || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(apiError(t, lang, data, res.status, "close.err"));
        setBusy(false);
        return;
      }
      onDone(data.table);
    } catch (e) {
      setErr(e.message);
      setBusy(false);
    }
  }

  return (
    <div className={styles.sheetOverlay} role="dialog" aria-modal="true" aria-label={t("table.closeBill")}>
      <div className={styles.closeSheet}>
        <h2 className={styles.sheetTitle}>{t("table.closeBill")}</h2>

        {/* The itemisation. The tab is deliberately hidden all evening, so
            THIS is the first and only place the guest sees what they are
            being asked to pay for — which makes it the one part of the
            screen that is not negotiable. Charging someone who was never
            shown the lines is not a design choice, it is a bill they
            cannot check. */}
        <OrderList orders={table.orders} />

        <div className={styles.billRow}>
          <span>{t("close.table")}</span>
          <span className="mono">{eurExact(tab)} €</span>
        </div>

        <p className={styles.fieldLabel}>{t("close.tip")}</p>
        <div className={styles.tipRow}>
          {tipPresets.map((p) => {
            const cents = Math.round(tab * p);
            const disabled = cents > maxTip;
            return (
              <button
                key={p}
                className={styles.tipBtn}
                data-active={tipCents === cents || undefined}
                disabled={disabled}
                onClick={() => setTipCents(cents)}
              >
                {p === 0 ? t("close.none") : `${Math.round(p * 100)}%`}
              </button>
            );
          })}
        </div>
        {maxTip < Math.round(tab * tipPresets[tipPresets.length - 1]) && (
          /* Its own class: `.hint` carries a negative top margin for the
             button it normally sits under, which dragged this line up over
             the tip buttons. */
          <p className={styles.tipHint}>{t("close.tipHint", { amount: eurExact(maxTip) })}</p>
        )}

        <div className={styles.billRow} data-total>
          <span>{t("close.total")}</span>
          <span className={`mono ${styles.totalValue}`}>{eurExact(tab + tipCents)} €</span>
        </div>

        <p className={styles.fieldLabel}>{t("close.howService")}</p>
        <div className={styles.starRow}>
          {[1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              className={styles.star}
              data-on={rating !== null && n <= rating ? "" : undefined}
              aria-label={t("close.starAria", { n })}
              onClick={() => setRating(n)}
            >
              ★
            </button>
          ))}
        </div>

        <p className={styles.fieldLabel}>{t("close.anything")}</p>
        <textarea
          className={styles.textarea}
          rows={3}
          maxLength={500}
          placeholder={t("close.placeholder")}
          value={comment}
          onChange={(e) => setComment(e.target.value)}
        />

        {err && <p className={styles.err}>{err}</p>}

        <button className={styles.payBtn} onClick={submit} disabled={busy}>
          {busy ? t("close.charging") : t("close.pay", { amount: eurExact(tab + tipCents) })}
        </button>
        <button className={styles.cancelBtn} onClick={onCancel} disabled={busy}>
          {t("common.notYet")}
        </button>
      </div>
    </div>
  );
}

function Settled({ table, bookingToken }) {
  const t = useT();
  const tip = table.tipAmountCents || 0;
  const card = table.capturedAmountCents || 0;
  const cash = table.cashAmountCents || 0;
  const bill = table.billAmountCents ?? table.tabAmountCents ?? 0;
  const tokenQ = bookingToken ? `?t=${bookingToken}` : "";

  return (
    <Shell table={table}>
      <div className={styles.seal}>✓</div>
      <h1 className={styles.doneTitle}>{t("settled.title")}</h1>
      <p className={styles.doneText}>
        {table.guestEmail ? t("settled.textEmail") : t("settled.text")}
      </p>

      <div className={styles.receipt}>
        <div className={styles.billRow}>
          <span>{t("settled.bill")}</span>
          <span className="mono">{eurExact(bill)} €</span>
        </div>
        {cash > 0 && (
          <div className={styles.billRow}>
            <span>{t("settled.paidCash")}</span>
            <span className="mono">{eurExact(cash)} €</span>
          </div>
        )}
        {tip > 0 && (
          <div className={styles.billRow}>
            <span>{t("close.tip")}</span>
            <span className="mono">{eurExact(tip)} €</span>
          </div>
        )}
        <div className={styles.billRow} data-total>
          <span>{t("settled.charged")}</span>
          <span className={`mono ${styles.totalValue}`}>{eurExact(card)} €</span>
        </div>
      </div>

      {/* The physical copy, on request rather than by default — printing a
          receipt nobody asked for is how a venue ends up with a bin full of
          them. */}
      <a className={styles.printLink} href={`/receipt/${table.id}${tokenQ}`} target="_blank" rel="noreferrer">
        {t("settled.print")}
      </a>

      {table.serviceRating && (
        <p className={styles.doneMeta}>{t("settled.rated", { n: table.serviceRating })}</p>
      )}
    </Shell>
  );
}
