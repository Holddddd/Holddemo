import { redirect } from "next/navigation";
import { getTable } from "@/lib/db";
import { canSeeBooking } from "@/lib/auth";
import { TIP_PRESETS } from "@/lib/config";
import GuestTable from "./GuestTable";
import { getT } from "@/lib/i18n/server";

export default function TablePage({ params, searchParams }) {
  const table = getTable(params.tableId);

  if (!table) {
    return <main style={{ padding: 40 }}>{getT("guest")("common.tableNotFound")}</main>;
  }

  // This page can order drinks and close a bill, so the table id on its own
  // is not enough to open it — the guest's link carries a per-booking
  // token, and staff can open any table with their own session.
  // No token means this is the printed sticker on the table, not the
  // guest's own link — somebody just sat down and pointed a camera at it.
  // Send them to the walk-in entry rather than an error: /t/[id] starts a
  // fresh session and refuses to open a table that is already occupied,
  // so a photographed sticker still can't reach anyone else's bill.
  if (!canSeeBooking(table, searchParams?.t)) {
    redirect(`/t/${table.id}`);
  }

  return (
    <GuestTable
      initialTable={table}
      bookingToken={searchParams?.t || null}
      tipPresets={TIP_PRESETS}
    />
  );
}
