import { getDemoTable } from "@/lib/demo/fixtures";
import PayScreen from "./PayScreen";

// SCREEN 2 — pay the deposit and authorise the hold.
export default function DemoPayPage({ params }) {
  const table = getDemoTable(params.tableId);

  if (!table) {
    return (
      <div className="demo-guest flex min-h-dvh items-center justify-center p-10">
        <p className="text-white/60">That code doesn&apos;t match a table here.</p>
      </div>
    );
  }

  return <PayScreen table={table} />;
}
