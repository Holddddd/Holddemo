"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { VENUE, holdFor, eur } from "@/lib/demo/fixtures";

const stripePromise = loadStripe(process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || "");

// Stripe's own dark theme, nudged towards the guest palette. Colours only —
// no layout rules, because injecting those into Stripe's iframe is what
// broke focus in the production booking form.
const appearance = {
  theme: "night",
  variables: {
    colorPrimary: "#ffffff",
    colorBackground: "#0d0d0f",
    colorText: "#ffffff",
    colorTextSecondary: "rgba(255,255,255,0.6)",
    colorDanger: "#ff5a5a",
    borderRadius: "4px",
  },
};

export default function PayScreen({ table }) {
  const [clientSecret, setClientSecret] = useState(null);
  const [err, setErr] = useState(null);

  useEffect(() => {
    fetch("/api/demo/setup-intent", { method: "POST" })
      .then((r) => r.json())
      .then((d) => (d.clientSecret ? setClientSecret(d.clientSecret) : setErr(d.error)))
      .catch((e) => setErr(e.message));
  }, []);

  // Memoised: a fresh object on every render makes react-stripe-js call
  // elements.update() and reset the card field under the cursor.
  const options = useMemo(() => ({ clientSecret, appearance }), [clientSecret]);

  const hold = holdFor(table);

  return (
    <div className="demo-guest px-5 pb-12 pt-9">
      <div className="mx-auto w-full max-w-[440px]">
        <header className="mb-8 text-center">
          <div className="text-[17px] font-black uppercase leading-none tracking-[0.02em]">
            {VENUE.name}
          </div>
          <div className="mt-2 text-[9px] font-semibold uppercase tracking-[0.44em] text-white/40">
            {table.name} · {table.zone}
          </div>
        </header>

        <Card className="mb-6 border-white/10 bg-[#0d0d0f]">
          <CardContent className="p-5">
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
                Charged now
              </span>
              <span className="demo-money text-[34px] font-extrabold leading-none tracking-[-0.03em]">
                {eur(table.depositCents)} €
              </span>
            </div>
            <Separator className="my-4 bg-white/10" />
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
                Held, not charged
              </span>
              <span className="font-mono text-[15px] text-white/70">{eur(hold)} €</span>
            </div>
          </CardContent>
        </Card>

        {err && (
          <p className="mb-4 text-[13px] leading-relaxed text-[#ff5a5a]">
            Couldn&apos;t reach Stripe: {err}
          </p>
        )}

        {!clientSecret && !err && (
          <p className="py-6 text-center text-[13px] text-white/40">Loading payment…</p>
        )}

        {clientSecret && (
          <Elements stripe={stripePromise} options={options}>
            <CardForm table={table} />
          </Elements>
        )}
      </div>
    </div>
  );
}

function CardForm({ table }) {
  const stripe = useStripe();
  const elements = useElements();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  async function submit(e) {
    e.preventDefault();
    if (!stripe || !elements) return;
    setBusy(true);
    setErr(null);

    // Validates and tokenises the card at Stripe. Nothing is charged: this
    // is a SetupIntent, and in the demo we don't even keep the result.
    const { error } = await stripe.confirmSetup({
      elements,
      redirect: "if_required",
    });

    if (error) {
      setErr(error.message);
      setBusy(false);
      return;
    }
    router.push(`/demo/tab/${table.id}`);
  }

  return (
    <form onSubmit={submit}>
      {/* Apple Pay and Google Pay appear here automatically — but only over
          HTTPS on a domain registered with Stripe. On localhost the wallet
          buttons are absent by design, not broken. */}
      <PaymentElement options={{ layout: "tabs" }} />

      {err && <p className="mt-4 text-[13px] leading-relaxed text-[#ff5a5a]">{err}</p>}

      <Button
        type="submit"
        size="lg"
        disabled={!stripe || busy}
        className="mt-6 h-14 w-full rounded-full bg-white text-[12px] font-extrabold uppercase tracking-[0.16em] text-black hover:bg-white/90 disabled:opacity-30"
      >
        {busy ? "Confirming…" : `Pay ${eur(table.depositCents)} €`}
      </Button>

      <p className="mt-3 text-center text-[11px] leading-relaxed text-white/35">
        Demo · Stripe test mode. Use 4242 4242 4242 4242, any future date, any CVC. No money
        moves and the card is not stored.
      </p>
    </form>
  );
}
