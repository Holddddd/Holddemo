"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { eur, ordersTotal } from "@/lib/demo/fixtures";

// Deliberately the SAME number as the real staff entrance at /login.
// Having two — 1234 here, 2468 there — meant the right PIN typed on the
// wrong screen just said "wrong PIN", which is a trap nobody needs on
// stage in front of a club. One number for both doors.
//
// This one is a stage prop, not a security control: it gates a mock
// screen and nothing behind it touches money. The real /login PIN is
// checked server-side against STAFF_PIN and issues a signed cookie.
const DEMO_PIN = "2468";

export default function DemoStaff() {
  const [unlocked, setUnlocked] = useState(false);
  const [pin, setPin] = useState("");
  const [err, setErr] = useState(false);
  const [tables, setTables] = useState([]);
  const router = useRouter();

  useEffect(() => {
    if (!unlocked) return;
    const tick = async () => {
      const r = await fetch("/api/demo/state", { cache: "no-store" });
      const d = await r.json();
      setTables(d.tables || []);
    };
    tick();
    const id = setInterval(tick, 1500);
    return () => clearInterval(id);
  }, [unlocked]);

  if (!unlocked) {
    return (
      <div className="demo-staff flex min-h-dvh items-center justify-center bg-black px-6">
        <div className="w-full max-w-[320px]">
          <h1 className="text-[34px] font-black uppercase leading-none tracking-[-0.03em] text-white">
            Staff
          </h1>
          <p className="mt-3 text-[12px] text-white/40">
            Demo PIN — <b className="text-white/80">{DEMO_PIN}</b> (same as the real staff login)
          </p>
          <input
            type="password"
            inputMode="numeric"
            autoFocus
            value={pin}
            onChange={(e) => {
              setPin(e.target.value);
              setErr(false);
            }}
            onKeyDown={(e) => {
              if (e.key !== "Enter") return;
              pin === DEMO_PIN ? setUnlocked(true) : setErr(true);
            }}
            className="mt-6 w-full rounded border border-solid border-white/15 bg-white/[0.04] px-4 py-4 text-center font-mono text-[24px] tracking-[0.4em] text-white outline-none focus:border-white/40"
          />
          {err && <p className="mt-3 text-[13px] text-[#ff5a5a]">Wrong PIN</p>}
          <Button
            onClick={() => (pin === DEMO_PIN ? setUnlocked(true) : setErr(true))}
            className="mt-4 h-14 w-full rounded-full bg-white text-[12px] font-extrabold uppercase tracking-[0.16em] text-black hover:bg-white/90"
          >
            Enter
          </Button>
        </div>
      </div>
    );
  }

  const zones = [...new Set(tables.map((t) => t.zone))];

  return (
    <div className="demo-staff min-h-dvh bg-black px-5 pb-16 pt-7">
      <div className="mx-auto max-w-[900px]">
        <div className="mb-6 flex items-baseline justify-between">
          <h1 className="text-[15px] font-black uppercase tracking-[0.3em] text-white">Floor</h1>
          <button
            onClick={async () => {
              await fetch("/api/demo/state", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ action: "reset" }),
              });
            }}
            className="rounded-full border border-solid border-white/15 px-4 py-2 text-[9px] font-bold uppercase tracking-[0.18em] text-white/40 hover:border-white/40 hover:text-white"
          >
            Reset demo
          </button>
        </div>

        {/* The floor plan, moved here from the public page. Staff are the
            ones who need to see the whole room at a glance — which tables
            are live, which are near their ceiling. A guest only ever has
            the one table they are sitting at. */}
        <div className="mb-8 rounded border border-solid border-white/10 bg-[#0d0d0f] p-4">
          <div className="mb-3 text-[9px] font-semibold uppercase tracking-[0.3em] text-white/30">
            Room
          </div>
          <div className="flex flex-wrap items-end gap-x-8 gap-y-5">
            {zones.map((zone) => (
              <div key={zone}>
                <div className="mb-2 text-[8px] uppercase tracking-[0.24em] text-white/25">
                  {zone}
                </div>
                <div className="flex gap-2">
                  {tables
                    .filter((t) => t.zone === zone)
                    .map((t) => {
                      const s = ordersTotal(t.lines || []);
                      const ceil = t.depositCents + t.holdCents;
                      const st =
                        t.status !== "open"
                          ? "idle"
                          : s >= ceil
                          ? "max"
                          : s > t.depositCents
                          ? "over"
                          : "live";
                      return (
                        <button
                          key={t.id}
                          onClick={() => router.push(`/demo/staff/${t.id}`)}
                          title={`${t.name} · ${eur(s)} €`}
                          className={`flex h-11 w-11 items-center justify-center rounded border border-solid text-[13px] font-bold ${
                            st === "max"
                              ? "border-[#ff5a5a] bg-[#ff5a5a]/15 text-[#ff5a5a]"
                              : st === "over"
                              ? "border-[#f5a623] bg-[#f5a623]/15 text-[#f5a623]"
                              : st === "live"
                              ? "border-[#e3c68a] bg-[#e3c68a]/15 text-[#e3c68a]"
                              : "border-white/12 text-white/35"
                          }`}
                        >
                          {t.name.replace(/\D/g, "")}
                        </button>
                      );
                    })}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Detail below the plan: the same tables with their numbers. */}
        {zones.map((zone) => (
          <div key={zone} className="mb-7">
            <div className="mb-3 text-[9px] font-semibold uppercase tracking-[0.3em] text-white/30">
              {zone}
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
              {tables
                .filter((t) => t.zone === zone)
                .map((t) => {
                  const spent = ordersTotal(t.lines || []);
                  const ceiling = t.depositCents + t.holdCents;
                  const pct = Math.min((spent / ceiling) * 100, 100);
                  const over = spent > t.depositCents;
                  const maxed = spent >= ceiling;

                  return (
                    <Card
                      key={t.id}
                      onClick={() => router.push(`/demo/staff/${t.id}`)}
                      className={`cursor-pointer border-solid bg-[#0d0d0f] transition-colors ${
                        maxed
                          ? "border-[#ff5a5a]"
                          : over
                          ? "border-[#f5a623]"
                          : t.status === "open"
                          ? "border-white/25"
                          : "border-white/10"
                      }`}
                    >
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between gap-2">
                          <span className="text-[13px] font-extrabold uppercase tracking-[0.1em] text-white">
                            {t.name}
                          </span>
                          <Badge
                            variant="outline"
                            className={`border-solid text-[8px] uppercase tracking-[0.16em] ${
                              t.status === "open"
                                ? "border-white/30 text-white"
                                : t.status === "closed"
                                ? "border-white/10 text-white/30"
                                : "border-white/10 text-white/35"
                            }`}
                          >
                            {t.status === "open" ? "live" : t.status}
                          </Badge>
                        </div>

                        <div
                          className={`mt-3 font-mono text-[22px] font-bold ${
                            maxed ? "text-[#ff5a5a]" : over ? "text-[#f5a623]" : "text-[#e3c68a]"
                          }`}
                        >
                          {eur(spent)} €
                        </div>
                        <div className="mt-1 text-[10px] text-white/35">
                          of {eur(ceiling)} € · {t.seats} seats
                        </div>

                        <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-white/[0.08]">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              maxed ? "bg-[#ff5a5a]" : over ? "bg-[#f5a623]" : "bg-[#e3c68a]"
                            }`}
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
