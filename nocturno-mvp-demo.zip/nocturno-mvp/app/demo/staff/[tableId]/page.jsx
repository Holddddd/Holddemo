"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { settlementPlan } from "@/lib/deposit";
import { eur, eurExact, lineTotal, ordersTotal } from "@/lib/demo/fixtures";

// The waiter's till. Every button here changes what the guest sees on
// their own phone within a second — that is the whole demo, and it is why
// the guest screen no longer runs on a timer.
const TILL = [
  { name: "Red Bull", unitCents: 800 },
  { name: "Still water", unitCents: 500 },
  { name: "Mixer", unitCents: 1000 },
  { name: "Fruit platter", unitCents: 8000 },
  { name: "Grey Goose (1L)", unitCents: 35000 },
  { name: "Hennessy VS", unitCents: 40000 },
  { name: "Moët & Chandon", unitCents: 45000 },
  { name: "Dom Pérignon", unitCents: 70000 },
];

export default function StaffTable({ params }) {
  const [t, setT] = useState(null);
  const router = useRouter();

  const load = useCallback(async () => {
    const r = await fetch(`/api/demo/state?tableId=${params.tableId}`, { cache: "no-store" });
    const d = await r.json();
    setT(d.table);
  }, [params.tableId]);

  useEffect(() => {
    load();
    const id = setInterval(load, 2000);
    return () => clearInterval(id);
  }, [load]);

  async function act(body) {
    const r = await fetch("/api/demo/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tableId: params.tableId, ...body }),
    });
    const d = await r.json();
    if (d.table) setT(d.table);
  }

  if (!t) {
    return (
      <div className="demo-staff flex min-h-dvh items-center justify-center bg-black">
        <p className="text-white/40">Loading…</p>
      </div>
    );
  }

  const spent = ordersTotal(t.lines || []);
  const ceiling = t.depositCents + t.holdCents;
  const plan = settlementPlan({
    billCents: spent,
    depositCents: t.depositCents,
    authorizedCents: t.holdCents,
  });
  const over = spent > t.depositCents;

  return (
    <div className="demo-staff min-h-dvh bg-black px-5 pb-16 pt-6">
      <div className="mx-auto max-w-[560px]">
        <button
          onClick={() => router.push("/demo/staff")}
          className="mb-5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 hover:text-white"
        >
          ← Floor
        </button>

        <div className="flex items-baseline justify-between">
          <h1 className="text-[26px] font-black uppercase tracking-[-0.02em] text-white">
            {t.name}
          </h1>
          <span className="text-[10px] uppercase tracking-[0.2em] text-white/35">{t.zone}</span>
        </div>

        <Card className="mt-4 border-solid border-white/10 bg-[#0d0d0f]">
          <CardContent className="p-4">
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] uppercase tracking-[0.2em] text-white/40">Spent</span>
              <span
                className={`font-mono text-[26px] font-bold ${
                  over ? "text-[#f5a623]" : "text-[#e3c68a]"
                }`}
              >
                {eur(spent)} €
              </span>
            </div>
            <Separator className="my-3 bg-white/10" />
            <Row l="Deposit" r={`${eur(t.depositCents)} €`} />
            <Row l="Hold" r={`${eur(t.holdCents)} €`} />
            <Row l="Headroom left" r={`${eur(Math.max(0, ceiling - spent))} €`} />
          </CardContent>
        </Card>

        {t.status === "free" && (
          <Button
            onClick={() => act({ action: "open" })}
            className="mt-4 h-14 w-full rounded-full bg-white text-[12px] font-extrabold uppercase tracking-[0.16em] text-black hover:bg-white/90"
          >
            Open table
          </Button>
        )}

        {t.status === "open" && (
          <>
            <div className="mb-3 mt-6 flex items-baseline justify-between">
              <h2 className="text-[10px] font-semibold uppercase tracking-[0.26em] text-white/40">
                Add to the tab
              </h2>
              <button
                onClick={() => act({ action: "undo" })}
                className="text-[9px] font-bold uppercase tracking-[0.18em] text-white/35 hover:text-white"
              >
                Undo last
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {TILL.map((item) => (
                <button
                  key={item.name}
                  onClick={() => act({ action: "add", line: { ...item, qty: 1 } })}
                  className="flex min-h-[56px] items-center justify-between gap-2 rounded border border-solid border-white/10 bg-white/[0.03] px-3 text-left text-[13px] text-white hover:border-white/35"
                >
                  <span className="leading-tight">{item.name}</span>
                  <span className="shrink-0 font-mono text-[11px] text-[#e3c68a]">
                    {eur(item.unitCents)} €
                  </span>
                </button>
              ))}
            </div>

            {t.lines.length > 0 && (
              <ul className="mt-6">
                {t.lines.map((l) => (
                  <li
                    key={l.id}
                    className="flex items-baseline justify-between border-b border-solid border-white/[0.07] py-2.5 text-[13px] text-white/75"
                  >
                    <span>
                      {l.qty > 1 && <span className="text-white/40">{l.qty}× </span>}
                      {l.name}
                    </span>
                    <span className="font-mono text-[12px] text-[#e3c68a]">
                      {eur(lineTotal(l))} €
                    </span>
                  </li>
                ))}
              </ul>
            )}

            <Button
              onClick={() => act({ action: "close" })}
              disabled={spent <= 0}
              className="mt-6 h-14 w-full rounded-full bg-[#e3c68a] text-[12px] font-extrabold uppercase tracking-[0.14em] text-[#17120a] hover:bg-[#e3c68a]/90 disabled:opacity-30"
            >
              Close bill · charge {eurExact(plan.totalTakenCents)} €
            </Button>
            <p className="mt-2 text-center text-[11px] leading-relaxed text-white/35">
              {eurExact(t.depositCents)} € deposit + {eurExact(plan.captureCents)} € from the
              hold · {eurExact(plan.releaseCents)} € released
            </p>
          </>
        )}

        {t.status === "closed" && (
          <p className="mt-6 text-[13px] leading-relaxed text-white/50">
            Closed. The guest sees the receipt on their phone.
          </p>
        )}
      </div>
    </div>
  );
}

function Row({ l, r }) {
  return (
    <div className="flex items-baseline justify-between py-1">
      <span className="text-[11px] uppercase tracking-[0.16em] text-white/40">{l}</span>
      <span className="font-mono text-[13px] text-white/80">{r}</span>
    </div>
  );
}
