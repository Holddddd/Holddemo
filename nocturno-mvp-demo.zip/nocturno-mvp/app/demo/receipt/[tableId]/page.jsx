"use client";

import { useEffect, useState } from "react";
import { settlementPlan } from "@/lib/deposit";
import { VENUE, holdFor, eurExact, lineTotal, ordersTotal, getDemoTable } from "@/lib/demo/fixtures";

// The receipt. Deliberately a plain printable page rather than a generated
// PDF: it prints to paper, saves to PDF from the browser's own print
// dialog, and works with no service and no network — which is more than a
// server-side PDF gives you and is one less thing to fail in a bar.
export default function ReceiptPage({ params }) {
  const table = getDemoTable(params.tableId);
  const [live, setLive] = useState(null);

  useEffect(() => {
    fetch(`/api/demo/state?tableId=${params.tableId}`, { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => setLive(d.table))
      .catch(() => {});
  }, [params.tableId]);

  if (!table) return <main style={{ padding: 40 }}>Table not found.</main>;

  const lines = live?.lines || [];
  const spent = ordersTotal(lines);
  const deposit = table.depositCents;
  const hold = holdFor(table);
  const plan = settlementPlan({ billCents: spent, depositCents: deposit, authorizedCents: hold });

  return (
    <main
      style={{
        background: "#fff",
        color: "#000",
        minHeight: "100dvh",
        padding: "32px 22px 60px",
        fontFamily: "var(--font-ui)",
      }}
    >
      <div style={{ maxWidth: 420, margin: "0 auto" }}>
        <div style={{ textAlign: "center", marginBottom: 26 }}>
          <div style={{ fontWeight: 900, fontSize: 17, textTransform: "uppercase" }}>
            {VENUE.name}
          </div>
          <div style={{ fontSize: 9, letterSpacing: "0.4em", marginTop: 6, color: "#666" }}>
            {VENUE.city.toUpperCase()}
          </div>
        </div>

        <div style={{ fontSize: 12, color: "#666", marginBottom: 18 }}>
          {table.name} · {table.zone}
          {live?.closedAt ? ` · ${new Date(live.closedAt).toLocaleString("es-ES")}` : ""}
        </div>

        {lines.map((l) => (
          <Line key={l.id} left={`${l.qty > 1 ? `${l.qty}× ` : ""}${l.name}`} right={eurExact(lineTotal(l))} />
        ))}

        <div style={{ borderTop: "1px solid #000", margin: "14px 0 10px" }} />
        <Line left="Total ordered" right={eurExact(spent)} bold />

        <div style={{ height: 18 }} />
        <Line left="Deposit paid" right={eurExact(deposit)} />
        <Line left="Charged from hold" right={eurExact(plan.captureCents)} />
        {plan.unusedDepositCents > 0 && (
          <Line left="Unused minimum (not refunded)" right={eurExact(plan.unusedDepositCents)} muted />
        )}

        <div style={{ borderTop: "2px solid #000", margin: "12px 0 10px" }} />
        <Line left="TOTAL CHARGED" right={eurExact(plan.totalTakenCents)} bold big />

        {plan.releaseCents > 0 && (
          <p style={{ fontSize: 12, lineHeight: 1.6, color: "#444", marginTop: 16 }}>
            {eurExact(plan.releaseCents)} € of the {eurExact(hold)} € hold was never charged and
            has been released back to your card.
          </p>
        )}

        <p style={{ fontSize: 11, color: "#888", marginTop: 26, textAlign: "center" }}>
          Demo receipt · no payment was processed
        </p>

        <button
          onClick={() => window.print()}
          style={{
            display: "block",
            width: "100%",
            marginTop: 26,
            padding: "16px",
            background: "#000",
            color: "#fff",
            border: 0,
            borderRadius: 999,
            fontSize: 11,
            fontWeight: 800,
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            cursor: "pointer",
          }}
          className="no-print"
        >
          Print / save as PDF
        </button>
      </div>

      <style>{`@media print { .no-print { display: none } }`}</style>
    </main>
  );
}

function Line({ left, right, bold, big, muted }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        gap: 12,
        padding: "5px 0",
        fontSize: big ? 17 : 13.5,
        fontWeight: bold ? 700 : 400,
        color: muted ? "#888" : "#000",
      }}
    >
      <span>{left}</span>
      <span style={{ fontVariantNumeric: "tabular-nums", whiteSpace: "nowrap" }}>{right} €</span>
    </div>
  );
}
