"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { settlementPlan } from "@/lib/deposit";
import {
  VENUE,
  holdFor,
  eur,
  eurExact,
  lineTotal,
  ordersTotal,
} from "@/lib/demo/fixtures";

export default function TabScreen({ table }) {
  const [live, setLive] = useState(null);

  // Polls the shared server state rather than running a timer of its own.
  // The bar now moves because a waiter tapped something on the tablet —
  // which is the thing worth showing a club, and the thing a self-running
  // animation could never demonstrate.
  useEffect(() => {
    let stop = false;
    const tick = async () => {
      try {
        const r = await fetch(`/api/demo/state?tableId=${table.id}`, { cache: "no-store" });
        const d = await r.json();
        if (!stop && d.table) setLive(d.table);
      } catch {}
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => {
      stop = true;
      clearInterval(id);
    };
  }, [table.id]);

  const lines = live?.lines || [];
  const closed = live?.status === "closed";

  const deposit = table.depositCents;
  const hold = holdFor(table);
  const spent = ordersTotal(lines);

  // The same function production settles with — the numbers on this screen
  // are the real arithmetic, only the payment is theatre.
  const plan = settlementPlan({
    billCents: spent,
    depositCents: deposit,
    authorizedCents: hold,
  });

  if (closed) return <Closed table={table} lines={lines} spent={spent} plan={plan} hold={hold} />;

  const overDeposit = spent > deposit;
  const depositUsed = Math.min(spent, deposit);
  // Clamped to what was actually authorised. Without the cap a table that
  // outruns its hold reads as "1512 € taken from a 1200 € hold", which is
  // not a thing that can happen — anything past the ceiling is unsecured
  // and is a shortfall for staff to collect, not money already reserved.
  const fromHold = Math.min(Math.max(0, spent - deposit), hold);
  const holdLeft = Math.max(0, hold - fromHold);
  const unsecured = Math.max(0, spent - deposit - hold);

  // Two different questions, so two different bars: below the deposit the
  // guest is spending money they have already paid; above it they are
  // eating into an authorization. Colour carries which one they're in.
  const pct = overDeposit
    ? Math.min((fromHold / hold) * 100, 100)
    : (spent / deposit) * 100;

  return (
    <div className="demo-guest px-5 pb-28 pt-9">
      <div className="mx-auto w-full max-w-[440px]">
        <header className="mb-7 text-center">
          <div className="text-[15px] font-black uppercase leading-none tracking-[0.02em]">
            {VENUE.name}
          </div>
          <div className="mt-2 text-[9px] font-semibold uppercase tracking-[0.44em] text-white/40">
            {table.name} · {table.zone}
          </div>
        </header>

        <div className="mb-2 text-[10px] font-semibold uppercase tracking-[0.26em] text-white/40">
          Spent so far
        </div>
        <div
          className={`text-[clamp(46px,15vw,64px)] font-extrabold leading-none tracking-[-0.045em] ${
            overDeposit ? "text-[#f5a623]" : "text-[#e3c68a]"
          }`}
          style={{ fontVariantNumeric: "tabular-nums" }}
        >
          {eur(spent)} €
        </div>

        <div className="mt-5 h-2 w-full overflow-hidden rounded-full bg-white/[0.08]">
          <div
            className={`h-full rounded-full transition-all duration-700 ${
              overDeposit ? "bg-[#f5a623]" : "bg-[#e3c68a]"
            }`}
            style={{ width: `${pct}%` }}
          />
        </div>

        {!overDeposit ? (
          <div className="mt-3 flex items-baseline justify-between text-[12px]">
            <span className="text-white/50">
              of <b className="text-white/80">{eur(deposit)} €</b> deposit
            </span>
            <span className="text-white/80">
              Free: <b className="demo-money">{eur(deposit - spent)} €</b>
            </span>
          </div>
        ) : (
          <div className="mt-3 flex items-baseline justify-between text-[12px]">
            <span className="text-[#f5a623]">Deposit {eur(deposit)} € used up</span>
            <span className="text-white/60">
              hold left <b className="text-white/85">{eur(holdLeft)} €</b> of {eur(hold)} €
            </span>
          </div>
        )}

        {overDeposit && (
          <Card className="mt-5 border-[#f5a623]/40 bg-[#f5a623]/[0.06]">
            <CardContent className="p-4">
              <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-[#f5a623]">
                Now drawing on the hold
              </p>
              <p className="mt-2 text-[13px] leading-relaxed text-white/70">
                Your {eur(deposit)} € deposit is spent. Anything further comes out of the{" "}
                {eur(hold)} € reserved on your card — {eur(fromHold)} € so far, {eur(holdLeft)} €
                still available. Nothing beyond what you order is ever charged.
              </p>
              {unsecured > 0 && (
                <p className="mt-3 text-[13px] font-semibold leading-relaxed text-[#ff5a5a]">
                  {eur(unsecured)} € of this table is beyond what your card has authorised. Ask
                  staff to raise the hold before ordering more.
                </p>
              )}
            </CardContent>
          </Card>
        )}

        {/* Live itemised bill. Appears as the waiter rings each round in. */}
        <div className="mt-8 mb-3 flex items-baseline justify-between">
          <h2 className="text-[10px] font-semibold uppercase tracking-[0.26em] text-white/40">
            On your table
          </h2>
          <Badge
            variant="outline"
            className="border-white/15 text-[9px] uppercase tracking-[0.18em] text-white/35"
          >
            live
          </Badge>
        </div>

        {lines.length === 0 ? (
          <p className="py-6 text-center text-[13px] text-white/35">
            Nothing yet — your first round will appear here.
          </p>
        ) : (
          <ul>
            {lines.map((l) => (
              <li
                key={l.id}
                className="flex items-baseline justify-between border-b border-white/[0.07] py-3 text-[14px]"
              >
                <span className="text-white/80">
                  {l.qty > 1 && <span className="text-white/45">{l.qty}× </span>}
                  {l.name}
                </span>
                <span className="demo-money font-mono text-[13px]">{eur(lineTotal(l))} €</span>
              </li>
            ))}
          </ul>
        )}

        <Card className="mt-6 border-white/10 bg-[#0d0d0f]">
          <CardContent className="p-4">
            <Row label="Deposit paid" value={`${eurExact(deposit)} €`} />
            <Separator className="my-3 bg-white/10" />
            <Row label="Of it used" value={`${eurExact(depositUsed)} €`} />
            <Row label="Taken from hold" value={`${eurExact(fromHold)} €`} muted={!fromHold} />
          </CardContent>
        </Card>
      </div>

    </div>
  );
}

function Row({ label, value, muted }) {
  return (
    <div className="flex items-baseline justify-between py-1">
      <span className="text-[11px] uppercase tracking-[0.18em] text-white/40">{label}</span>
      <span className={`font-mono text-[13px] ${muted ? "text-white/30" : "demo-money"}`}>
        {value}
      </span>
    </div>
  );
}

// SCREEN 5 — what the guest sees once the manager closes the table.
function Closed({ table, lines, spent, plan, hold }) {
  const deposit = table.depositCents;

  return (
    <div className="demo-guest px-5 pb-16 pt-16">
      <div className="mx-auto w-full max-w-[440px]">
        <div className="mb-6 flex h-12 w-12 items-center justify-center rounded-full border border-white/25 text-[20px]">
          ✓
        </div>
        <h1 className="text-[clamp(36px,11vw,48px)] font-black uppercase leading-[0.9] tracking-[-0.035em]">
          Table closed
        </h1>
        <p className="mt-4 text-[14px] leading-relaxed text-white/60">
          Thanks for tonight. Here is exactly what was taken and what goes back.
        </p>

        <Card className="mt-7 border-white/10 bg-[#0d0d0f]">
          <CardContent className="p-5">
            <Row label="Deposit" value={`${eurExact(deposit)} €`} />
            <Row label="Taken from hold" value={`${eurExact(plan.captureCents)} €`} />
            <Separator className="my-3 bg-white/10" />
            <div className="flex items-baseline justify-between py-1">
              <span className="text-[11px] font-bold uppercase tracking-[0.18em] text-white">
                Charged in total
              </span>
              <span className="demo-money font-mono text-[20px] font-bold">
                {eurExact(plan.totalTakenCents)} €
              </span>
            </div>
          </CardContent>
        </Card>

        {plan.releaseCents > 0 && (
          <p className="mt-4 text-[13px] leading-relaxed text-white/60">
            <b className="text-white/85">{eurExact(plan.releaseCents)} €</b> of the {eur(hold)} €
            hold was never charged and is released — it drops off your statement within a few
            days, with nothing for you to do.
          </p>
        )}

        {plan.unusedDepositCents > 0 && (
          <p className="mt-3 text-[13px] leading-relaxed text-white/45">
            You spent {eurExact(spent)} € of the {eurExact(deposit)} € minimum. As agreed at the
            start, the unused {eurExact(plan.unusedDepositCents)} € is not refunded.
          </p>
        )}

        <Button
          size="lg"
          onClick={() => window.open(`/demo/receipt/${table.id}`, "_blank")}
          className="mt-7 h-14 w-full rounded-full bg-white text-[12px] font-extrabold uppercase tracking-[0.16em] text-black hover:bg-white/90"
        >
          Get receipt
        </Button>
        <Button
          variant="ghost"
          className="mt-2 h-12 w-full text-[11px] uppercase tracking-[0.18em] text-white/45 hover:bg-white/5 hover:text-white"
        >
          Email it to me
        </Button>

        <p className="mt-6 text-center text-[11px] text-white/30">
          Demo · no money moved.
        </p>
      </div>
    </div>
  );
}

