import { getDemoTable } from "@/lib/demo/fixtures";
import TabScreen from "./TabScreen";

// SCREEN 3 — the live spend tracker, and SCREEN 5 — the closed receipt.
// Same page: the guest never navigates, the screen changes under them when
// the manager closes the table.
export default function DemoTabPage({ params }) {
  const table = getDemoTable(params.tableId);

  if (!table) {
    return (
      <div className="demo-guest flex min-h-dvh items-center justify-center p-10">
        <p className="text-white/60">That code doesn&apos;t match a table here.</p>
      </div>
    );
  }

  return <TabScreen table={table} />;
}
