import "./demo.css";

// Everything under /demo is mock data and client-side state: no Stripe
// call, no write to the database, no PIN. Refreshing the page resets it,
// which is exactly what you want between two meetings.
export const metadata = {
  title: "Demo · Club Nocturno",
  robots: { index: false, follow: false },
};

export default function DemoLayout({ children }) {
  return <>{children}</>;
}
