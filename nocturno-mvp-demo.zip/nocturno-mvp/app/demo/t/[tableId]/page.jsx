import { getDemoTable } from "@/lib/demo/fixtures";
import Landing from "./Landing";

// SCREEN 1 — what the guest sees the instant they scan the sticker.
export default function DemoLandingPage({ params }) {
  const table = getDemoTable(params.tableId);

  if (!table) {
    return (
      <div className="demo-guest flex min-h-dvh items-center justify-center p-10">
        <p className="text-white/60">That code doesn&apos;t match a table here.</p>
      </div>
    );
  }

  return <Landing table={table} />;
}
