"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { VENUE, holdFor, eur } from "@/lib/demo/fixtures";

export default function Landing({ table }) {
  const [agreed, setAgreed] = useState(false);
  const router = useRouter();

  const hold = holdFor(table);

  return (
    <div className="demo-guest px-5 pb-12 pt-9">
      <div className="mx-auto w-full max-w-[440px]">
        <header className="mb-9 text-center">
          <div className="text-[17px] font-black uppercase leading-none tracking-[0.02em]">
            {VENUE.name}
          </div>
          <div className="mt-2 text-[9px] font-semibold uppercase tracking-[0.44em] text-white/40">
            {VENUE.city}
          </div>
        </header>

        <div className="mb-2 flex items-center gap-3">
          <Badge
            variant="outline"
            className="border-white/20 text-[9px] font-semibold uppercase tracking-[0.24em] text-white/50"
          >
            {table.zone} · {table.seats} seats
          </Badge>
        </div>

        <h1 className="mb-8 text-[clamp(40px,13vw,56px)] font-black uppercase leading-[0.88] tracking-[-0.04em]">
          {table.name}
        </h1>

        {/* The two numbers, and the difference between them, is the entire
            product. Deposit is money that leaves tonight; the hold is not. */}
        <Card className="border-white/10 bg-[#0d0d0f]">
          <CardContent className="p-5">
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
                Deposit
              </span>
              <span className="demo-money text-[38px] font-extrabold leading-none tracking-[-0.03em]">
                {eur(table.depositCents)} €
              </span>
            </div>

            <Separator className="my-4 bg-white/10" />

            <div className="flex items-baseline justify-between">
              <span className="text-[10px] font-semibold uppercase tracking-[0.24em] text-white/40">
                Held on your card
              </span>
              <span className="font-mono text-[15px] text-white/70">{eur(hold)} €</span>
            </div>

            <p className="mt-4 text-[13px] leading-relaxed text-white/60">
              The deposit is your minimum spend and is charged now.{" "}
              <span className="text-white/85">
                Any part of it you don&apos;t drink is not refunded.
              </span>{" "}
              The {eur(hold)} € is a temporary hold for anything above it — not a charge, and
              whatever you don&apos;t use is released.
            </p>
          </CardContent>
        </Card>

        {/* Consent is its own act, separate from paying. The wording names
            the non-refundable part in the sentence the guest ticks, not in
            small print somewhere below the button. */}
        <label className="mt-6 flex cursor-pointer items-start gap-3">
          <Checkbox
            checked={agreed}
            onCheckedChange={(v) => setAgreed(v === true)}
            // border-solid is explicit on purpose: `appearance: none` makes
            // the browser drop a button's border style, and a width with no
            // style computes to zero — which left the consent box invisible.
            className="mt-0.5 h-5 w-5 border-2 border-solid border-white/40 data-[state=checked]:border-white data-[state=checked]:bg-white data-[state=checked]:text-black"
          />
          <span className="text-[13px] leading-relaxed text-white/60">
            I agree to a minimum spend of{" "}
            <b className="demo-money font-semibold">{eur(table.depositCents)} €</b>, charged now
            and not refunded if unused, and to a hold of up to{" "}
            <b className="font-semibold text-white/85">{eur(hold)} €</b> on my card for anything
            beyond it.
          </span>
        </label>

        <Button
          size="lg"
          disabled={!agreed}
          onClick={() => router.push(`/demo/pay/${table.id}`)}
          className="mt-6 h-14 w-full rounded-full bg-white text-[12px] font-extrabold uppercase tracking-[0.16em] text-black hover:bg-white/90 disabled:opacity-30"
        >
          Pay {eur(table.depositCents)} €
        </Button>

        <p className="mt-3 text-center text-[11px] text-white/35">
          Demo — no card is charged.
        </p>
      </div>
    </div>
  );
}
