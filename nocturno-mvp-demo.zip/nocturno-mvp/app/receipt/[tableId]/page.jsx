import { getTable } from "@/lib/db";
import { canSeeBooking } from "@/lib/auth";
import { buildReceipt } from "@/lib/receipt";
import styles from "./receipt.module.css";
import { getT } from "@/lib/i18n/server";

function money(cents, currency = "eur") {
  return `${new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format((cents || 0) / 100)} ${currency.toUpperCase()}`;
}

// The paper copy. A guest who wants something physical prints this from
// their own phone, or a manager prints it at the till.
//
// Light on white, not the venue's black — a receipt is a document, and
// printing 200 mm of near-black through somebody's inkjet to hand them a
// grey smudge is not a design choice, it is ignoring what the page is for.
export default function ReceiptPage({ params, searchParams }) {
  const t = getT("guest");
  const table = getTable(params.tableId);
  if (!table) {
    return <main className={styles.page}>{t("common.tableNotFound")}</main>;
  }

  // A receipt lists what somebody drank and what they paid. Token-gated
  // exactly like the bill it describes.
  if (!canSeeBooking(table, searchParams?.t)) {
    return (
      <main className={styles.page}>
        <p>{t("receipt.badLink")}</p>
      </main>
    );
  }

  if (table.status !== "closed") {
    return (
      <main className={styles.page}>
        <p>{t("receipt.notClosed")}</p>
      </main>
    );
  }

  const r = buildReceipt(table);
  const m = (c) => money(c, r.currency);

  return (
    <main className={styles.page}>
      <article className={styles.receipt}>
        <header className={styles.head}>
          <h1 className={styles.venue}>{r.venue}</h1>
          <p className={styles.city}>{r.city}</p>
        </header>

        <dl className={styles.meta}>
          <div>
            <dt>{t("receipt.table")}</dt>
            <dd>{r.tableName}</dd>
          </div>
          {r.guestName && (
            <div>
              <dt>{t("receipt.name")}</dt>
              <dd>{r.guestName}</dd>
            </div>
          )}
          <div>
            <dt>{t("receipt.reference")}</dt>
            <dd className="mono">{r.reference}</dd>
          </div>
          <div>
            <dt>{t("receipt.closed")}</dt>
            <dd>{new Date(r.closedAt).toLocaleString("es-ES")}</dd>
          </div>
        </dl>

        <table className={styles.lines}>
          <tbody>
            {r.items.map((i) => (
              <tr key={i.id}>
                <td>
                  {i.qty > 1 ? `${i.qty}× ` : ""}
                  {i.name}
                </td>
                <td className={styles.amount}>{m(i.totalCents)}</td>
              </tr>
            ))}
            {r.adjustments.map((a, idx) => (
              <tr key={`adj-${idx}`}>
                <td>{a.name === "Manual adjustment" ? t("receipt.adjustment") : a.name}</td>
                <td className={styles.amount}>
                  {a.totalCents < 0 ? "−" : "+"}
                  {m(Math.abs(a.totalCents))}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <table className={styles.totals}>
          <tbody>
            <tr>
              <td>{t("receipt.bill")}</td>
              <td className={styles.amount}>{m(r.billCents)}</td>
            </tr>
            {r.cashCents > 0 && (
              <tr>
                <td>{t("receipt.paidCash")}</td>
                <td className={styles.amount}>{m(r.cashCents)}</td>
              </tr>
            )}
            {r.tipCents > 0 && (
              <tr>
                <td>{t("receipt.tip")}</td>
                <td className={styles.amount}>{m(r.tipCents)}</td>
              </tr>
            )}
            <tr>
              <td>{t("receipt.chargedCard")}</td>
              <td className={styles.amount}>{m(r.cardCents)}</td>
            </tr>
            {r.refundedCents > 0 && (
              <tr>
                <td>{t("receipt.refunded")}</td>
                <td className={styles.amount}>−{m(r.refundedCents)}</td>
              </tr>
            )}
            <tr className={styles.grand}>
              <td>{t("receipt.totalPaid")}</td>
              <td className={styles.amount}>{m(r.totalPaidCents)}</td>
            </tr>
          </tbody>
        </table>

        <p className={styles.note}>{t("receipt.note")}</p>
        {/* Said plainly. A document that looks like an invoice without
            being one is the kind of thing an accountant discovers in
            April. */}
        <p className={styles.legal}>{t("receipt.legal")}</p>
      </article>
    </main>
  );
}
