import { getTable } from "@/lib/db";
import { canApproveTopUp } from "@/lib/auth";
import { getT } from "@/lib/i18n/server";
import TopUpScreen from "./TopUpScreen";

export default function TopUpPage({ params, searchParams }) {
  const t = getT("guest");
  const table = getTable(params.tableId);
  if (!table) {
    return <main style={{ padding: 40 }}>{t("common.tableNotFound")}</main>;
  }

  // This screen leads to money being reserved on a card, so the table id
  // alone is not enough to open it — the link carries the booking token,
  // or the short-lived top-up token from the SMS. Checking only the booking
  // token here, while the API accepted both, turned every SMS link into
  // "this link isn't valid" — the page refused what the server allowed.
  if (!canApproveTopUp(table, searchParams?.t)) {
    return (
      <main style={{ padding: 40, maxWidth: 420, margin: "0 auto" }}>
        <p style={{ color: "var(--coral)", lineHeight: 1.6 }}>{t("topup.badLink")}</p>
      </main>
    );
  }

  return <TopUpScreen tableId={table.id} bookingToken={searchParams?.t || null} />;
}
