"use client";

import { useCallback, useEffect, useState } from "react";
import { useApproveTopUp } from "@/app/components/useApproveTopUp";
import styles from "./topup.module.css";
import { useLang } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";

const VENUE_NAME = "CLUB NOCTURNO";

function eurExact(cents) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format((cents || 0) / 100);
}

// The consent screen. The guest is standing in a loud room with a phone in
// one hand, so it says one number, one sentence about what it is not, and
// one button.
//
// The card issuer's 3-D Secure challenge runs on top of this — which is
// the point. An SMS link alone proves somebody with the link approved it;
// 3DS proves it was the cardholder.
export default function TopUpScreen({ tableId, bookingToken }) {
  const { t, lang } = useLang();
  const [state, setState] = useState(null);
  const [loadErr, setLoadErr] = useState(null);
  const [done, setDone] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch(
      `/api/topup?tableId=${tableId}&t=${encodeURIComponent(bookingToken || "")}`
    );
    const data = await res.json();
    if (!res.ok) {
      setLoadErr(apiError(t, lang, data, res.status, "topup.errLoad"));
      return;
    }
    setState(data);
  }, [tableId, bookingToken, t, lang]);

  useEffect(() => {
    load();
  }, [load]);

  // Shared with the guest's table page — the confirm → 3DS → server-verify
  // sequence must be identical on both, so it lives in one hook.
  const { approve, busy, err } = useApproveTopUp({
    tableId,
    bookingToken,
    onDone: () => setDone(true),
  });

  return (
    <div className={styles.shell}>
      <header className={styles.venueBar}>
        <span className={styles.venueMark}>{VENUE_NAME}</span>
        <span className={styles.venueCity}>{t("venue.city")}</span>
      </header>

      <main className={styles.sheet}>
        {!state && !loadErr && <p className={styles.note}>{t("common.loading")}</p>}

        {state && (
          <>
            <p className={styles.eyebrow}>
              {state.tableName}
              {state.guestName ? ` · ${state.guestName}` : ""}
            </p>

            {done || state.topUp?.status === "done" ? (
              <>
                <div className={styles.seal}>✓</div>
                <h1 className={styles.title}>{t("topup.approved")}</h1>
                <p className={styles.note}>{t("topup.approvedText")}</p>
              </>
            ) : state.topUp?.status === "pending" ? (
              <>
                <h1 className={styles.title}>
                  {t("topup.title1")}
                  <br />
                  {t("topup.title2")}
                </h1>

                <div className={styles.amountBox}>
                  <span className={`mono ${styles.amount}`}>
                    {eurExact(state.topUp.amountCents)} €
                  </span>
                  <span className={styles.amountLabel}>{t("topup.toReserve")}</span>
                </div>

                {/* Said before the button, not after. This is the only
                    screen in the product where the guest is asked to
                    increase what is held, so it is the only place the
                    distinction between a hold and a charge has to land. */}
                <div className={styles.notice}>
                  <p className={styles.noticeTitle}>{t("topup.notPayment")}</p>
                  <p className={styles.noticeText}>{t("topup.notPaymentText")}</p>
                </div>

                <p className={styles.note}>{t("topup.bankMayAsk")}</p>

                {err && <p className={styles.err}>{err}</p>}

                <button className={styles.cta} onClick={approve} disabled={busy}>
                  {busy ? t("topup.confirming") : t("topup.approve", { amount: eurExact(state.topUp.amountCents) })}
                </button>
                <p className={styles.reassure}>{t("topup.canRefuse")}</p>
              </>
            ) : (
              <>
                <h1 className={styles.title}>{t("topup.nothing")}</h1>
                <p className={styles.note}>
                  {state.topUp?.status === "expired"
                    ? t("topup.expired")
                    : state.topUp?.status === "declined"
                      ? t("topup.declined")
                      : t("topup.noOpen")}
                </p>
              </>
            )}
          </>
        )}

        {loadErr && !state && <p className={styles.err}>{loadErr}</p>}
      </main>
    </div>
  );
}
