import { LangProvider } from "@/app/components/i18n/LangProvider";
import { getLang } from "@/lib/i18n/server";

// The guest side's language — chosen separately from the staff side's.
// Adds the language button; changes nothing else on the page.
export default function Layout({ children }) {
  return (
    <LangProvider area="guest" initialLang={getLang("guest")}>
      {children}
    </LangProvider>
  );
}
