import { getTable } from "@/lib/db";
import { DEFAULT_BUFFER_MULTIPLIER } from "@/lib/config";
import BookingForm from "./BookingForm";
import styles from "./book.module.css";
import { getT } from "@/lib/i18n/server";

export default function BookPage({ params }) {
  const table = getTable(params.tableId);

  if (!table) {
    return (
      <main className={styles.wrap}>
        <p>{getT("guest")("common.tableNotFound")}</p>
      </main>
    );
  }

  return (
    <main className={styles.wrap}>
      <BookingForm table={table} bufferMultiplier={DEFAULT_BUFFER_MULTIPLIER} />
    </main>
  );
}
