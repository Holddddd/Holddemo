"use client";

import { useEffect, useMemo, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";
import { Elements, PaymentElement, useStripe, useElements } from "@stripe/react-stripe-js";
import { cutoffLabel } from "@/lib/nightclock";
import { useLang, useT } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";
import styles from "./book.module.css";

// `.catch` here is not defensive clutter. Without it this promise rejects
// unhandled whenever js.stripe.com cannot be reached, and the guest is left
// on a card step with no card field and a Confirm button that never
// enables — no message, nothing to do, and the table still held in their
// name.
//
// It is not a rare case either: an ad blocker, a hotel or corporate
// network, or a phone dropping signal all produce it, and a club's guests
// are on exactly those networks. Resolving to null lets the UI say so.
const stripePromise = loadStripe(
  process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY || ""
).catch(() => null);

// White-label: a club replaces this with their own name. Everything else
// is driven by CSS variables, so re-skinning per venue is a token swap.
const VENUE_NAME = "CLUB NOCTURNO";

// Stripe renders in an iframe we cannot style with our stylesheet, so the
// token values are mirrored here by hand. If globals.css changes, this
// changes with it — otherwise the card field is the one element on the
// page still wearing the old palette.
const stripeAppearance = {
  theme: "night",
  variables: {
    colorPrimary: "#FFFFFF",
    colorBackground: "#141416",
    colorText: "#FFFFFF",
    colorTextSecondary: "rgba(255,255,255,0.60)",
    colorTextPlaceholder: "rgba(255,255,255,0.36)",
    colorDanger: "#FF5A5A",
    fontFamily: "Archivo, sans-serif",
    borderRadius: "3px",
    spacingUnit: "4px",
  },
  // Colours only, no layout. The uppercase wide-tracked labels and the
  // custom input padding that used to live here were the only thing this
  // app injected into Stripe's own iframe, and a card field that won't
  // take the expiry date is not worth a matching letter-spacing. If the
  // field ever misbehaves again, it is not because of anything here.
  rules: {
    ".Input:focus": { boxShadow: "none" },
  },
};

// Stripe draws the card fields itself and supports Spanish but not
// Ukrainian — its locale list has no "uk". English is the fallback there;
// substituting Russian for a Ukrainian speaker is not a neutral choice.
const STRIPE_LOCALE = { en: "en", es: "es", uk: "en" };

function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

export default function BookingForm({ table, bufferMultiplier }) {
  const { t, lang } = useLang();
  const [step, setStep] = useState("name");
  const [guestName, setGuestName] = useState("");
  const [guestPhone, setGuestPhone] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [clientSecret, setClientSecret] = useState(null);
  const [bookingToken, setBookingToken] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);
  // Null from stripePromise means Stripe.js never loaded — see above.
  const [stripeDown, setStripeDown] = useState(false);

  useEffect(() => {
    let live = true;
    stripePromise.then((s) => {
      if (live && !s) setStripeDown(true);
    });
    return () => {
      live = false;
    };
  }, []);

  // THE ROOT CAUSE of "after entering the card, nothing else works".
  //
  // `<Elements options={{ ... }}>` with an inline object literal hands
  // react-stripe-js a new object identity on every render. It compares
  // options by reference and calls elements.update() whenever they
  // "change", which re-applies appearance to the mounted card Element and
  // knocks out focus mid-typing. Nothing is disabled and nothing is
  // covering it — the element is being reset underneath the cursor.
  //
  // Memoised on clientSecret, so update() fires only when the intent
  // genuinely changes.
  //
  // The locale joins it: switching language is the one other moment the
  // card field should be re-rendered.
  const elementsOptions = useMemo(
    () => ({ clientSecret, appearance: stripeAppearance, locale: STRIPE_LOCALE[lang] || "en" }),
    [clientSecret, lang]
  );

  const minCents = table.minSpendCents;
  const capCents = Math.round(table.minSpendCents * bufferMultiplier);

  async function startVerification(e) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/setup-intent", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tableId: table.id, guestName, guestPhone, guestEmail }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(apiError(t, lang, data, res.status, "book.errGeneric"));
      setClientSecret(data.clientSecret);
      setBookingToken(data.bookingToken);
      setStep("card");
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className={styles.shell}>
      <header className={styles.venueBar}>
        <span className={styles.venueMark}>{VENUE_NAME}</span>
        <span className={styles.venueCity}>{t("venue.city")}</span>
      </header>

      {step === "done" ? (
        <DoneScreen
          table={table}
          guestName={guestName}
          capCents={capCents}
          bookingToken={bookingToken}
        />
      ) : (
        <main className={styles.sheet}>
          <p className={styles.eyebrow}>{table.name}</p>
          <h1 className={styles.title}>
            {t("book.title1")}
            <br />
            {t("book.title2")}
          </h1>

          <Gauge minCents={minCents} capCents={capCents} />

          {/* Name and phone stay on screen and stay editable once the card
              form appears. They used to live on a separate step, which is
              why "the other fields are unreachable" was reported: they
              weren't disabled, they were gone. */}
          <form onSubmit={startVerification} className={styles.form}>
            <label className={styles.label} htmlFor="guestName">
              {t("book.nameLabel")}
            </label>
            <input
              id="guestName"
              value={guestName}
              onChange={(e) => setGuestName(e.target.value)}
              placeholder={t("book.namePlaceholder")}
              autoComplete="name"
              required
            />

            <label className={styles.label} htmlFor="guestPhone">
              {t("book.phoneLabel")} <span className={styles.optional}>{t("common.optional")}</span>
            </label>
            <input
              id="guestPhone"
              type="tel"
              value={guestPhone}
              onChange={(e) => setGuestPhone(e.target.value)}
              placeholder="+34 600 000 000"
              autoComplete="tel"
            />
            <p className={styles.fieldNote}>{t("book.phoneNote")}</p>

            <label className={styles.label} htmlFor="guestEmail">
              {t("book.emailLabel")} <span className={styles.optional}>{t("common.optional")}</span>
            </label>
            <input
              id="guestEmail"
              type="email"
              value={guestEmail}
              onChange={(e) => setGuestEmail(e.target.value)}
              placeholder="you@example.com"
              autoComplete="email"
            />
            <p className={styles.fieldNote}>{t("book.emailNote")}</p>

            {error && <p className={styles.error}>{error}</p>}

            {step === "name" && (
              <>
                <button className={styles.cta} type="submit" disabled={loading}>
                  {loading ? t("book.loading") : t("book.continue")}
                </button>
                <p className={styles.reassure}>{t("book.reassure")}</p>
              </>
            )}
          </form>

          {step === "card" && clientSecret && stripeDown && (
            <div className={styles.stripeDown} role="alert">
              <p className={styles.stripeDownTitle}>{t("book.stripeDownTitle")}</p>
              <p>{t("book.stripeDownText")}</p>
              <button
                type="button"
                className={styles.secondaryBtn}
                onClick={() => window.location.reload()}
              >
                {t("book.reload")}
              </button>
            </div>
          )}

          {step === "card" && clientSecret && !stripeDown && (
            <Elements stripe={stripePromise} options={elementsOptions}>
              <CardStep
                table={table}
                bookingToken={bookingToken}
                minCents={minCents}
                capCents={capCents}
                onDone={() => setStep("done")}
              />
            </Elements>
          )}
        </main>
      )}
    </div>
  );
}

/* The signature element. It is not decoration — it is the entire product
   argument in one graphic: you owe the gold part, we may hold up to the
   dashed part, and you will never be charged past the line at the end. */
function Gauge({ minCents, capCents }) {
  const t = useT();
  const minPct = (minCents / capCents) * 100;

  return (
    <section className={styles.gauge} aria-label={t("book.gaugeAria")}>
      <div className={styles.gaugeHead}>
        <div>
          <div className={styles.gaugeFigure}>
            {eur(minCents)}
            <span className={styles.gaugeCur}>€</span>
          </div>
          <div className={styles.gaugeCaption}>{t("book.minConsumption")}</div>
        </div>
        <div className={styles.gaugeHeadRight}>
          <div className={styles.gaugeFigureGhost}>
            {eur(capCents)}
            <span className={styles.gaugeCur}>€</span>
          </div>
          <div className={styles.gaugeCaption}>{t("book.holdCeiling")}</div>
        </div>
      </div>

      <div className={styles.track}>
        <div className={styles.trackFill} style={{ width: `${minPct}%` }} />
        <div className={styles.trackHeadroom} style={{ left: `${minPct}%` }} />
        <div className={styles.trackCeiling} />
      </div>

      <p className={styles.gaugeNote}>{t("book.gaugeNote")}</p>
    </section>
  );
}

function CardStep({ table, minCents, capCents, bookingToken, onDone }) {
  const { t, lang } = useLang();
  const stripe = useStripe();
  const elements = useElements();
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!stripe || !elements || !agreed) return;
    setLoading(true);
    setError(null);

    const { error: confirmError, setupIntent } = await stripe.confirmSetup({
      elements,
      redirect: "if_required",
    });

    if (confirmError) {
      setError(confirmError.message);
      setLoading(false);
      return;
    }

    if (setupIntent && setupIntent.status === "succeeded") {
      const res = await fetch("/api/setup-intent-confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tableId: table.id, bookingToken }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(apiError(t, lang, data, res.status, "book.errFinalize"));
        setLoading(false);
        return;
      }
      onDone();
    } else {
      setError(t("book.errIncomplete", { status: setupIntent?.status }));
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      {/* Said plainly and said first. Handing a card to a nightclub before
          you have set foot in it is the moment the booking gets abandoned,
          and the consent checkbox below is legal wording, not comfort. */}
      <div className={styles.notice}>
        <p className={styles.noticeTitle}>{t("book.noticeTitle")}</p>
        <p className={styles.noticeText}>
          {t("book.noticeText", { cap: <b className="mono">{eur(capCents)} €</b> })}
        </p>
      </div>

      <div className={styles.cardWrap}>
        <PaymentElement />
      </div>

      <label className={styles.terms}>
        <input
          type="checkbox"
          checked={agreed}
          onChange={(e) => setAgreed(e.target.checked)}
          className={styles.checkbox}
        />
        <span>
          {t("book.consent", {
            cap: <b className="mono">{eur(capCents)} €</b>,
            min: <b className="mono">{eur(minCents)} €</b>,
          })}
        </span>
      </label>

      {error && <p className={styles.error}>{error}</p>}

      <button className={styles.cta} type="submit" disabled={!stripe || !agreed || loading}>
        {loading ? t("book.verifying") : t("book.confirm")}
      </button>
    </form>
  );
}

function DoneScreen({ table, guestName, capCents, bookingToken }) {
  const t = useT();
  const q = bookingToken ? `?t=${bookingToken}` : "";
  return (
    <main className={styles.sheet}>
      <div className={styles.seal}>✓</div>
      <p className={styles.eyebrow}>{table.name}</p>
      <h1 className={styles.title}>{t("book.doneTitle")}</h1>
      <p className={styles.doneText}>
        {guestName ? t("book.doneTextNamed", { name: guestName }) : t("book.doneText")}
      </p>

      {/* No floor plan here. Publishing the room to a guest hands out the
          venue's live inventory — which tables are sold, which are empty,
          what each one costs — to anyone with a booking link. The guest has
          exactly one table, the one they booked, and a host walks them to
          it. The plan is a staff instrument and lives on /staff. */}
      <section className={styles.locator}>
        <p className={styles.blockLabel}>{t("book.yourTable")}</p>
        {/* The name already carries the zone ("Mesa 7 · Reservado"), so
            printing table.zone alongside it says Reservado twice. */}
        <p className={styles.locatorMeta}>{t("book.seats", { name: table.name, n: table.seats })}</p>
      </section>

      {/* The code is the check-in. Kept on a white plate because a QR
          inverted onto black scans on some phones and fails on others. */}
      <section className={styles.ticket}>
        <div className={styles.qrPlate}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            className={styles.qr}
            src={`/api/checkin-qr/${table.id}${q}`}
            alt={t("book.qrAlt", { name: table.name })}
            width={132}
            height={132}
          />
        </div>
        <div>
          <p className={styles.blockLabel}>{t("book.checkinCode")}</p>
          <p className={styles.ticketText}>{t("book.ticketText")}</p>
          {/* Stated on the confirmation, not discovered at the door. The
              table is released after this, and a guest who was never told
              is a guest who argues about it on the step — correctly. */}
          <p className={styles.ticketWarn}>{t("book.arriveBy", { time: cutoffLabel() })}</p>
        </div>
      </section>
      <div className={styles.doneRow}>
        <span className={styles.doneRowLabel}>{t("book.holdOnArrival")}</span>
        <span className={`mono ${styles.doneRowValue}`}>{eur(capCents)} €</span>
      </div>
      {/* The same URL is the live tab once staff check them in, so it is
          worth keeping — this is the link they will actually use all night. */}
      <a className={styles.cta} href={`/table/${table.id}${q}`}>
        {t("book.openMyTable")}
      </a>
      <p className={styles.reassure}>{t("book.keepLink")}</p>
    </main>
  );
}
