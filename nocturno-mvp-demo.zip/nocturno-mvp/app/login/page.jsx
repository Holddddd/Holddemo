import { authConfigured } from "@/lib/auth";
import LoginForm from "./LoginForm";

export default function LoginPage({ searchParams }) {
  return (
    <LoginForm configured={authConfigured()} next={searchParams?.next || "/staff"} />
  );
}
