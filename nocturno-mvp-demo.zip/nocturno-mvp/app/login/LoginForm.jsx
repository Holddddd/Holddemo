"use client";

import { useState } from "react";
import styles from "./login.module.css";
import { useLang } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";

export default function LoginForm({ configured, next }) {
  const { t, lang } = useLang();
  const [pin, setPin] = useState("");
  const [err, setErr] = useState(null);
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(apiError(t, lang, data, res.status, "login.err"));
        setBusy(false);
        return;
      }
      // Full navigation rather than a router push: the destination reads
      // the session cookie on the server, so it has to be a fresh request.
      window.location.href = next;
    } catch (e) {
      setErr(e.message);
      setBusy(false);
    }
  }

  return (
    <main className={styles.wrap}>
      <div className={styles.venueBar}>
        <span className={styles.venueMark}>Club Nocturno</span>
        <span className={styles.venueCity}>{t("venue.city")}</span>
      </div>

      <h1 className={styles.title}>{t("login.title")}</h1>

      {configured ? (
        <form onSubmit={submit} className={styles.form}>
          <label className={styles.label} htmlFor="pin">
            {t("login.pin")}
          </label>
          <input
            id="pin"
            className={styles.pin}
            type="password"
            inputMode="numeric"
            autoComplete="off"
            autoFocus
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            required
          />
          {err && <p className={styles.err}>{err}</p>}
          <button className={styles.cta} type="submit" disabled={busy}>
            {busy ? t("login.checking") : t("login.signIn")}
          </button>
        </form>
      ) : (
        <p className={styles.notConfigured}>
          {t("login.notConfigured", {
            pin: <code>STAFF_PIN</code>,
            secret: <code>AUTH_SECRET</code>,
            env: <code>.env.local</code>,
          })}
        </p>
      )}
    </main>
  );
}
