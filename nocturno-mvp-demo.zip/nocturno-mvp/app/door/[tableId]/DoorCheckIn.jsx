"use client";

import { useState } from "react";
import { cutoffLabel } from "@/lib/nightclock";
import styles from "./door.module.css";
import { useLang } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";
import { reasonText } from "@/lib/i18n/reasons";

function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

// What the doorman sees after scanning the guest's confirmation code.
// Deliberately one screen and one button: this is used standing up, in a
// queue, holding someone else's phone.
export default function DoorCheckIn({ initialTable, bufferMultiplier }) {
  const { t, lang } = useLang();
  const [table, setTable] = useState(initialTable);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  // Appears only once the server has actually refused for being past the
  // cutoff — the doorman shouldn't be looking at an override all night.
  const [needsOverride, setNeedsOverride] = useState(false);

  const holdCents = Math.round(table.minSpendCents * bufferMultiplier);

  async function checkIn(force = false) {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/checkin", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tableId: table.id, bufferMultiplier, force }),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(apiError(t, lang, data, res.status, "door.errFailed"));
        if (data.code === "past_cutoff") setNeedsOverride(true);
      } else {
        setTable(data.table);
        setNeedsOverride(false);
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className={styles.wrap}>
      <p className={styles.eyebrow}>{t("door.eyebrow")}</p>

      <h1 className={styles.name}>{table.name}</h1>
      <p className={styles.guest}>
        {t("door.guestLine", {
          name: table.guestName || t("door.noName"),
          zone: table.zone,
          n: table.seats,
        })}
      </p>

      {table.status === "card_saved" && (
        <>
          <dl className={styles.specs}>
            <div>
              <dt>{t("door.minimum")}</dt>
              <dd className={`mono ${styles.money}`}>{eur(table.minSpendCents)} €</dd>
            </div>
            <div>
              <dt>{t("door.holdToPlace")}</dt>
              <dd className={`mono ${styles.money}`}>{eur(holdCents)} €</dd>
            </div>
          </dl>

          <button className={styles.primary} onClick={() => checkIn(false)} disabled={busy}>
            {busy ? t("checkin.placing") : t("checkin.button")}
          </button>
          <p className={styles.note}>{t("door.note", { time: cutoffLabel() })}</p>

          {needsOverride && (
            <button
              className={styles.override}
              onClick={() => {
                if (
                  window.confirm(t("checkin.overrideConfirm", { time: cutoffLabel() }))
                ) {
                  checkIn(true);
                }
              }}
              disabled={busy}
            >
              {t("checkin.override")}
            </button>
          )}
        </>
      )}

      {table.status === "checked_in" && (
        <>
          <div className={styles.ok}>{t("door.checkedIn")}</div>
          <dl className={styles.specs}>
            <div>
              <dt>{t("door.holdPlaced")}</dt>
              <dd className={`mono ${styles.money}`}>{eur(table.holdAmountCents || 0)} €</dd>
            </div>
          </dl>
          <a className={styles.primary} href={`/table/${table.id}`}>
            {t("door.openTable")}
          </a>
        </>
      )}

      {table.status === "available" && (
        <p className={styles.note}>{t("door.noBooking")}</p>
      )}
      {table.status === "pending_card" && (
        <p className={styles.note}>{t("door.pending")}</p>
      )}
      {table.status === "cancelled" && (
        <p className={styles.note}>
          {t("door.cancelled", { reason: reasonText(t, { label: table.cancelReason }) })}
        </p>
      )}
      {table.status === "closed" && <p className={styles.note}>{t("door.settled")}</p>}

      {err && <p className={styles.err}>{err}</p>}
    </main>
  );
}
