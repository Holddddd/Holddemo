import { redirect } from "next/navigation";
import { getTable } from "@/lib/db";
import { isStaff, bookingTokenValid } from "@/lib/auth";
import { DEFAULT_BUFFER_MULTIPLIER } from "@/lib/config";
import DoorCheckIn from "./DoorCheckIn";
import { getT } from "@/lib/i18n/server";

export default function DoorPage({ params, searchParams }) {
  const token = searchParams?.t;

  // The scan happens on a STAFF phone, so staff sign-in is the real gate.
  // The token in the QR isn't a credential — it just binds this scan to
  // one booking, which is why an invalid one is refused but a missing one
  // (staff typing the URL, or coming from the board) is fine.
  if (!isStaff()) {
    const next = `/door/${params.tableId}${token ? `?t=${token}` : ""}`;
    redirect(`/login?next=${encodeURIComponent(next)}`);
  }

  const table = getTable(params.tableId);
  if (!table) {
    return <main style={{ padding: 40 }}>{getT("staff")("common.tableNotFound")}</main>;
  }

  if (token && !bookingTokenValid(table, token)) {
    return (
      <main style={{ padding: 40, maxWidth: 420, margin: "0 auto" }}>
        <p style={{ color: "var(--coral)", lineHeight: 1.6 }}>
          {getT("staff")("door.badCode", { name: table.name })}
        </p>
      </main>
    );
  }

  return <DoorCheckIn initialTable={table} bufferMultiplier={DEFAULT_BUFFER_MULTIPLIER} />;
}
