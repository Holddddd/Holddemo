"use client";

import { useCallback, useEffect, useState } from "react";
import styles from "./staff.module.css";
import { MENU } from "@/lib/menu";
import {
  CANCEL_REASONS,
  CASH_LIMIT_CENTS,
  PENDING_CARD_TIMEOUT_MINUTES,
} from "@/lib/config";
import { minutesToCutoff, cutoffLabel } from "@/lib/nightclock";
import { useLang, useT } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";
import { reasonText } from "@/lib/i18n/reasons";
import StaffFloorMap from "./StaffFloorMap";
import StatsPanel from "./StatsPanel";

async function logout() {
  await fetch("/api/auth/logout", { method: "POST" });
  window.location.href = "/login";
}

// "Confirmed" was ambiguous on a shift — confirmed by whom, and is anyone
// sitting there? The board's job for that state is to say a booking exists
// and nobody has walked in yet, which is a table that must not be resold
// and must not be forgotten either.
const STATUS = {
  available: { label: "Free", tone: "idle" },
  pending_card: { label: "Card pending", tone: "idle" },
  card_saved: { label: "Booked", tone: "ready" },
  // Transient: the hold is being placed with Stripe right now.
  checking_in: { label: "Checking in…", tone: "ready" },
  checked_in: { label: "Live", tone: "live" },
  closed: { label: "Closed", tone: "done" },
  cancelled: { label: "Released", tone: "cancelled" },
};

// Rounded — for scanning figures (headroom, meter, menu prices), where
// whole euros read faster across a room and nobody is reconciling them.
function eur(cents) {
  return new Intl.NumberFormat("es-ES", { maximumFractionDigits: 0 }).format(cents / 100);
}

// Exact — for any figure that has to match the guest's receipt. Staff
// showing "523 €" against a receipt reading "522,50 €" is the same
// transaction described two ways, which is how a till dispute starts.
function eurExact(cents) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

// lib/nightclock's formatCountdown, in the chosen language. Same rule —
// minutes only once the door is under 90 minutes away — so English reads
// exactly as it did ("11h 37m").
function countdown(t, mins) {
  const m = Math.max(0, mins);
  if (m < 90) return t("cd.m", { m });
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return rem ? t("cd.hm", { h, m: rem }) : t("cd.h", { h });
}

// Whole minutes since an ISO timestamp, for the "entering a card" clock.
function minutesSince(iso) {
  return Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
}

export default function StaffDashboard() {
  const t = useT();
  const [tables, setTables] = useState([]);
  const [resetting, setResetting] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  // Computed after mount, never during render: the server and the browser
  // are at different instants, and a clock rendered on both sides is a
  // guaranteed hydration mismatch.
  const [minsLeft, setMinsLeft] = useState(null);
  // How long this night has been open. A shift nobody closed is why a
  // table can still be carrying yesterday's orders.
  const [shiftAgeHours, setShiftAgeHours] = useState(0);
  // The close-shift summary, and the result panel afterwards.
  const [confirmingShift, setConfirmingShift] = useState(false);
  const [shiftResult, setShiftResult] = useState(null);

  const refresh = useCallback(async () => {
    const res = await fetch("/api/tables");
    const data = await res.json();
    setTables(data.tables);
  }, []);

  useEffect(() => {
    refresh();
    // The floor changes without this tab doing anything — a guest can
    // finish their booking link mid-service. Poll so the board is never
    // stale in someone's hand.
    const id = setInterval(refresh, 5000);
    return () => clearInterval(id);
  }, [refresh]);

  useEffect(() => {
    fetch("/api/stats")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        const started = d?.shift?.startedAt;
        if (started) setShiftAgeHours((Date.now() - new Date(started).getTime()) / 3600000);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    const tick = () => setMinsLeft(minutesToCutoff());
    tick();
    const id = setInterval(tick, 30000);
    return () => clearInterval(id);
  }, []);

  // The map is a navigation control, not a second place to read numbers:
  // tapping a table takes you to the card that has the controls on it.
  const selectFromMap = useCallback((id) => {
    setSelectedId(id);
    document
      .getElementById(`table-card-${id}`)
      ?.scrollIntoView({ behavior: "smooth", block: "center" });
  }, []);

  // Settles every table still open, then marks the night finished. The
  // confirm is deliberate: this one moves real money on every live table
  // at once, and it is next to a button labelled "Reset demo".
  // Runs the shift close for real, once the summary has been read and
  // confirmed. The arithmetic is shown BEFORE this, not described in a
  // one-line confirm() nobody reads.
  async function closeShift() {
    setResetting(true);
    const res = await fetch("/api/auto-settle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close-shift" }),
    });
    const data = await res.json();
    setShiftResult(data);
    await refresh();
    setResetting(false);
  }

  // The same sweep a cron would call, on a button — settles tables that
  // went quiet and releases bookings that never arrived. Safe to press at
  // any point in the night: it only touches tables that qualify, which is
  // why it very often does nothing and should say so plainly rather than
  // looking broken.
  async function sweep() {
    setResetting(true);
    const res = await fetch("/api/auto-settle", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    setShiftResult(await res.json());
    await refresh();
    setResetting(false);
  }

  async function resetAll() {
    setResetting(true);
    await fetch("/api/tables", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reset" }),
    });
    await refresh();
    setResetting(false);
  }

  const live = tables.filter((t) => t.status === "checked_in");
  const booked = tables.filter((t) => t.status === "card_saved");
  const atRisk = live.filter(
    (t) => t.holdAmountCents && t.tabAmountCents / t.holdAmountCents >= 0.8
  ).length;

  const doorShut = minsLeft !== null && minsLeft <= 0;

  return (
    <main className={styles.wrap}>
      <header className={styles.bar}>
        <div className={styles.barLeft}>
          <h1 className={styles.h1}>{t("bar.floor")}</h1>
          <div className={styles.barStats}>
            <span>{t("bar.live", { n: <b>{live.length}</b> })}</span>
            {/* Booked-but-not-arrived is the number this product exists to
                make impossible to lose track of. */}
            <span className={booked.length > 0 ? styles.statBooked : undefined}>
              {t("bar.booked", { n: <b>{booked.length}</b> })}
            </span>
            <span className={atRisk > 0 ? styles.statAlert : undefined}>
              {t("bar.nearCeiling", { n: <b>{atRisk}</b> })}
            </span>
            {minsLeft !== null && (
              <span className={doorShut ? styles.statAlert : undefined}>
                {doorShut
                  ? t("bar.doorShut", { shut: <b>{t("bar.doorShutWord")}</b>, time: cutoffLabel() })
                  : t("bar.countdown", { left: <b>{countdown(t, minsLeft)}</b>, time: cutoffLabel() })}
              </span>
            )}
          </div>
        </div>
        <div className={styles.barActions}>
          {/* Every one of these gets a title, because three of them look
              broken when they are working correctly: they act only on
              tables that qualify, and most of the night none do. */}
          <a
            className={styles.reset}
            href="/board"
            target="_blank"
            rel="noreferrer"
            title={t("bar.wallBoardTitle")}
          >
            {t("bar.wallBoard")}
          </a>
          <button
            className={styles.reset}
            onClick={sweep}
            disabled={resetting}
            title={t("bar.sweepTitle")}
          >
            {t("bar.sweep")}
          </button>
          <button
            className={styles.reset}
            onClick={() => setConfirmingShift(true)}
            disabled={resetting}
            title={t("bar.closeShiftTitle")}
          >
            {t("bar.closeShift")}
          </button>
          <button
            className={styles.reset}
            onClick={resetAll}
            disabled={resetting}
            title={t("bar.resetDemoTitle")}
          >
            {resetting ? t("bar.resetting") : t("bar.resetDemo")}
          </button>
          <button className={styles.reset} onClick={logout} title={t("bar.signOutTitle")}>
            {t("bar.signOut")}
          </button>
        </div>
      </header>

      {/* A shift that has been open for most of a day is not a busy night,
          it is a sweep that never ran (README §4b — nothing calls
          /api/auto-settle on its own yet). Saying so beats letting staff
          wonder why a table claims to have ordered something "22h ago". */}
      {shiftAgeHours >= 12 && (
        <p className={styles.cutoffBanner}>{t("bar.shiftOld", { h: Math.round(shiftAgeHours) })}</p>
      )}

      {doorShut && booked.length > 0 && (
        <p className={styles.cutoffBanner}>
          {t("bar.noShows", { n: booked.length, time: cutoffLabel() })}
        </p>
      )}

      {confirmingShift && (
        <CloseShiftSheet
          tables={tables}
          busy={resetting}
          onCancel={() => setConfirmingShift(false)}
          onConfirm={async () => {
            setConfirmingShift(false);
            await closeShift();
          }}
        />
      )}

      {shiftResult && (
        <SweepResult result={shiftResult} onClose={() => setShiftResult(null)} />
      )}

      {tables.length > 0 && (
        <StaffFloorMap tables={tables} selectedId={selectedId} onSelect={selectFromMap} />
      )}

      <div className={styles.board}>
        {tables.map((t) => (
          <TableRow
            key={t.id}
            table={t}
            selected={t.id === selectedId}
            pastCutoff={doorShut}
            onChange={refresh}
          />
        ))}
      </div>

      {/* Last thing on the page on purpose: it is what you read at the end
          of a shift, not something to glance at mid-service. */}
      <StatsPanel />
    </main>
  );
}

// Shared by "booked" and "live" cards, because the reason a table is
// released is the same question in both cases — the only difference is
// whether there is a hold to void on the way out.
function CancelBox({ label, busy, onCancel }) {
  const t = useT();
  const [reason, setReason] = useState(CANCEL_REASONS[0].id);
  const [note, setNote] = useState("");

  const picked = CANCEL_REASONS.find((r) => r.id === reason);
  const isRefusal = Boolean(picked?.refusal);
  const needsNote = Boolean(picked?.needsNote);
  const missingNote = needsNote && !note.trim();

  return (
    <div className={styles.cancelBox} data-refusal={isRefusal || undefined}>
      <div className={styles.cancelRow}>
        <select
          className={styles.cancelSelect}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          aria-label={t("cancel.aria")}
        >
          {CANCEL_REASONS.map((r) => (
            <option key={r.id} value={r.id}>
              {reasonText(t, { id: r.id, label: r.label })}
            </option>
          ))}
        </select>
        <button
          className={styles.cancelBtn}
          disabled={busy || missingNote}
          onClick={() => onCancel(reason, note)}
        >
          {isRefusal ? t("cancel.refuse") : label}
        </button>
      </div>

      {/* Said before they commit, not after. Turning someone away creates a
          document with their name on it and sends them a message — staff
          should know that at the moment they pick the reason. */}
      {isRefusal && (
        <p className={styles.refusalWarn}>{t("cancel.official")}</p>
      )}

      <input
        className={styles.cancelNote}
        placeholder={
          needsNote ? t("cancel.noteRequired") : t("cancel.noteOptional")
        }
        value={note}
        onChange={(e) => setNote(e.target.value)}
        data-required={missingNote || undefined}
      />

      {missingNote && (
        <p className={styles.refusalWarn}>
          {t("cancel.conclusion", { label: reasonText(t, { id: picked.id, label: picked.label }) })}
        </p>
      )}
    </div>
  );
}

// What closing the night will actually do, with the arithmetic, BEFORE it
// does it.
//
// This replaces a one-line confirm(). Closing a shift captures money on
// every open table at once — it is the single largest action on this
// board — and "are you sure?" is not informed consent. Every figure here
// is computed from the same rules /api/auto-settle applies, so what is
// promised is what happens.
function CloseShiftSheet({ tables, busy, onCancel, onConfirm }) {
  const t = useT();
  const live = tables.filter((t) => t.status === "checked_in");
  const booked = tables.filter((t) => t.status === "card_saved" || t.status === "pending_card");

  // A table that ordered nothing is RELEASED, not charged — an idle empty
  // tab is a no-show, and no-show ≠ bill.
  const willCharge = live.filter((t) => (t.tabAmountCents || 0) > 0);
  const willRelease = live.filter((t) => (t.tabAmountCents || 0) <= 0);

  const sum = (rows, f) => rows.reduce((s, t) => s + f(t), 0);

  const billed = sum(willCharge, (t) => t.tabAmountCents || 0);
  const cash = sum(willCharge, (t) => t.cashAmountCents || 0);
  // The card can only ever be charged what it authorized. Anything the
  // bill exceeds that by cannot be taken by closing the shift.
  const onCard = sum(willCharge, (t) =>
    Math.min(
      Math.max(0, (t.tabAmountCents || 0) - (t.cashAmountCents || 0)),
      t.holdAmountCents || 0
    )
  );
  const short = billed - cash - onCard;
  const authorized = sum(live, (t) => t.holdAmountCents || 0);
  const releasing = authorized - onCard;

  return (
    <div className={styles.sheetOverlay} role="dialog" aria-modal="true" aria-label={t("shift.title")}>
      <div className={styles.shiftSheet}>
        <h2 className={styles.sheetTitle}>{t("shift.title")}</h2>

        {live.length === 0 && booked.length === 0 ? (
          <p className={styles.idle}>{t("shift.nothingOpen")}</p>
        ) : (
          <>
            <p className={styles.shiftLede}>{t("shift.lede")}</p>

            <ul className={styles.statsList}>
              <Row label={t("shift.charged", { n: willCharge.length })} value={`${eurExact(billed)} €`} />
              {cash > 0 && <Row label={t("shift.paidCash")} value={`−${eurExact(cash)} €`} />}
              <Row label={t("shift.fromCards")} value={`${eurExact(onCard)} €`} />
              {short > 0 && (
                <Row label={t("shift.notCovered")} value={`${eurExact(short)} €`} alert />
              )}
              <Row label={t("shift.holdsReleased")} value={`${eurExact(releasing)} €`} />
              {willRelease.length > 0 && (
                <Row
                  label={t("shift.releasedNothing", { n: willRelease.length })}
                  value={t("shift.noCharge")}
                />
              )}
              {booked.length > 0 && (
                <Row label={t("shift.neverArrived", { n: booked.length })} value={t("shift.releasedValue")} />
              )}
            </ul>

            {short > 0 && (
              <p className={styles.alertOver}>{t("shift.cannotTake", { amount: eurExact(short) })}</p>
            )}
          </>
        )}

        <button className={styles.close} disabled={busy} onClick={onConfirm}>
          {busy ? t("shift.settling") : t("shift.confirm", { amount: eurExact(onCard) })}
        </button>
        <button className={styles.ghost} disabled={busy} onClick={onCancel}>
          {t("common.notYet")}
        </button>
      </div>
    </div>
  );
}

// What a sweep or a shift-close actually did. Shown even when the answer
// is "nothing", because a button that silently does nothing is the one
// people report as broken.
function SweepResult({ result, onClose }) {
  const t = useT();
  const settled = result.settled || [];
  const takenCents = settled.reduce((s, r) => s + (r.capturedCents || 0), 0);
  const shortCents = settled.reduce((s, r) => s + Math.max(0, r.shortCents || 0), 0);
  const nothing =
    settled.length === 0 &&
    !(result.released || []).length &&
    !(result.expired || []).length &&
    !(result.stale || []).length;

  return (
    <div className={styles.sheetOverlay} role="dialog" aria-modal="true" aria-label={t("sweep.aria")}>
      <div className={styles.shiftSheet}>
        <h2 className={styles.sheetTitle}>{nothing ? t("sweep.nothingTitle") : t("sweep.doneTitle")}</h2>

        {nothing ? (
          <p className={styles.shiftLede}>{t("sweep.nothingText")}</p>
        ) : (
          <ul className={styles.statsList}>
            {settled.length > 0 && (
              <Row label={t("sweep.settled", { n: settled.length })} value={`${eurExact(takenCents)} €`} />
            )}
            {shortCents > 0 && (
              <Row label={t("sweep.short")} value={`${eurExact(shortCents)} €`} alert />
            )}
            {(result.released || []).length > 0 && (
              <Row
                label={t("shift.releasedNothing", { n: result.released.length })}
                value={t("shift.noCharge")}
              />
            )}
            {(result.expired || []).length > 0 && (
              <Row label={t("sweep.neverArrived", { n: result.expired.length })} value={t("shift.releasedValue")} />
            )}
            {(result.stale || []).length > 0 && (
              <Row label={t("sweep.cardNever", { n: result.stale.length })} value={t("sweep.freed")} />
            )}
            {(result.failed || []).length > 0 && (
              <Row label={t("sweep.failed", { n: result.failed.length })} value={t("sweep.checkStripe")} alert />
            )}
          </ul>
        )}

        <button className={styles.primary} onClick={onClose}>
          {t("common.close")}
        </button>
      </div>
    </div>
  );
}

function Row({ label, value, alert }) {
  return (
    <li>
      <span>{label}</span>
      <span className={`mono ${alert ? styles.rowAlert : styles.statsMoney}`}>{value}</span>
    </li>
  );
}

// Every line, when it landed, and who put it there.
//
// The grouped summary this replaces answered "what did they drink". It
// could not answer the questions that actually come up: when did the
// second bottle go on, was that rung in before or after the guest
// complained, did a waiter add it or did it come off the till. A dispute
// is always about a moment, so the log is per line and timestamped rather
// than rolled up.
//
// `by` is already recorded on every order (staff | guest). When the POS
// webhook replaces the hand-tapped menu it writes the same field, so this
// view is what the till feeds without changing.
function OrderLog({ orders, tabCents }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const lines = orders || [];

  if (lines.length === 0) return null;

  // Newest first: the thing being queried is nearly always the last one.
  const rows = [...lines].reverse();
  const shown = open ? rows : rows.slice(0, 4);

  return (
    <div className={styles.logBox}>
      <div className={styles.splitHead}>
        <span className={styles.menuLabel}>
          {t("log.rungIn", { n: lines.length, amount: eurExact(tabCents) })}
        </span>
        {rows.length > 4 && (
          <button className={styles.linkBtn} onClick={() => setOpen((v) => !v)}>
            {open ? t("log.showLess") : t("log.all", { n: rows.length })}
          </button>
        )}
      </div>

      <ul className={styles.logList}>
        {shown.map((o, i) => (
          <li key={`${o.id}-${o.at}-${i}`} data-adjustment={o.priceCents < 0 || undefined}>
            <span className={`mono ${styles.logTime}`}>
              {o.at
                ? new Date(o.at).toLocaleTimeString("es-ES", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                : "—"}
            </span>
            <span className={styles.logName}>
              {o.name}
              {/* Who put it on. A line the guest added themselves is a
                  different conversation from one a waiter rang in. */}
              <em>{o.by === "guest" ? t("log.byGuest") : o.by === "pos" ? t("log.byPos") : t("log.byStaff")}</em>
            </span>
            <span className={`mono ${styles.logPrice}`}>
              {o.priceCents < 0 ? "−" : ""}
              {eurExact(Math.abs(o.priceCents))} €
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

// More money on a table, two ways, and they are not variations of one
// thing — they are different mechanics with different risks:
//
//   CARD  a request. The guest approves on their phone and clears their
//         bank's 3-D Secure check. Nothing is reserved until they do, so
//         it can be refused or simply ignored.
//   CASH  already done. The notes are in the till, there is nothing to
//         verify and nobody to wait for — but the law caps how much of a
//         bill a business may take in notes, so this one can be refused
//         by the server rather than by the guest.
function MoreMoney({ table, busy, onAskCard, onTakeCash }) {
  const t = useT();
  const [mode, setMode] = useState("card");
  const [cashInput, setCashInput] = useState("");

  const cashTaken = table.cashAmountCents || 0;
  const cashRoom = Math.max(0, CASH_LIMIT_CENTS - cashTaken);
  const cents = Math.round((parseFloat(cashInput) || 0) * 100);
  const cashValid = cents > 0 && cents <= cashRoom;

  return (
    <div className={styles.moreBox}>
      <div className={styles.splitToggle}>
        <button data-active={mode === "card" || undefined} onClick={() => setMode("card")}>
          {t("more.card")}
        </button>
        <button data-active={mode === "cash" || undefined} onClick={() => setMode("cash")}>
          {t("more.cash")}
        </button>
      </div>

      {mode === "card" ? (
        <>
          <div className={styles.bumpRow}>
            {[250, 500, 1000].map((v) => (
              <button key={v} onClick={() => onAskCard(v)} disabled={busy} className={styles.bump}>
                +{v} €
              </button>
            ))}
          </div>
          <p className={styles.bumpNote}>{t("more.cardNote")}</p>
        </>
      ) : (
        <>
          <div className={styles.inputRow}>
            <input
              type="number"
              step="0.01"
              min="0"
              inputMode="decimal"
              placeholder={t("more.cashPlaceholder")}
              value={cashInput}
              onChange={(e) => setCashInput(e.target.value)}
            />
            <button
              className={styles.ghost}
              disabled={busy || !cashValid}
              onClick={async () => {
                const ok = await onTakeCash(cents);
                if (ok) setCashInput("");
              }}
            >
              {t("more.take")}
            </button>
          </div>
          <p className={styles.bumpNote}>
            {cashTaken > 0 && t("more.alreadyTaken", { amount: eurExact(cashTaken) })}
            {cashRoom > 0
              ? t("more.room", { room: eurExact(cashRoom), cap: eurExact(CASH_LIMIT_CENTS) })
              : t("more.full", { cap: eurExact(CASH_LIMIT_CENTS) })}
          </p>
        </>
      )}
    </div>
  );
}

// Giving money back after it was taken. Deliberately two steps and never
// prefilled with the full amount: a refund is days out of the club's
// balance and does not come back, so it should not be one tap away from a
// tired thumb. The common case is a bottle that was charged and never
// opened, not undoing the night.
function RefundBox({ table, busy, onRefund }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");

  const captured = table.capturedAmountCents || 0;
  const already = table.refundedAmountCents || 0;
  const refundable = captured - already;

  if (captured <= 0) return null;

  if (!open) {
    return (
      <>
        {already > 0 && (
          <div className={styles.tipRow}>
            <span className={styles.headroomLabel}>{t("refund.refunded")}</span>
            <span className="mono">−{eurExact(already)} €</span>
          </div>
        )}
        {refundable > 0 && (
          <button className={styles.ghost} disabled={busy} onClick={() => setOpen(true)}>
            {t("refund.open")}
          </button>
        )}
      </>
    );
  }

  const cents = Math.round((parseFloat(amount) || 0) * 100);
  const valid = cents > 0 && cents <= refundable;

  return (
    <div className={styles.refundBox}>
      <label className={styles.closeLabel} htmlFor={`refund-${table.id}`}>
        {t("refund.label", { amount: eurExact(refundable) })}
      </label>
      <div className={styles.inputRow}>
        <input
          id={`refund-${table.id}`}
          type="number"
          step="0.01"
          min="0"
          max={(refundable / 100).toFixed(2)}
          inputMode="decimal"
          placeholder={t("refund.amountPlaceholder")}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          autoFocus
        />
        <button className={styles.ghost} disabled={busy} onClick={() => setOpen(false)}>
          {t("common.cancel")}
        </button>
      </div>
      <input
        className={styles.cancelNote}
        placeholder={t("refund.reasonPlaceholder")}
        value={reason}
        onChange={(e) => setReason(e.target.value)}
      />
      <button
        className={styles.refundBtn}
        disabled={busy || !valid}
        onClick={async () => {
          if (
            !window.confirm(t("refund.confirm", { amount: eurExact(cents) }))
          ) {
            return;
          }
          const ok = await onRefund(cents, reason);
          if (ok) {
            setOpen(false);
            setAmount("");
            setReason("");
          }
        }}
      >
        {t("refund.do", { amount: eurExact(cents) })}
      </button>
    </div>
  );
}

function TableRow({ table, selected, pastCutoff, onChange }) {
  const { t, lang } = useLang();
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);
  const [tabInput, setTabInput] = useState("");
  const [closingBill, setClosingBill] = useState(false);
  const [finalInput, setFinalInput] = useState("");
  // Set when the server refuses a check-in for being past 01:00, so the
  // override appears only after the rule has actually bitten.
  const [needsOverride, setNeedsOverride] = useState(false);

  const status = STATUS[table.status]
    ? { ...STATUS[table.status], label: t(`status.${table.status}`) }
    : { label: table.status, tone: "idle" };
  const hold = table.holdAmountCents || 0;
  const tab = table.tabAmountCents || 0;
  // What the table can actually run to: the authorization plus notes
  // already taken. The same figure /api/order enforces against.
  const covered = hold + (table.cashAmountCents || 0);
  const someBlocked = MENU.some((i) => tab + i.priceCents > covered);
  // Money the table owes that nothing on file can pay. Until it is zero
  // the bill cannot be settled by anyone.
  const shortfall = Math.max(0, tab - covered);
  const headroom = hold - tab;
  const pct = hold > 0 ? Math.min((tab / hold) * 100, 100) : 0;

  // The one number that decides whether staff must act. Everything on this
  // card is arranged around making this readable at arm's length.
  const zone = hold === 0 ? "idle" : tab > hold ? "over" : pct >= 80 ? "warn" : "ok";

  async function call(path, body) {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      const data = await res.json();
      if (!res.ok) {
        setErr(apiError(t, lang, data, res.status, "row.errRequest"));
        if (data.code === "past_cutoff") setNeedsOverride(true);
      }
      await onChange();
      return res.ok;
    } finally {
      setBusy(false);
    }
  }

  const setTab = () => {
    const v = parseFloat(tabInput);
    if (isNaN(v) || v < 0) return;
    call("/api/tab", { tableId: table.id, tabAmountCents: Math.round(v * 100) });
    setTabInput("");
  };

  // Asks the guest, rather than reaching for their card. They get a link,
  // approve the amount and pass their bank's 3-D Secure check before
  // anything is reserved — see /api/topup.
  const askTopUp = (addEuros) =>
    call("/api/topup", { action: "request", tableId: table.id, amountCents: addEuros * 100 });

  const cancelTopUp = () => call("/api/topup", { action: "cancel", tableId: table.id });

  // Notes, taken at the table. No link, no 3-D Secure, nothing to wait for
  // — the money is in the till. Capped for the whole table by law.
  const takeCash = (cents) =>
    call("/api/topup", { action: "cash", tableId: table.id, amountCents: cents });

  const order = (itemId) => call("/api/order", { tableId: table.id, itemId });

  const cancel = (reason, note) => call("/api/cancel", { tableId: table.id, reason, note });

  const checkIn = (force = false) =>
    call("/api/checkin", { tableId: table.id, bufferMultiplier: 1.5, force });

  const reopen = () => call("/api/tables", { action: "reopen", tableId: table.id });

  const refund = (cents, reason) =>
    call("/api/refund", { tableId: table.id, amountCents: cents, reason });

  // Group repeated orders (e.g. two rounds of Chips) into one line with a
  // count, instead of listing every tap separately.
  const orderSummary = Object.values(
    (table.orders || []).reduce((acc, o) => {
      acc[o.id] = acc[o.id] || { ...o, qty: 0 };
      acc[o.id].qty += 1;
      return acc;
    }, {})
  );

  return (
    <section
      id={`table-card-${table.id}`}
      className={styles.card}
      data-zone={zone}
      data-selected={selected || undefined}
    >
      <div className={styles.cardHead}>
        <div>
          <h2 className={styles.name}>{table.name}</h2>
          {table.guestName && <p className={styles.guest}>{table.guestName}</p>}
        </div>
        <span className={styles.pill} data-tone={status.tone}>
          {status.label}
        </span>
      </div>

      {table.status === "checked_in" && (
        <>
          <div className={styles.readout}>
            <div className={styles.headroom} data-zone={zone}>
              <span className={`mono ${styles.headroomValue}`}>
                {headroom < 0 ? "−" : ""}
                {eur(Math.abs(headroom))} €
              </span>
              <span className={styles.headroomLabel}>
                {headroom < 0 ? t("row.overHold") : t("row.headroomLeft")}
              </span>
            </div>
          </div>

          <div className={styles.meter}>
            <div className={styles.meterFill} data-zone={zone} style={{ width: `${pct}%` }} />
          </div>
          <div className={styles.meterLabels}>
            <span className="mono">{t("row.tab", { amount: eur(tab) })}</span>
            <span className="mono">{t("row.hold", { amount: eur(hold) })}</span>
          </div>

          {zone === "warn" && <p className={styles.alertWarn}>{t("row.raiseNow")}</p>}

          {/* A table whose bill has outgrown its card cannot be closed by
              anyone — not the guest, not staff. Rather than leaving it
              stuck, the card states the gap and offers the only three ways
              out. Deliberately MANUAL: every one of them is somebody
              deciding who absorbs the difference, and software should not
              pick for them. The nightly sweep still captures what it can
              and records the shortfall, so nothing sits open forever. */}
          {shortfall > 0 && (
            <div className={styles.shortBox}>
              <div className={styles.splitHead}>
                <span className={styles.closeLabel}>{t("short.title")}</span>
                <span className={`mono ${styles.shortAmount}`}>{eurExact(shortfall)} €</span>
              </div>
              <p className={styles.bookedNote}>
                {t("short.text", { tab: eurExact(tab), covered: eurExact(covered) })}
              </p>
              <ol className={styles.shortSteps}>
                <li>{t("short.ask", { amount: eurExact(shortfall) })}</li>
                <li>{t("short.notes", { amount: eurExact(shortfall) })}</li>
                <li>{t("short.writeOff")}</li>
              </ol>
              <button
                className={styles.cancelBtn}
                disabled={busy}
                onClick={() => {
                  if (
                    window.confirm(
                      t("short.confirm", { amount: eurExact(shortfall), covered: eurExact(covered) })
                    )
                  ) {
                    // Recorded as an adjustment LINE, not a silent edit of
                    // the total — /api/tab keeps it in the order list where
                    // the next round can't quietly erase it.
                    call("/api/tab", { tableId: table.id, tabAmountCents: covered });
                  }
                }}
              >
                {t("short.button", { amount: eurExact(shortfall) })}
              </button>
            </div>
          )}

          {/* Raising the hold is a request now, not an action. Staff ask;
              the guest approves on their own phone and clears their bank's
              3-D Secure check. Slower — and the only version that is
              defensible while the guest cannot see their own tab. */}
          {table.topUp?.status === "pending" ? (
            <div className={styles.topUpBox}>
              <div className={styles.splitHead}>
                <span className={styles.closeLabel}>
                  {t("wait.label", { amount: eurExact(table.topUp.amountCents) })}
                </span>
                <button className={styles.linkBtn} disabled={busy} onClick={cancelTopUp}>
                  {t("wait.withdraw")}
                </button>
              </div>
              <p className={styles.bookedNote}>
                {table.topUp.requestedBy
                  ? t("wait.askedBy", {
                      time: new Date(table.topUp.requestedAt).toLocaleTimeString(),
                      name: table.topUp.requestedBy,
                    })
                  : t("wait.asked", { time: new Date(table.topUp.requestedAt).toLocaleTimeString() })}
              </p>
            </div>
          ) : (
            <MoreMoney
              table={table}
              busy={busy}
              onAskCard={askTopUp}
              onTakeCash={takeCash}
            />
          )}

          <div className={styles.menu}>
            <p className={styles.menuLabel}>{t("menu.label")}</p>

            <div className={styles.menuGrid}>
              {MENU.map((item) => {
                // Greyed out BEFORE it is tapped, not refused after. The
                // server enforces the same rule, but a waiter should see
                // which bottles this table can still afford rather than
                // finding out by being told no in front of the guest.
                const wouldExceed = tab + item.priceCents > covered;
                return (
                  <button
                    key={item.id}
                    className={styles.menuItem}
                    disabled={busy || wouldExceed}
                    data-blocked={wouldExceed || undefined}
                    title={
                      wouldExceed
                        ? t("menu.needs", { amount: eurExact(tab + item.priceCents - covered) })
                        : undefined
                    }
                    onClick={() => order(item.id)}
                  >
                    <span>{item.name}</span>
                    <span className="mono">{eur(item.priceCents)} €</span>
                  </button>
                );
              })}
            </div>

            {someBlocked && (
              <p className={styles.blockedNote}>{t("menu.blocked", { amount: eurExact(covered) })}</p>
            )}
          </div>

          <OrderLog orders={table.orders} tabCents={tab} />

          <div className={styles.inputRow}>
            <input
              type="number"
              inputMode="decimal"
              placeholder={t("row.manualPlaceholder")}
              value={tabInput}
              onChange={(e) => setTabInput(e.target.value)}
            />
            <button onClick={setTab} disabled={busy} className={styles.ghost}>
              {t("row.set")}
            </button>
          </div>

          {/* Closing the bill is the one action that takes real money, so
              it is two steps: name the amount, then confirm it. The field
              is prefilled with the running tab but staff can type anything
              up to what's authorized — the actual bill is the POS's
              number, not ours. */}
          {!closingBill ? (
            <button
              className={styles.close}
              disabled={busy || hold <= 0 || shortfall > 0}
              onClick={() => {
                setFinalInput((tab / 100).toFixed(2));
                setClosingBill(true);
              }}
            >
              {shortfall > 0 ? t("row.short", { amount: eurExact(shortfall) }) : t("row.closeBill")}
            </button>
          ) : (
            <div className={styles.closeBox}>
              <label className={styles.closeLabel} htmlFor={`final-${table.id}`}>
                {t("row.finalLabel", { amount: eurExact(hold) })}
              </label>
              <div className={styles.inputRow}>
                <input
                  id={`final-${table.id}`}
                  type="number"
                  step="0.01"
                  min="0"
                  max={(hold / 100).toFixed(2)}
                  inputMode="decimal"
                  value={finalInput}
                  onChange={(e) => setFinalInput(e.target.value)}
                  autoFocus
                />
                <button
                  className={styles.ghost}
                  disabled={busy}
                  onClick={() => setClosingBill(false)}
                >
                  {t("common.cancel")}
                </button>
              </div>
              <button
                className={styles.close}
                disabled={busy || !(parseFloat(finalInput) > 0) || parseFloat(finalInput) * 100 > hold}
                onClick={async () => {
                  const cents = Math.round(parseFloat(finalInput) * 100);
                  await call("/api/capture", { tableId: table.id, finalAmountCents: cents });
                  setClosingBill(false);
                }}
              >
                {t("row.charge", { amount: eurExact(Math.round((parseFloat(finalInput) || 0) * 100)) })}
              </button>
              <p className={styles.closeHint}>{t("row.restReleased", { amount: eurExact(hold) })}</p>
            </div>
          )}

          <a className={styles.guestLink} href={`/table/${table.id}`}>
            {t("row.guestView")}
          </a>

          <CancelBox label={t("cancel.releaseHold")} busy={busy} onCancel={cancel} />
        </>
      )}

      {table.status === "card_saved" && (
        <>
          {/* A booking nobody has walked into. The card's job here is to
              say "held for someone who isn't here yet" loudly enough that
              the table is neither resold nor forgotten. */}
          <div className={styles.bookedBox}>
            <span className={styles.headroomLabel}>{t("booked.label")}</span>
            <p className={styles.bookedNote}>
              {t("booked.min", {
                min: eur(table.minSpendCents),
                hold: eur(Math.round(table.minSpendCents * 1.5)),
              })}
            </p>
            <p className={styles.bookedNote}>{t("booked.scan")}</p>
          </div>

          {pastCutoff && !needsOverride && (
            <p className={styles.alertWarn}>{t("booked.noShow", { time: cutoffLabel() })}</p>
          )}

          <button className={styles.primary} disabled={busy} onClick={() => checkIn(false)}>
            {busy ? t("checkin.placing") : t("checkin.button")}
          </button>

          {/* Only after the server has actually refused. An override that
              is always on screen is not an override, it is a second
              check-in button. */}
          {needsOverride && (
            <button
              className={styles.ghost}
              disabled={busy}
              onClick={() => {
                if (
                  window.confirm(t("checkin.overrideConfirm", { time: cutoffLabel() }))
                ) {
                  checkIn(true);
                }
              }}
            >
              {t("checkin.override")}
            </button>
          )}

          <CancelBox label={t("cancel.releaseTable")} busy={busy} onCancel={cancel} />
        </>
      )}

      {table.status === "available" && (
        <p className={styles.idle}>{t("available.min", { min: eur(table.minSpendCents) })}</p>
      )}

      {/* A booking that started and stopped. The table is held so nobody
          else can take it, which is right for the two minutes it takes to
          type a card and wrong for the rest of the night — so it expires,
          and staff can free it sooner if somebody is standing at the door
          waiting for exactly this table. */}
      {table.status === "pending_card" && (
        <>
          <div className={styles.pendingBox}>
            <span className={styles.headroomLabel}>{t("pending.label")}</span>
            <p className={styles.bookedNote}>
              {table.pendingSince
                ? t("pending.textAgo", {
                    who: table.guestName || t("pending.someone"),
                    n: minutesSince(table.pendingSince),
                  })
                : t("pending.text", { who: table.guestName || t("pending.someone") })}
            </p>
            <p className={styles.bookedNote} data-dim>
              {t("pending.auto", { n: PENDING_CARD_TIMEOUT_MINUTES })}
            </p>
          </div>
          <button className={styles.ghost} disabled={busy} onClick={reopen}>
            {t("pending.free")}
          </button>
        </>
      )}

      {table.status === "closed" && (
        <>
          <div className={styles.closedRow}>
            <span className={styles.headroomLabel}>{t("closed.charged")}</span>
            <span className={`mono ${styles.closedValue}`}>
              {eurExact(table.capturedAmountCents || 0)} €
            </span>
          </div>
          {table.tipAmountCents > 0 && (
            <div className={styles.tipRow}>
              <span className={styles.headroomLabel}>{t("closed.ofTip")}</span>
              <span className="mono">{eurExact(table.tipAmountCents)} €</span>
            </div>
          )}
          {(table.serviceRating || table.guestComment) && (
            <div className={styles.feedback}>
              {table.serviceRating && (
                <p className={styles.stars} aria-label={t("closed.ratedAria", { n: table.serviceRating })}>
                  {"★".repeat(table.serviceRating)}
                  <span>{"★".repeat(5 - table.serviceRating)}</span>
                </p>
              )}
              {table.guestComment && <p className={styles.comment}>“{table.guestComment}”</p>}
            </div>
          )}
          <RefundBox table={table} busy={busy} onRefund={refund} />

          <button className={styles.ghost} disabled={busy} onClick={reopen}>
            {t("row.freeUp")}
          </button>
        </>
      )}

      {table.status === "cancelled" && (
        <>
          {/* A refusal is an official record, not a status. It is shown in
              full — reference, who decided, what they saw — because the
              call that comes the next day quotes the reference and asks
              exactly these questions. */}
          {table.refusal ? (
            <div className={styles.refusalBox}>
              <div className={styles.refusalHead}>
                <span className={styles.closeLabel}>{t("refusal.title")}</span>
                <span className={`mono ${styles.refusalRef}`}>{table.refusal.ref}</span>
              </div>
              <p className={styles.refusalReason}>
                {reasonText(t, { id: table.refusal.reasonId, label: table.refusal.label })}
              </p>
              {table.refusal.note && (
                <p className={styles.bookedNote}>“{table.refusal.note}”</p>
              )}
              <p className={styles.refusalMeta}>
                {table.refusal.by
                  ? t("refusal.decidedBy", {
                      date: new Date(table.refusal.at).toLocaleString(),
                      name: table.refusal.by,
                    })
                  : new Date(table.refusal.at).toLocaleString()}
              </p>
            </div>
          ) : (
            <p className={styles.idle}>{reasonText(t, { label: table.cancelReason })}</p>
          )}
          <button className={styles.ghost} disabled={busy} onClick={reopen}>
            {t("row.freeUp")}
          </button>
        </>
      )}

      {err && <p className={styles.err}>{err}</p>}

      {table.log?.length > 0 && (
        <details className={styles.log}>
          <summary>{t("log.activity", { n: table.log.length })}</summary>
          <ol>
            {table.log
              .slice()
              .reverse()
              .map((e, i) => (
                <li key={i}>
                  <span className="mono">
                    {new Date(e.at).toLocaleTimeString()}
                    {/* Who did it. The whole point of per-user PINs: a log
                        that records a comp but not who approved it answers
                        nothing the next morning. */}
                    {e.by ? ` · ${e.by}` : ""}
                  </span>{" "}
                  {e.line}
                </li>
              ))}
          </ol>
        </details>
      )}
    </section>
  );
}
