import { redirect } from "next/navigation";
import { isStaff } from "@/lib/auth";
import { LangProvider } from "@/app/components/i18n/LangProvider";
import { getLang } from "@/lib/i18n/server";

// The board is a client component, so the gate lives in a server layout
// above it. Checking here means the page's data never reaches the browser
// for someone who isn't signed in — a client-side redirect would ship it
// first and hide it second.
export default function StaffLayout({ children }) {
  if (!isStaff()) redirect("/login?next=/staff");
  // The staff side's language — chosen separately from the guests'.
  return (
    <LangProvider area="staff" initialLang={getLang("staff")}>
      {children}
    </LangProvider>
  );
}
