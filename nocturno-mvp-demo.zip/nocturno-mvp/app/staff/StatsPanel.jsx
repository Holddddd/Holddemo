"use client";

import { useState } from "react";
import styles from "./staff.module.css";
import { useLang } from "@/app/components/i18n/LangProvider";
import { apiError } from "@/lib/i18n/apiError";
import { reasonText } from "@/lib/i18n/reasons";

function eurExact(cents) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format((cents || 0) / 100);
}

// Tonight's numbers, on demand.
//
// The hard part of this screen is not the arithmetic — it is that a
// hold-based product breaks every habit an owner has from ordinary card
// takings. "232.500 € authorized" looks like a fortune and is not income;
// "90.000 € released" looks like a refund and is not a loss. So the panel
// leads with the one figure that IS money, states the tip separately
// because that belongs to somebody else, and labels the rest with what it
// actually means rather than with an accounting word that misleads.
export default function StatsPanel() {
  const { t, lang } = useLang();
  const [open, setOpen] = useState(false);
  const [stats, setStats] = useState(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(null);

  async function load() {
    setBusy(true);
    setErr(null);
    try {
      const res = await fetch("/api/stats");
      const data = await res.json();
      if (!res.ok) throw new Error(apiError(t, lang, data, res.status, "stats.errLoad"));
      setStats(data);
      setOpen(true);
    } catch (e) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  if (!open) {
    return (
      <section className={styles.statsLauncher}>
        <button className={styles.statsBtn} onClick={load} disabled={busy}>
          {busy ? t("stats.adding") : t("stats.open")}
        </button>
        {err && <p className={styles.err}>{err}</p>}
      </section>
    );
  }

  const m = stats.money;
  const tb = stats.tables;

  return (
    <section className={styles.statsPanel} aria-label={t("stats.open")}>
      <div className={styles.statsHead}>
        <h2 className={styles.mapTitle}>{t("stats.open")}</h2>
        <div className={styles.statsHeadActions}>
          <button className={styles.reset} onClick={load} disabled={busy}>
            {busy ? "…" : t("stats.refresh")}
          </button>
          <button className={styles.reset} onClick={() => setOpen(false)}>
            {t("common.close")}
          </button>
        </div>
      </div>

      {/* The headline. One number, and it is the only one that is money. */}
      <div className={styles.statsHero}>
        <span className={`mono ${styles.statsHeroValue}`}>{eurExact(m.netSalesCents)} €</span>
        <span className={styles.headroomLabel}>{t("stats.income")}</span>
      </div>

      <div className={styles.statsGrid}>
        <Figure
          label={t("stats.tips")}
          value={m.tipsCents}
          note={t("stats.tipsNote")}
        />
        <Figure
          label={t("stats.charged")}
          value={m.capturedCents}
          note={t("stats.chargedNote")}
        />
        <Figure
          label={t("stats.refunded")}
          value={m.refundedCents}
          note={t("stats.refundedNote")}
          tone={m.refundedCents > 0 ? "warn" : "ghost"}
        />
        <Figure
          label={t("stats.onHold")}
          value={m.onHoldCents}
          note={t("stats.onHoldNote")}
          tone="ghost"
        />
        <Figure
          label={t("stats.returned")}
          value={m.releasedCents}
          note={t("stats.returnedNote")}
          tone="ghost"
        />
        <Figure
          label={t("stats.authorized")}
          value={m.authorizedCents}
          note={t("stats.authorizedNote")}
          tone="ghost"
        />
        <Figure
          label={t("stats.uncollected")}
          value={m.uncollectedCents}
          note={t("stats.uncollectedNote")}
          tone={m.uncollectedCents > 0 ? "warn" : "ghost"}
        />
      </div>

      <div className={styles.statsSplit}>
        <div>
          <p className={styles.statsSectionLabel}>{t("stats.floor")}</p>
          <ul className={styles.statsList}>
            <Row label={t("stats.liveNow")} value={tb.live} />
            <Row label={t("stats.bookedNot")} value={tb.booked} />
            <Row label={t("stats.closed")} value={tb.closed} />
            <Row label={t("stats.releasedCancelled")} value={tb.cancelled} />
            <Row label={t("stats.free")} value={tb.free} />
            {tb.pendingCard > 0 && <Row label={t("stats.startedNoCard")} value={tb.pendingCard} />}
            <Row label={t("stats.avgClosed")} value={`${eurExact(tb.avgClosedSpendCents)} €`} />
            <Row label={t("stats.runningTabs")} value={`${eurExact(tb.liveTabCents)} €`} />
          </ul>
        </div>

        <div>
          <p className={styles.statsSectionLabel}>
            {t("stats.whyReleased", { n: stats.cancellations.total })}
          </p>
          {stats.cancellations.byReason.length === 0 ? (
            <p className={styles.idle}>{t("stats.nothingReleased")}</p>
          ) : (
            <ul className={styles.statsList}>
              {stats.cancellations.byReason.map((r) => (
                <Row key={r.reason} label={reasonText(t, { label: r.reason })} value={r.count} />
              ))}
            </ul>
          )}
        </div>
      </div>

      <div>
        <p className={styles.statsSectionLabel}>
          {t("stats.poured", {
            n: stats.products.itemsSold,
            amount: eurExact(stats.products.orderedCents),
          })}
        </p>
        {stats.products.lines.length === 0 ? (
          <p className={styles.idle}>{t("stats.nothingRung")}</p>
        ) : (
          <ul className={styles.statsList}>
            {stats.products.lines.map((p) => (
              <li key={p.id}>
                <span>
                  {p.qty}× {p.name}
                </span>
                <span className={`mono ${styles.statsMoney}`}>{eurExact(p.revenueCents)} €</span>
              </li>
            ))}
            {stats.products.adjustmentsCents !== 0 && (
              <li>
                <span>{t("stats.adjustments")}</span>
                <span className={`mono ${styles.statsMoney}`}>
                  {stats.products.adjustmentsCents > 0 ? "+" : "−"}
                  {eurExact(Math.abs(stats.products.adjustmentsCents))} €
                </span>
              </li>
            )}
          </ul>
        )}
      </div>

      <p className={styles.statsFoot}>{t("stats.foot")}</p>
    </section>
  );
}

function Figure({ label, value, note, tone }) {
  return (
    <div className={styles.figure} data-tone={tone}>
      <span className={`mono ${styles.figureValue}`}>{eurExact(value)} €</span>
      <span className={styles.figureLabel}>{label}</span>
      <span className={styles.figureNote}>{note}</span>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <li>
      <span>{label}</span>
      <span className={`mono ${styles.statsMoney}`}>{value}</span>
    </li>
  );
}
