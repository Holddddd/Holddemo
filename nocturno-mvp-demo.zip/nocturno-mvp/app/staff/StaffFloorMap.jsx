"use client";

import { useState } from "react";
import FloorPlanSvg, { spendRisk } from "@/app/components/FloorPlanSvg";
import { mapState } from "@/lib/floorplan";
import styles from "./staff.module.css";
import { useT } from "@/app/components/i18n/LangProvider";
import { reasonText } from "@/lib/i18n/reasons";

function eurExact(cents) {
  return new Intl.NumberFormat("es-ES", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format((cents || 0) / 100);
}

// The room, on the staff board — moved here from the guest side, where
// publishing the venue's live inventory to anyone holding a booking link
// was the wrong trade.
//
// It answers the question a list of cards can't: WHERE. "Table 6 is at 92%
// of its hold" is a row on a board; "the sofa in the far corner is about to
// run out" is a place you can walk to.
//
// Two layers of information, on purpose:
//   ALWAYS   every live table is coloured by how close it is to its
//            ceiling — gold, amber at 80%, coral once it is past. Readable
//            from across a room without touching anything.
//   ON HOVER the actual figures, in a panel rather than an SVG tooltip:
//            a tooltip that small is unreadable in a dark club, and it
//            would be clipped by the map's own viewBox.
const LEGEND = [
  { state: "free", label: "Free" },
  { state: "reserved", label: "Booked · not arrived" },
  { state: "live", label: "Live" },
  { state: "spent", label: "Closed" },
];

const RISK_COPY = {
  ok: { label: "Room left", tone: "ok" },
  warn: { label: "Near the ceiling", tone: "warn" },
  over: { label: "Over the hold", tone: "over" },
};

export default function StaffFloorMap({ tables, selectedId, onSelect }) {
  const t = useT();
  const [hoveredId, setHoveredId] = useState(null);

  const counts = tables.reduce((acc, t) => {
    const s = mapState(t.status);
    acc[s] = (acc[s] || 0) + 1;
    return acc;
  }, {});

  const atRisk = tables.filter((t) => {
    const r = spendRisk(t);
    return r === "warn" || r === "over";
  });

  const hovered = tables.find((t) => t.id === hoveredId) || null;

  return (
    <section className={styles.mapPanel} aria-label={t("map.aria")}>
      <div className={styles.mapHead}>
        <h2 className={styles.mapTitle}>{t("map.title")}</h2>
        <p className={styles.mapHint}>
          {atRisk.length > 0 ? t.plural("map.nearCeiling", atRisk.length) : t("map.point")}
        </p>
      </div>

      <FloorPlanSvg
        tables={tables}
        selectedId={selectedId}
        onSelect={onSelect}
        onHover={setHoveredId}
        showSpend
        label={t("map.svgLabel")}
        tableLabel={(tb, min) => t("map.tableAria", { name: tb.name, n: tb.seats, min })}
      />

      {/* Fixed height so the map doesn't jump as the pointer moves across
          it — a plan that reflows under the cursor is unusable. */}
      <div className={styles.hoverPanel} data-empty={!hovered || undefined}>
        {hovered ? <TableReadout table={hovered} /> : <span>{t("map.pointShort")}</span>}
      </div>

      <ul className={styles.mapLegend}>
        {LEGEND.map((l) => (
          <li key={l.state}>
            <span className={styles.mapSwatch} data-state={l.state} />
            {t(`map.${l.state}`)}
            <b>{counts[l.state] || 0}</b>
          </li>
        ))}
        <li>
          <span className={styles.mapSwatch} data-risk="warn" />
          {t("map.nearOver")}
          <b>{atRisk.length}</b>
        </li>
      </ul>
    </section>
  );
}

function TableReadout({ table }) {
  const t = useT();
  const risk = spendRisk(table);
  const tab = table.tabAmountCents || 0;
  const hold = table.holdAmountCents || 0;
  const cash = table.cashAmountCents || 0;

  if (table.status !== "checked_in") {
    return (
      <>
        <strong>{table.name}</strong>
        <span>
          {table.status === "card_saved"
            ? t("readout.booked", { name: table.guestName || t("readout.noName") })
            : table.status === "closed"
              ? t("readout.closed", { amount: eurExact(table.capturedAmountCents || 0) })
              : table.status === "cancelled"
                ? t("readout.released", { reason: reasonText(t, { label: table.cancelReason }) })
                : t("readout.free", { amount: eurExact(table.minSpendCents) })}
        </span>
      </>
    );
  }

  const covered = hold + cash;
  const pct = covered > 0 ? Math.round((tab / covered) * 100) : 0;
  const headroom = covered - tab;

  // Labelled figures in a row of their own, and the number that decides
  // whether to walk over there is the big one. The earlier version ran
  // everything together on one line, which is the sort of thing that reads
  // fine on a desk and not at all on a tablet held at arm's length.
  return (
    <>
      <div className={styles.hoverTop}>
        <strong>
          {table.name}
          {table.guestName ? ` · ${table.guestName}` : ""}
        </strong>
        <span className={styles.hoverPct} data-tone={RISK_COPY[risk]?.tone}>
          {pct}%
        </span>
      </div>

      <div className={styles.hoverBig} data-tone={RISK_COPY[risk]?.tone}>
        <span className="mono">
          {headroom < 0 ? "−" : ""}
          {eurExact(Math.abs(headroom))} €
        </span>
        <em>{headroom < 0 ? t("readout.overCovered") : t("readout.leftToSpend")}</em>
      </div>

      <div className={styles.hoverFigures}>
        <span>{t("readout.spent", { amount: <b className="mono">{eurExact(tab)} €</b> })}</span>
        <span>{t("readout.hold", { amount: <b className="mono">{eurExact(hold)} €</b> })}</span>
        {cash > 0 && (
          <span>{t("readout.cash", { amount: <b className="mono">{eurExact(cash)} €</b> })}</span>
        )}
        {table.topUp?.status === "pending" && (
          <span className={styles.hoverPending}>
            {t("readout.waiting", { amount: eurExact(table.topUp.amountCents) })}
          </span>
        )}
      </div>
    </>
  );
}
