import "./globals.css";

export const metadata = {
  title: "Overage Hold",
  description: "Card pre-authorization and live hold management for VIP table service",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        {/* Loaded via <link> rather than next/font so the project builds
            in offline/CI environments — fonts resolve in the browser. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Archivo:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@400;500;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
