import { redirect } from "next/navigation";
import { getTable } from "@/lib/db";
import { getT } from "@/lib/i18n/server";

// Where the printed table code lands: the walk-in entry point.
//
// The guest sat down without a booking, so there is no token to carry and
// nothing to authenticate against — they get a fresh session on this
// table. That is also the security boundary: because this route always
// STARTS a session and never opens an existing one, a code someone
// photographed last Saturday cannot be used to read tonight's bill.
export default function TableEntry({ params }) {
  const t = getT("guest");
  const table = getTable(params.tableId);

  if (!table) {
    return (
      <main style={{ padding: 40, maxWidth: 420, margin: "0 auto" }}>
        <p style={{ lineHeight: 1.7, color: "var(--text-dim)" }}>{t("t.noMatch")}</p>
      </main>
    );
  }

  // A table that is already open belongs to whoever is sitting at it, and
  // their link carries the token. Scanning the furniture must not hand a
  // stranger the running bill, so this stops rather than joining them.
  if (table.status === "checked_in") {
    return (
      <main style={{ padding: 40, maxWidth: 420, margin: "0 auto" }}>
        <p style={{ lineHeight: 1.7, color: "var(--text-dim)" }}>
          {t("t.alreadyOpen", { name: <b>{table.name}</b> })}
        </p>
      </main>
    );
  }

  // Screen 1 (deposit + consent) will live here once the payment model is
  // settled. Until then the code drops straight into the existing booking
  // flow, so a printed QR is functional end to end rather than a dead end.
  redirect(`/book/${table.id}`);
}
