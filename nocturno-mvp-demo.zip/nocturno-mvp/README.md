# VIP table overage-hold — MVP

Card verified when the table is booked → a real authorization hold placed
when the guests arrive → that hold raised through the night as they order →
the actual bill captured at close-out, with the unused hold released
automatically.

Runs entirely on **Stripe test mode**. No real cards, no real money, no
account approval needed.

## 1. Setup

```bash
npm install
cp .env.example .env.local
```

Get free test-mode keys from https://dashboard.stripe.com/test/apikeys and
put them in `.env.local` (each on its own line, no `#` in front):

```
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
AUTH_SECRET=<any long random string, e.g. openssl rand -hex 32>
STAFF_USERS=Ana:1111,Marc:2222,Sofia:3333
```

`AUTH_SECRET` plus at least one account guard `/staff` and `/door`. Both
are required: without them the app refuses those surfaces rather than
serving them unauthenticated, because the version that quietly runs open
is the version that gets deployed.

One PIN per person, because the activity log stamps every line with who
wrote it — see §5. `STAFF_PIN=2468` still works and signs in as an account
called "Staff". See `.env.example` for the optional `CRON_SECRET` (§4b) and
Twilio variables (§5).

Then:

```bash
npm run dev
```

Open http://localhost:3000 — and restart the server any time you edit
`.env.local`, since env vars are only read at startup.

## 2. Walking through the flow

1. On the home page, pick a table to open `/book/[id]` — the link a club
   sends after taking a booking over the phone. The guest never browses
   the room: the floor plan is a **staff** instrument and lives on
   `/staff`, because publishing which tables are sold and what each costs
   hands the venue's live inventory to anyone with a booking link. Narrow
   your window or open it on your phone: the guest side is designed
   phone-first, because that's where it gets opened.
2. Enter a name, continue. Creates a Stripe Customer + `SetupIntent`
   (`/api/setup-intent`) — card verified, no money moves.
3. Enter a test card (below), tick the consent box, submit. The card step
   leads with **"No payment is taken today"** — handing a card to a
   nightclub you haven't walked into yet is where bookings get abandoned,
   and the consent checkbox underneath is legal wording, not reassurance.
   The server independently re-verifies the SetupIntent succeeded
   (`/api/setup-intent-confirm`) before confirming — the client's word is
   never trusted alone.
4. **Booking confirmed.** The guest gets their table, their seat count, a
   **check-in QR code** and the arrival deadline stated up front — not
   discovered on the step at 01:30. The code points at `/door/[id]`.
5. Check in, either way:
   - **Scan the code** (or open `/door/[id]`) — the doorman's screen: who
     the booking is for, what will be held, one button.
   - **Or use /staff.** The board polls every 5s, so the table turns up as
     **Booked** without a refresh, on the floor plan and as a card.

   Either path authorizes 1.5× the table minimum off-session against the
   saved card (`/api/checkin`). A decline surfaces here, before a bottle is
   opened.

   **Arrivals close at 01:00** (`CHECKIN_CUTOFF_HOUR`). Past it the server
   refuses the check-in — a cutoff that only greys out a button is one that
   gets clicked through at 02:30 — and offers a manager override that signs
   the activity log. `lib/nightclock.js` owns the arithmetic, because a
   club night crosses midnight: at 00:30 "tonight's 01:00" is today and
   thirty minutes away, at 22:00 it is tomorrow, and a naive `setHours(1)`
   gets one of those wrong every single night.
6. **Menu** — tap a bottle and its price is rung straight into the tab
   (`/api/order`), which is what the POS webhook would do in production.
   Headroom and meter react: gold under 80%, amber at 80%, coral once the
   tab passes the hold. **Manual override** sets an arbitrary total — a
   comp, a breakage, something rung in on the wrong table — and is recorded
   as an adjustment line inside the order list, so the next thing anyone
   orders can't quietly erase it.
7. **+250 / +500 / +1000** — raises what's authorized on the same card
   (`/api/increment`). No new card entry, no new 3DS challenge. Works on
   any account: it increments the existing authorization where that's
   available and places a second hold alongside it where it isn't — see
   **Raising the hold** below.
8. **Close table** — captures exactly the tab amount (`/api/capture`).
   Anything held above that is released by the guest's bank.
9. **Release the table, or refuse entry** (`/api/cancel`). Voids the
   authorization outright rather than capturing it; nothing is charged
   either way. Staff pick a reason from a list that covers what actually
   happens at a door, and the list lives in `lib/config.js` shared by the
   dropdown and the server, so a label can't exist in the UI and land in
   the log as something else. **Free up table** then returns it to the
   pool. See §4a — the two endings are not the same event.
10. **Tonight's numbers** — at the foot of the board (`/api/stats`).
   Income, tips, what is still on hold, what was returned, what was rung
   up but not collected, the floor by state, why tables were released, and
   every product poured with quantity and revenue.

   The panel's real job is vocabulary. A hold-based product breaks every
   habit an owner has from ordinary card takings: "5.875 € authorized"
   looks like a fortune and is not income, "3.830 € returned" looks like a
   refund and is not a loss. So the one figure that IS money leads, tips
   are stated separately because they belong to somebody else, and the
   three figures most easily mistaken for takings are visibly demoted.
11. **Sweep** — the same pull endpoint a cron would hit
   (`/api/auto-settle`). Settles tables that have gone quiet, and past
   01:00 releases bookings that never walked in so the table goes back on
   the floor. Safe to press at any point: it only touches tables that
   qualify.

Expand **Activity** on any table for a timestamped log of every call.

### The guest's own page

`/table/[id]` — the link the guest keeps open on the table all night. Staff
reach it from **Guest's view →** on a live card.

- **Order to the table.** The same menu, tapped by the guest instead of the
  waiter (`/api/order` with `by: "guest"`, so the log can tell them apart).
- **One number: spent so far.** Staff get headroom remaining because their
  job is to sell into it. The guest's question is only ever what it's
  costing them, so the figure is inverted.
- **The 90% message.** When the tab reaches 90% of the authorization the
  guest gets a banner naming exactly what's left and stating plainly that
  nothing has been charged yet. It fires once per night — the flag is
  latched server-side (`warned90`) rather than derived, so it can't
  re-appear on every poll, and it lands in the activity log so staff know
  the guest has already been told.
- **Close the bill.** Tip (preset percentages), a 1–5 service rating and a
  free-text comment, then `/api/close-bill` captures tab + tip in one go.
  The rating and comment surface on the staff card afterwards.

Tips are capped at the headroom left under the hold, because a capture can
never exceed its authorization — asking for 15% on a table already at 90%
is refused with the actual maximum, not a raw Stripe error.

## 2b. Raising the hold

The product's whole claim is that the hold climbs with the tab, and Stripe
offers two ways to do it:

1. **Increment the existing authorization** — one hold that grows. Cleanest
   for the guest: a single pending line on their statement. Requires
   incremental authorization, which needs Stripe IC+ pricing and
   merchant-category approval. Limits: 10 increments per PaymentIntent,
   each capped at the greater of 500 local or 500% over the previous amount.
2. **Place another hold alongside it** — a stack of authorizations on the
   same saved card. Works on any Stripe account with no eligibility gate.
   The honest cost: it ties up more of the guest's credit line and shows
   several pending lines on their statement.

`/api/increment` takes a target total and picks whichever is available, so
the +250/+500/+1000 buttons don't have to know which world they're in. A
table therefore holds a *stack* (`holds[]`), not one PaymentIntent, and
close-out walks it: capture what each hold can cover until the bill is
paid, then cancel any hold that ended up covering nothing rather than
leaving it pinned against the card for days.

Worked example, on a test account with no incremental eligibility:

```
check in            hold #1  525.00  open
+500                hold #2  500.00  open      → 1025.00 authorized
close at 800.00     hold #1  525.00  captured 525.00
                    hold #2  500.00  captured 275.00   (225.00 released)
```

## 2d. The floor mechanics

**One card per table.** The booking's card is the table's card: it takes
the hold, it takes the raises, it is what gets captured. Splitting a bill
across several payers was built and then removed — each joiner needed their
own Stripe customer, their own authorization and their own settlement path,
which doubled the number of ways a night could end badly (a stranded hold
on a friend's card, a host billed for other people's drinks) to solve a
problem the venue can solve by having one person book the table. If it
comes back it should come back as a product decision, not as plumbing that
happened to be there.

**Auto-settle.** `/api/auto-settle` sweeps tables that have gone quiet past
`IDLE_SETTLE_MINUTES`, or everything still open when the shift closes. Two
rules it won't break: it never adds a tip, and a table that ordered nothing
is *released*, not captured — an idle empty tab is a no-show, and no-shows
don't get billed because a timer fired. It's a pull endpoint, not a
`setInterval` in the web process: an in-process timer is lost on restart
and duplicated on every extra instance. Point a cron at it.

**Leaderboard.** `/board` is the wall screen; `/api/leaderboard` is public
because the whole point is that it goes on a wall. That makes what it omits
the important part — a table's public identity is its own number or a name
the guests chose, never the name on the card. Spend excludes tips: ranking
people by what they tipped changes how they tip.

**Guest memory.** An optional phone at booking, hashed one-way immediately;
the raw number is never written to the table, the log, or the profile.
Returning guests get "the usual" at the top of the menu, priced from
*tonight's* menu rather than from the remembered order — a saved price is a
stale price. First-time guests get no card at all rather than a fabricated
recommendation.

## 2c. Who is allowed to do what

- **Staff** — a shared PIN exchanged for a signed, httpOnly session cookie.
  Guards `/staff`, `/door` and every route that moves money: check-in,
  raising the hold, capture, cancel, hand-corrections, demo reset.
- **The guest** — an unguessable per-booking token minted when the booking
  starts, carried in their confirmation links and in the check-in QR.
  Required to read `/api/booking/[id]`, order to the table, or close the
  bill. Staff sessions also satisfy it, since staff can legitimately open
  any table.
- **Anyone** — the floor plan. It has to work before you've booked or
  signed in, so `GET /api/tables` is public and returns only what it takes
  to draw the room and price it: no guest names, no Stripe ids, no tokens,
  no activity log. Signed-in staff get the full record from the same URL.

## 3. Test cards

Any future expiry, any 3-digit CVC.

| Card number           | Simulates                                        |
| --------------------- | ------------------------------------------------ |
| `4242 4242 4242 4242` | Normal card, everything succeeds                 |
| `4000 0000 0000 0002` | Declined at check-in                             |
| `4000 0025 0000 3155` | Requires 3D Secure during card verification      |
| `4000 0084 0000 0063` | Hold increases succeed — eligible accounts only  |
| `4000 0084 0000 0076` | Hold increase **declined** — eligible accounts only |

The last two only behave differently on an account with incremental
authorization enabled. Without it those cards behave like the first one,
and raising the hold goes down the parallel-hold path instead (§2b) — the
feature still works, it just gets there differently.

Full list: https://docs.stripe.com/testing

## 4. Design notes

The visual language is calibrated against how Barcelona's own table-selling
clubs present themselves — Opium, Shôko and Sutton were the references.
Three things all of them do, and this app now does:

1. **True black.** Not navy, not indigo. The light in the frame comes from
   the room, never from the background.
2. **One grotesk, set loud.** Heavy, uppercase, tight tracking. None of them
   use a didone; the serif reads as "hotel", not "club".
3. **The button is white.** There is no brand-colour CTA anywhere in the
   category. White on black is the whole visual argument.

Also universal, and worth copying exactly: the wordmark lockup of a heavy
name stacked over a micro-tracked city line (`CLUB NOCTURNO` / `BARCELONA`).
It is most of what makes a page read as a venue on sight.

With no venue photography to lean on — which is what actually carries those
sites — the weight is carried instead by deep black, a single overhead light
gradient, a trace of film grain, and very large type against very small type.

Two surfaces, two deliberately different personalities on the same tokens:

- **Guest** (`/book/[id]`) — opened on a phone, from a WhatsApp link, by
  someone deciding whether a venue is worth €1500. Unhurried, atmospheric.
  The signature element is the hold gauge: gold is what you owe, the hatched
  remainder is what may be authorized, the tick at the end is the ceiling.
- **Staff** (`/staff`) — read at arm's length, in the dark, mid-shift. Same
  black and same grotesk, stripped of every atmospheric move: no light rig,
  no wordmark. One dominant number per table (headroom remaining), preset
  increments instead of typing at 2am, every target ≥48px.

Colour is load-bearing, not decorative: **champagne = money** (if a number
is euros it's gold, and nothing else ever is), **white = the action you're
meant to take next**, amber and coral only for the two states that require
action. The single filled-gold control in the product is "Close table",
because it is the one button that moves money.

White-labelling is a token swap — change `VENUE_NAME` in `BookingForm.jsx`
and the custom properties at the top of `globals.css`. Note that the Stripe
card field renders in an iframe and cannot read those properties: its
palette is mirrored by hand in `stripeAppearance` in `BookingForm.jsx`, and
has to be changed alongside them.

## 4a. Refusal is not the same event as a no-show

Both end with a released table and nothing charged, and the software used
to treat them identically. They are not the same thing.

A **no-show** is an absence. Nobody judged anybody.

A **refusal** is a decision a named member of staff made about a person who
was standing in front of them — and it is the one thing this system does
that can be challenged afterwards. *"You said I was drunk." "Nobody checked
my ID." "Your doorman didn't like my face."* The only trace used to be a
line in an activity log with no author and no reference, which is worth
nothing to either side of that argument.

So `underage`, `intoxicated`, `dress_code`, `behaviour` and `face_control`
produce an **official record** (`lib/refusal.js`):

- a quotable reference — `REF-20260817-JXAN`, built from an alphabet with
  no ambiguous characters because it gets read aloud in a doorway
- the reason, the time, and **who decided** — the whole point of §per-user
  PINs was so this field could exist
- what was actually observed. `underage`, `intoxicated` and `behaviour`
  **require** it, server-side: "under 18" is a conclusion, "DNI showed DOB
  12/03/2009" is a fact somebody can check, and these are precisely the
  refusals that get disputed. A record carrying only the conclusion is one
  person's word.

**And the guest is told.** Being refused entry and then never hearing from
the venue again — no message, no reason, no way to ask — was the part that
was actually broken. They get an SMS stating the outcome, that no money was
taken, and the reference to quote. That protects the guest, because they
can contest it, and it protects the club, because a documented refusal with
a reason is defensible and a whispered one is not.

The message names the reason only where the reason is a checkable fact
(`underage`, `dress_code`). Putting *"you seemed too drunk"* in writing to
a stranger's phone helps nobody: staff said it at the door, the record has
it, and the reference is how they ask.

A lapsed booking gets a plainer message with no reference — there is
nothing to contest, but the guest should still learn their table is gone
from a text rather than by turning up.

## 4b. Nothing calls the sweep on its own

`/api/auto-settle` is a **pull** endpoint. It does nothing until something
asks it to run, and right now the only thing that ever asks is the
**Sweep** button on the staff board. Press nobody, sweep nothing.

That is deliberate, and the alternative is worse. The obvious version is a
`setInterval` inside the web process, which fails in three ways that all
look fine in development: it dies on every deploy and restart, it runs
twice on two instances (two sweeps racing to capture the same table), and
it cannot be triggered or audited from outside. A pull endpoint has none of
those problems and can be tested with `curl`.

What it costs is that **something outside the app has to call it**. Until
that exists, an idle table sits on its authorization until a human presses
Sweep, and a booking that never arrived holds its table past 01:00.

The missing piece is one line of scheduling, wherever the app is deployed:

```bash
*/15 * * * * curl -fsS -X POST https://your-venue.example/api/auto-settle -H 'Cookie: nocturno_staff=…'
```

The catch is in that header: the route is `staffOnly()`, so a cron needs a
credential. A shared staff cookie in a crontab is not the answer. The real
fix is a separate machine token — `CRON_SECRET` in the environment,
accepted by this one route as a bearer header — so the scheduler can settle
tables without being able to sign in, comp a bottle, or issue a refund.
That token does not exist yet.

Hosting-native schedulers (Vercel Cron, Railway, a systemd timer, GitHub
Actions) all work the same way and hit the same wall, so the token is the
prerequisite for any of them.

## 5. Before this touches a real club

- **A no-show still costs the guest nothing, and that is the big one.**
  The product's pitch is two problems: guests who book and don't turn up,
  and guests who outspend their deposit and leave. The second is solved
  end-to-end. The first is only solved *operationally* — past 01:00 the
  table is released and resold, which recovers the room but not the
  evening. Nothing is charged because **no hold exists until check-in**:
  booking creates a `SetupIntent` (a £0 card verification), and the
  authorization is placed when the guests physically arrive
  (`/api/checkin`). To actually penalise a no-show the money has to move
  earlier — either a non-refundable deposit captured at booking or a hold
  placed at booking time. `lib/deposit.js` already has the tested
  arithmetic for deposit-plus-hold ("Model B"), but it is currently wired
  only into the scripted `/demo` screens, where the payment is theatre.
  Pointing the real booking route at it is the next piece of work.
- **SQLite is a real database, but it is a single-machine one.** The store
  is now `node:sqlite` with every read-modify-write inside
  `BEGIN IMMEDIATE`, which is what killed the lost-update bug the JSON file
  had (§7). It will hold a club. It will not survive being deployed to
  several instances behind a load balancer, or to a serverless platform
  with an ephemeral filesystem — that is the point where it becomes
  Postgres. The swap is contained: everything goes through `lib/db.js`.
- **The 01:00 cutoff is the venue's clock, not the guest's.**
  `checkinCutoff()` reads the server's local time, so a club whose server
  is in another timezone gets someone else's night. It needs to be a venue
  setting, not a machine setting, before this runs anywhere but a laptop.
- **Replace the manual tab input with a POS webhook.** Right now a human
  types the running tab; in production the POS should push every order so
  holds react automatically. As-is, it still depends on staff noticing.
- **Still worth getting incremental authorization enabled** with Stripe
  support for your merchant category, even though the product no longer
  depends on it (§2b). One growing hold is materially better for the guest
  than a stack: less of their credit line pinned, one pending line on the
  statement instead of several. The parallel-hold path is the portable
  fallback, not the nicer option.
- **Staff accounts are PINs in an env var, not real accounts.** Each person
  now has their own PIN (`STAFF_USERS`) and every log line is stamped with
  who wrote it, so "who comped that bottle" is finally answerable. What is
  still missing is everything around it: no password hashing, no way to add
  or revoke somebody without an edit and a restart, no roles (every account
  can do everything, including refunds). The *log* being keyed to a person
  was the part that could not be retrofitted later without rewriting every
  call site; the directory behind it can be swapped whenever.
- **No geolocation auto-close, deliberately.** It was in the brief and it
  shouldn't be built: browser geolocation needs a foreground permission
  prompt, can't run in the background once the phone is pocketed, is
  routinely tens of metres out, and charging someone because a coordinate
  drifted across a line is not a defensible reason to take money. Idle
  timeout and end-of-shift do the same job on evidence you can show
  someone.
- **Polling, not WebSockets.** The brief called for live sockets on the
  wall board. Every screen here polls on 5s instead: a socket that dies
  quietly at 2am leaves a frozen leaderboard on the wall, and nobody is
  watching that screen closely enough for the lag to matter. Worth
  revisiting only if the floor gets big enough for polling to cost real
  queries.
- **The guest profile is personal data.** Hashing the phone makes it
  pseudonymous, not anonymous — under GDPR it still needs a lawful basis, a
  retention limit and a deletion path, none of which exist here. Today it
  is a JSON blob that survives every demo reset by design.
- **The leaderboard is anonymous, but the room isn't.** It shows no names,
  but anyone who watched a party sit down at Mesa 6 can read their spend
  off the wall. That's a choice the venue makes knowingly; the alias field
  exists so guests can opt into a name of their own instead.
- **Booking tokens are bearer tokens.** Anyone the guest forwards their link
  to can order to that table and close its bill — which is roughly true of
  a physical table card too, but worth knowing. They expire after 24h.
  Rotating one per night, or binding it to a phone number confirmed at
  booking, would tighten it.
- **SMS needs an account before it is real.** `lib/notify.js` now sends
  through Twilio when `SMS_PROVIDER=twilio` and the three `TWILIO_*` vars
  are set, for both the 90% warning and the close-out receipt. Without
  them every notification still lands in the table's activity log and
  nowhere else, which is the safe default but is not a message. Delivery
  never throws: a dead provider must not roll back a capture that already
  took the money.
- **The guest's phone lives on the table for one night.** Sending an SMS
  needs a number, and the durable profile only ever holds a hash of one
  (§lib/customers.js). So the raw number sits on tonight's table row and is
  wiped when the table is freed or reset. That is purpose- and
  retention-limitation by construction — but "freed or reset" is a staff
  action, so a table nobody clears keeps the number until the next demo
  reset. A real deployment wants that on a timer.
- **The floor plan is hand-placed.** `lib/floorplan.js` positions each table
  by hand in SVG units. Fine for one venue; a second venue needs either its
  own file or a plan editor.
- **Get the consent wording reviewed by an EU consumer-payments lawyer.**
  Naming a specific cap is the right shape, but that isn't the same as
  reviewed and defensible.
- **Handle hold expiry.** Authorizations lapse (roughly 7 days, less on
  some cards) and neither increments nor additional parallel holds extend
  the window on the ones already placed.
- **Known dependency issues**: a transitive PostCSS advisory that only
  resolves via a Next.js major upgrade, plus two advisories pulled in by
  `qrcode` (used to render the check-in code). Irrelevant locally, worth
  clearing before deploying anywhere public — `npm audit` for details.

## 6. Structure

```
app/
  page.jsx                     home: two doors, guest and staff
  components/FloorPlanSvg.jsx  the room, drawn once — staff surface only
  login/                       staff PIN sign-in
  book/[tableId]/              guest booking + card verification + confirmation
  table/[tableId]/             guest's live tab: order, 90% alert, close-out
  door/[tableId]/              what scanning the check-in code opens
  board/                       the wall screen: tonight's top tables
  staff/                       floor board
  staff/StaffFloorMap.jsx      the room + who has booked and not arrived
  api/
    setup-intent/              save card (SetupIntent, no charge)
    setup-intent-confirm/      server-side re-verification
    checkin/                   place the real hold
    order/                     ring a menu item into the tab
    tab/                       staff hand-correction, as an adjustment line
    increment/                 raise the hold mid-service
    capture/                   settle the final bill (staff)
    close-bill/                settle + tip + rating + comment (guest)
    checkin-qr/[tableId]/      SVG check-in code for the confirmation
    cancel/                    no-show / refused entry — void every hold
    booking/[tableId]/         one booking, token-gated (guest page polls it)
    usual/                     what this guest always drinks; re-order it
    auto-settle/               sweep idle tables / close the shift
    refund/                    give money back after it was captured
    stats/                     tonight's numbers (staff only)
    leaderboard/               public, anonymous, for the wall screen
    auth/login, auth/logout    staff PIN session
    tables/                    public floor list; full list for staff; reset
lib/
  stripe.js                    Stripe SDK client
  nightclock.js                the 01:00 cutoff, across midnight
  stats.js                     tonight's numbers, derived not stored
  auth.js                      staff sessions + per-booking tokens
  settle.js                    capture / release across a stack of holds
  refusal.js                   official refusal records + guest notice
  customers.js                 guest memory, keyed by hashed phone
  db.js                        SQLite store, transactional + 90% latch
  menu.js                      bottle list the waiter taps
  floorplan.js                 room geometry for the seat map
  config.js                    buffer multiplier, warn ratio, tips, cutoff,
                               cancellation reasons
```
