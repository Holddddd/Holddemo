import { defineConfig, devices } from "@playwright/test";

// These tests drive a real Stripe test-mode account through real iframes.
// That shapes most of the settings below.
export default defineConfig({
  testDir: "./e2e",

  // Stripe Elements loads a script from js.stripe.com, mounts nested
  // iframes and round-trips to Stripe on confirm. The default 30s is not
  // generous once a real network is involved.
  timeout: 90_000,
  expect: { timeout: 15_000 },

  // NEVER parallel. Every test books a real table out of a nine-table
  // floor and resets it afterwards; two workers would take each other's
  // tables and the failures would look like product bugs.
  workers: 1,
  fullyParallel: false,

  // A retry hides exactly the flakiness these tests exist to catch — a
  // double-submit that only sometimes double-charges is the bug, not a
  // blip. Retries stay off locally and are capped at one on CI, where a
  // cold Stripe connection genuinely can time out.
  retries: process.env.CI ? 1 : 0,
  forbidOnly: !!process.env.CI,

  reporter: process.env.CI ? [["list"], ["html", { open: "never" }]] : [["list"]],

  use: {
    baseURL: process.env.E2E_BASE_URL || "http://localhost:3010",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "off",
  },

  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],

  // Reuses whatever is already running locally; starts its own on CI.
  webServer: {
    command: "npm run dev",
    url: process.env.E2E_BASE_URL || "http://localhost:3010",
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
});
