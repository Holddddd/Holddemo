/** @type {import('next').NextConfig} */

// Stripe Elements runs in iframes served from Stripe's own domains, and the
// SDK talks to api.stripe.com from the page. Any policy that forgets one of
// these takes the card form down, so they are listed once, here.
const STRIPE_JS = "https://js.stripe.com";
const STRIPE_API = "https://api.stripe.com";
const STRIPE_FRAMES = "https://js.stripe.com https://hooks.stripe.com";

// The venue's typefaces. Left out of the first draft of this policy, which
// blocked them and silently dropped the whole app back to system fonts —
// a policy that changes how the product looks is a policy that gets turned
// off, so the allowance is explicit rather than discovered later.
const FONTS_CSS = "https://fonts.googleapis.com";
const FONTS_FILES = "https://fonts.gstatic.com";

const isProd = process.env.NODE_ENV === "production";

const csp = [
  "default-src 'self'",
  // 'unsafe-inline' is a real concession and not one made lightly: Next
  // injects inline bootstrap scripts, and the nonce-based alternative needs
  // middleware on every request. What this still buys is the part that
  // matters most here — script-src is pinned to us and Stripe, so an
  // injected <script src="evil.com"> does not execute. 'unsafe-eval' is dev
  // only, for hot reload.
  `script-src 'self' 'unsafe-inline' ${isProd ? "" : "'unsafe-eval'"} ${STRIPE_JS}`,
  `style-src 'self' 'unsafe-inline' ${FONTS_CSS}`,
  "img-src 'self' data: blob:",
  `font-src 'self' data: ${FONTS_FILES}`,
  `connect-src 'self' ${STRIPE_API}`,
  `frame-src ${STRIPE_FRAMES}`,
  // The staff board captures cards and issues refunds with one tap. Framed
  // invisibly over a page a manager is already signed into, those taps are
  // free to whoever drew the page on top.
  "frame-ancestors 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "object-src 'none'",
].filter(Boolean).join("; ");

const securityHeaders = [
  { key: "Content-Security-Policy", value: csp },
  // Kept alongside frame-ancestors for browsers that honour only this one.
  { key: "X-Frame-Options", value: "DENY" },
  { key: "X-Content-Type-Options", value: "nosniff" },
  // A guest's booking token travels in the query string (/table/x?t=…).
  // The default referrer policy sends that full URL to every third-party
  // host the page touches — Stripe included — handing out a live
  // credential in a header nobody reads. This sends the origin only.
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), payment=(self)" },
];

if (isProd) {
  securityHeaders.push({
    key: "Strict-Transport-Security",
    value: "max-age=31536000; includeSubDomains",
  });
}

const nextConfig = {
  async headers() {
    return [{ source: "/:path*", headers: securityHeaders }];
  },
};

module.exports = nextConfig;
