import { expect } from "@playwright/test";

// Stripe's own test cards, and WHERE each one fails — which is not where
// you would guess, and is the difference between a test that proves
// something and a test that passes for the wrong reason.
//
// Booking only VERIFIES the card ($0 SetupIntent); the money is reserved
// later, at check-in. So a card can fail at either step, and the two are
// different product events:
export const CARDS = {
  // Verifies, and the hold goes through.
  ok: "4242424242424242",
  // Refused during verification — the booking never completes. Despite
  // the name, this never reaches the check-in stage at all.
  insufficientFunds: "4000000000009995",
  // Refused during verification, generic reason.
  declined: "4000000000000002",
  // Verifies happily, then fails when the hold is placed at check-in.
  // The only card that reproduces a decline in front of the doorman.
  failsAtCheckIn: "4000000000000341",
};

export const STAFF_PIN = process.env.E2E_STAFF_PIN || "2468";

// ---------- fixtures ----------

// Puts a table back to an empty, bookable state. Called before every test
// so a run never depends on what the previous one left behind.
export async function resetTable(request, tableId) {
  const login = await request.post("/api/auth/login", { data: { pin: STAFF_PIN } });
  expect(login.ok(), "staff sign-in failed — check E2E_STAFF_PIN").toBeTruthy();

  const res = await request.post("/api/tables", {
    data: { action: "reopen", tableId },
  });
  expect(res.ok(), `could not reset ${tableId}`).toBeTruthy();
}

// The server's view of a table, for assertions the DOM cannot make —
// "no booking was created" is a claim about state, not about pixels.
export async function getTable(request, tableId) {
  await request.post("/api/auth/login", { data: { pin: STAFF_PIN } });
  const res = await request.get("/api/tables");
  const { tables } = await res.json();
  return tables.find((t) => t.id === tableId);
}

// ---------- the card form ----------

// Stripe's PaymentElement renders in an iframe this page cannot reach into
// except through frameLocator. The frame has no stable name, so it is
// found by the field inside it.
function cardFrame(page) {
  return page
    .frameLocator('iframe[title*="payment" i], iframe[name^="__privateStripeFrame"]')
    .first();
}

// Fills the card fields. Stripe Link — the "pay faster next time" panel —
// hijacks this form once an email has been used before, so it is
// explicitly dismissed rather than hoped away.
export async function fillCard(page, number, { expiry = "12 / 34", cvc = "123" } = {}) {
  const frame = cardFrame(page);

  // Link remembers cards against an email and silently replaces the card
  // fields with "use this card". Refuse it so every run enters a card.
  const useAnother = frame.locator('text=/use another card|enter card|otro método/i').first();
  if (await useAnother.isVisible({ timeout: 3_000 }).catch(() => false)) {
    await useAnother.click();
  }

  const num = frame.getByPlaceholder("1234 1234 1234 1234");
  await num.waitFor({ state: "visible", timeout: 30_000 });
  await num.fill(number);
  await frame.getByPlaceholder("MM / YY").fill(expiry);
  await frame.getByPlaceholder("CVC").fill(cvc);

  // Link's optional sign-up asks for an email/phone underneath. Leaving it
  // blank is fine; filling it turns the run into a Link flow instead.
}

// Name + the consent checkbox: everything on the booking page that is ours
// rather than Stripe's.
export async function startBooking(page, tableId, { name = "E2E Guest" } = {}) {
  await page.goto(`/book/${tableId}`);
  await page.getByLabel(/name on the reservation/i).fill(name);
  await page.getByRole("button", { name: /^continue$/i }).click();

  // The card step only exists once the server has minted a SetupIntent.
  await expect(page.getByText(/no payment is taken today/i)).toBeVisible();
}

export async function agreeToTerms(page) {
  await page.getByRole("checkbox").check();
}

export const confirmButton = (page) =>
  page.getByRole("button", { name: /confirm reservation|verifying/i });
