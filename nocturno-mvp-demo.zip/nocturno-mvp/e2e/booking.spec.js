import { test, expect } from "@playwright/test";
import {
  CARDS,
  resetTable,
  getTable,
  fillCard,
  startBooking,
  agreeToTerms,
  confirmButton,
} from "./helpers.js";

// Each test owns a table for its whole run. Sharing one would make a
// failure in the first test look like a bug in the second.
const T = {
  happy: "table-1",
  declined: "table-2",
  doubleClick: "table-9",
  validation: "table-8",
};

test.describe("Booking a table", () => {
  // ---------------------------------------------------------------
  test("happy path: card verified, booking confirmed, QR code issued", async ({
    page,
    request,
  }) => {
    await resetTable(request, T.happy);

    await startBooking(page, T.happy, { name: "Marta Ruiz" });

    // The one promise the whole product rests on, and the sentence guests
    // abandon the booking without. If this copy ever goes missing the test
    // should fail even though the flow still "works".
    await expect(page.getByText(/no money leaves your account now/i)).toBeVisible();

    await fillCard(page, CARDS.ok);
    await agreeToTerms(page);
    await confirmButton(page).click();

    await expect(page.getByRole("heading", { name: /booking confirmed/i })).toBeVisible({
      timeout: 45_000,
    });

    // The QR is the check-in. A confirmation screen without it is a
    // confirmation the doorman cannot scan.
    const qr = page.getByRole("img", { name: /check-in code/i });
    await expect(qr).toBeVisible();
    await expect(qr).toHaveAttribute("src", new RegExp(`/api/checkin-qr/${T.happy}`));

    // And it has to actually render — a broken <img> is still "visible".
    await expect
      .poll(() => qr.evaluate((el) => el.naturalWidth), { timeout: 15_000 })
      .toBeGreaterThan(0);

    // The guest is told the deadline here or finds out at the door.
    await expect(page.getByText(/arrive by \d{2}:\d{2}/i)).toBeVisible();

    // The screen says confirmed; the server has to agree. A card saved but
    // a status left behind is exactly the drift worth catching.
    const table = await getTable(request, T.happy);
    expect(table.status).toBe("card_saved");
    expect(table.guestName).toBe("Marta Ruiz");
    expect(table.paymentMethodId).toBeTruthy();
    // Verified, not charged: no hold exists until they arrive.
    expect(table.holds ?? []).toHaveLength(0);
  });

  // ---------------------------------------------------------------
  test("declined card: no booking is created and the guest is told why", async ({
    page,
    request,
  }) => {
    await resetTable(request, T.declined);

    await startBooking(page, T.declined, { name: "Declined Guest" });
    await fillCard(page, CARDS.insufficientFunds);
    await agreeToTerms(page);
    await confirmButton(page).click();

    // Stripe refuses this card during VERIFICATION, so the failure lands
    // here rather than at check-in — see helpers.js. The guest must get a
    // sentence, not a spinner that stops.
    const error = page.locator("p").filter({ hasText: /declin|insufficient|card/i }).first();
    await expect(error).toBeVisible({ timeout: 45_000 });

    // Never silently succeed.
    await expect(page.getByRole("heading", { name: /booking confirmed/i })).toBeHidden();

    // They must be able to try another card without starting over.
    await expect(confirmButton(page)).toBeEnabled();

    // The real assertion: nothing was booked. The table never leaves
    // "pending_card" — no saved card, no reservation anyone must honour.
    const table = await getTable(request, T.declined);
    expect(table.status).toBe("pending_card");
    expect(table.paymentMethodId).toBeFalsy();
  });

  // ---------------------------------------------------------------
  test("double click on confirm creates exactly one booking", async ({ page, request }) => {
    await resetTable(request, T.doubleClick);

    await startBooking(page, T.doubleClick, { name: "Fast Fingers" });
    await fillCard(page, CARDS.ok);
    await agreeToTerms(page);

    // TWO layers protect this, and they are worth asserting separately —
    // a run that only checks the outcome passes even when our own guard is
    // gone, because Stripe refuses the second confirmation on its side.
    // That was measured, not assumed: with the button guard removed, the
    // browser really does call Stripe twice and still books once. So the
    // outcome alone proves Stripe works, not that we do.
    const ourConfirms = [];
    const stripeConfirms = [];
    page.on("request", (r) => {
      if (r.method() !== "POST") return;
      const u = r.url();
      if (u.includes("/api/setup-intent-confirm")) ourConfirms.push(u);
      else if (/api\.stripe\.com.*setup_intents\/[^/]+\/confirm/.test(u)) stripeConfirms.push(u);
    });

    // A real double click, at the speed a thumb actually produces one.
    //
    // The gap matters and is the whole subtlety here. Two clicks in the
    // SAME JavaScript task both get through even with the guard in place,
    // because React sets `loading` asynchronously and the DOM attribute
    // has not flipped yet — measured, not assumed. But no hand generates
    // two clicks 0 ms apart; a fast double click is 40–200 ms, by which
    // time React has re-rendered and the button is dead.
    //
    // So this fires them ~60 ms apart: fast enough that the first request
    // is still in flight, slow enough to be a thing a person can do.
    //
    // The disabled state is WATCHED rather than asserted afterwards. The
    // button is unmounted the moment the confirmation screen renders, so
    // an expect() arriving later finds nothing to be disabled.
    await confirmButton(page).evaluate((btn) => {
      window.__wentDisabled = false;
      new MutationObserver(() => {
        if (btn.disabled) window.__wentDisabled = true;
      }).observe(btn, { attributes: true, attributeFilter: ["disabled"] });

      btn.click();
      setTimeout(() => btn.click(), 60);
    });

    await expect(page.getByRole("heading", { name: /booking confirmed/i })).toBeVisible({
      timeout: 45_000,
    });

    // LAYER 1 — ours. The button went dead the instant it was pressed, so
    // the second press had nothing to hit. This is the assertion that
    // fails if somebody drops `loading` from the disabled expression.
    expect(
      await page.evaluate(() => window.__wentDisabled),
      "the confirm button never disabled itself while the request was in flight"
    ).toBe(true);

    // ...which means the card was only ever confirmed once, upstream too.
    expect(stripeConfirms.length, "the card was confirmed with Stripe twice").toBe(1);

    // LAYER 2 — the outcome, whoever ends up protecting it. Exactly one
    // booking reaches our server.
    expect(ourConfirms.length, "confirm was submitted more than once").toBe(1);

    const table = await getTable(request, T.doubleClick);
    expect(table.status).toBe("card_saved");
    // One booking means one card and one booking token, not two of either.
    expect(table.paymentMethodId).toBeTruthy();
    expect(table.holds ?? []).toHaveLength(0);
  });

  // ---------------------------------------------------------------
  test.describe("validation", () => {
    test("the name is required before a card is ever requested", async ({ page, request }) => {
      await resetTable(request, T.validation);
      await page.goto(`/book/${T.validation}`);

      await page.getByRole("button", { name: /^continue$/i }).click();

      // The card step must not appear: asking Stripe for a SetupIntent for
      // a nameless booking creates a Customer nobody can identify later.
      await expect(page.getByText(/no payment is taken today/i)).toBeHidden();

      // The browser's own required-field message is the guard here.
      const name = page.getByLabel(/name on the reservation/i);
      await expect(name).toBeFocused();
      expect(await name.evaluate((el) => el.validity.valueMissing)).toBe(true);

      // Nothing reached the server.
      const table = await getTable(request, T.validation);
      expect(table.status).toBe("available");
    });

    test("whitespace is not a name", async ({ page, request }) => {
      await resetTable(request, T.validation);
      await page.goto(`/book/${T.validation}`);

      await page.getByLabel(/name on the reservation/i).fill("   ");
      await page.getByRole("button", { name: /^continue$/i }).click();

      // Either the client refuses it or the server does — but one of them
      // must, and the table must not end up reserved to a blank name.
      await expect(page.getByText(/no payment is taken today/i)).toBeHidden({ timeout: 15_000 });

      const table = await getTable(request, T.validation);
      expect(table.guestName ?? "").toMatch(/^\s*$/);
      expect(table.status).toBe("available");
    });

    test("consent is required before the card can be submitted", async ({ page, request }) => {
      await resetTable(request, T.validation);

      await startBooking(page, T.validation, { name: "No Consent" });
      await fillCard(page, CARDS.ok);

      // The checkbox is the guest agreeing to a hold of a named size. It
      // is legal wording, not decoration, so the button stays dead
      // without it.
      await expect(confirmButton(page)).toBeDisabled();

      await agreeToTerms(page);
      await expect(confirmButton(page)).toBeEnabled();
    });

    test("an incomplete card cannot be submitted", async ({ page, request }) => {
      await resetTable(request, T.validation);

      await startBooking(page, T.validation, { name: "Half A Card" });
      // A number one digit short — the classic mistyped-card case.
      await fillCard(page, "424242424242424");
      await agreeToTerms(page);
      await confirmButton(page).click();

      // Stripe rejects it in the field; we must not report success.
      await expect(page.getByRole("heading", { name: /booking confirmed/i })).toBeHidden();

      const table = await getTable(request, T.validation);
      expect(table.status).toBe("pending_card");
      expect(table.paymentMethodId).toBeFalsy();
    });
  });
});
