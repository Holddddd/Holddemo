# Running this on another computer

Needs **Node 22 or newer** — the database uses `node:sqlite`, which is built
into Node itself. Check with `node -v`.

## 1. Install

```bash
npm install
```

## 2. Create `.env.local`

**This file is deliberately not in the archive** — it holds a Stripe secret
key, and secret keys should not travel through a chat app. Create it in the
project root and paste your own values:

```
STRIPE_SECRET_KEY=sk_test_...
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...

AUTH_SECRET=any-long-random-string
STAFF_USERS=Ana:1111,Marc:2222,Sofia:3333
STAFF_PIN=2468

CRON_SECRET=another-long-random-string
```

Both Stripe keys are in your Stripe dashboard under
**Developers → API keys** (test mode). For the two random strings:

```bash
openssl rand -hex 32
```

Everything else in `.env.example` is optional — SMS, email and the public
URL. Without them the app still runs: notifications are written to each
table's activity log instead of being sent.

## 3. Run

```bash
npm run dev
```

Open http://localhost:3000

- **Guest** — pick a table on the home page
- **Staff** — "Open the floor", PIN `2468` (or `1111` / `2222` / `3333`,
  which sign in as named people so the activity log says who did what)
- Test card `4242 4242 4242 4242`, any future expiry, any CVC

## Tests

End-to-end tests (Playwright) cover booking: the happy path, a declined
card, a double-clicked confirm button, and form validation.

```bash
npx playwright install chromium
npm test
```

They drive a **real Stripe test-mode account** through real card iframes,
so they need `.env.local` filled in and a working internet connection.
Seven tests, about 20 seconds.

They also need the app running. `npm test` starts it itself if nothing is
on the port, or reuses `npm run dev` if you already have it open.

Each test takes one table out of the nine and resets it first, so they run
one at a time on purpose — running them in parallel would have them
stealing each other's tables.

## The database

There isn't one in the archive, on purpose: it contained the phone numbers
and emails typed in during testing. `data/nocturno.sqlite` is created and
seeded with the nine tables the first time the app starts.

To wipe a night and start again, use **Reset demo** on the staff board.

## Restarting after an env change

Environment variables are read once at startup, so restart `npm run dev`
after editing `.env.local`. A stale process is the usual reason a correct
key still reports as invalid.
