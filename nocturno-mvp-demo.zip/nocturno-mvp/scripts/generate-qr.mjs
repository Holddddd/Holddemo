#!/usr/bin/env node
//
// Printable table stickers.
//
//   node scripts/generate-qr.mjs                      → uses NEXT_PUBLIC_BASE_URL
//   node scripts/generate-qr.mjs --base https://x.com  → overrides it
//
// Each table gets an SVG sticker (QR + table number + venue) and a plain
// high-resolution PNG of the code on its own.
//
// The SVG is the one to print. It is vector, so it is sharp at any size
// from a 5cm sticker to an A4 tent card, and there is no DPI to get wrong.
//
// WHAT THE CODE ENCODES: {base}/table/{id} — a plain https URL, so the
// stock camera app on an iPhone or Android opens it as a web page. No app,
// no deep link, no scanner needed.

import fs from "fs";
import path from "path";
import QRCode from "qrcode";

const OUT = "qr-codes";
const VENUE = "CLUB NOCTURNO";

const baseArg = process.argv.indexOf("--base");
const base = (
  baseArg > -1 ? process.argv[baseArg + 1] : process.env.NEXT_PUBLIC_BASE_URL || ""
).replace(/\/$/, "");

if (!base) {
  console.error("No base URL. Pass --base https://your-domain, or set NEXT_PUBLIC_BASE_URL.");
  process.exit(1);
}

// Loud, because a batch of stickers printed with a localhost or LAN URL is
// a batch of stickers that has to be thrown away.
if (/localhost|127\.0\.0\.1/.test(base)) {
  console.error(`\n  ✗ ${base} is not reachable from a phone. Nothing generated.\n`);
  process.exit(1);
}
const isLan = /^https?:\/\/(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(base);

const db = JSON.parse(fs.readFileSync(path.join("data", "db.json"), "utf-8"));
fs.mkdirSync(OUT, { recursive: true });

const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

// A 70×95mm sticker at 1 unit = 1mm, so it prints at physical size.
function sticker(table, qrSvg) {
  // Strip the wrapper off the generated QR and re-place its guts at the
  // size and position the sticker wants.
  const inner = qrSvg.replace(/^[\s\S]*?<svg[^>]*>/, "").replace(/<\/svg>\s*$/, "");
  const vb = qrSvg.match(/viewBox="0 0 (\d+) (\d+)"/);
  const n = vb ? Number(vb[1]) : 33;
  const size = 54;
  const scale = size / n;

  return `<svg xmlns="http://www.w3.org/2000/svg" width="70mm" height="95mm" viewBox="0 0 70 95">
  <rect width="70" height="95" fill="#000000"/>
  <text x="35" y="11" fill="#FFFFFF" font-family="Helvetica,Arial,sans-serif" font-size="4.6"
        font-weight="700" letter-spacing="1.1" text-anchor="middle">${esc(VENUE)}</text>
  <text x="35" y="17.5" fill="#8A8A8A" font-family="Helvetica,Arial,sans-serif" font-size="2.5"
        letter-spacing="1.6" text-anchor="middle">BARCELONA</text>

  <rect x="8" y="23" width="54" height="54" rx="2" fill="#FFFFFF"/>
  <g transform="translate(8,23) scale(${scale})">${inner}</g>

  <text x="35" y="85" fill="#FFFFFF" font-family="Helvetica,Arial,sans-serif" font-size="6.5"
        font-weight="700" letter-spacing="0.4" text-anchor="middle">${esc(table.name)}</text>
  <text x="35" y="91" fill="#8A8A8A" font-family="Helvetica,Arial,sans-serif" font-size="2.7"
        letter-spacing="0.9" text-anchor="middle">SCAN TO OPEN YOUR TABLE</text>
</svg>`;
}

const qrOpts = {
  margin: 1,
  // Highest correction: these get scratched, wet and scanned at an angle
  // in the dark. H survives ~30% of the code being unreadable.
  errorCorrectionLevel: "H",
  color: { dark: "#000000", light: "#FFFFFF" },
};

console.log(`\n  base: ${base}`);
if (isLan) console.log("  ⚠ LAN address — fine for testing on the club wifi, NOT for printing.\n");
else console.log("");

for (const t of db.tables) {
  const url = `${base}/table/${t.id}`;
  const qrSvg = await QRCode.toString(url, { ...qrOpts, type: "svg" });

  fs.writeFileSync(path.join(OUT, `${t.id}-sticker.svg`), sticker(t, qrSvg));
  await QRCode.toFile(path.join(OUT, `${t.id}-code.png`), url, { ...qrOpts, width: 1200 });

  console.log(`  ${t.name.padEnd(22)} → ${url}`);
}

console.log(`\n  ${db.tables.length} tables · ${OUT}/*-sticker.svg to print, *-code.png if you need the bare code\n`);
